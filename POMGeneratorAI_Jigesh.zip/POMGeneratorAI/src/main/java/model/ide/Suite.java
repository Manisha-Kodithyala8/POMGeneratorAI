package model.ide;


	public class Suite
	{
		public String id ;
		public String name ;
		public boolean persistSession ;
		public boolean parallel ;
		public int timeout ;
		public String[] tests ;
		
		public Suite()
		{
			
		}
	}


