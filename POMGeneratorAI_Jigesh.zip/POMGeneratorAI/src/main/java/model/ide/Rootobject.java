package model.ide;

import java.util.ArrayList;

public class Rootobject {

	public String id;
	public String version;
	public String name;
	public String url;
	public ArrayList<Test> tests;
	public ArrayList<Suite> suites;
	public ArrayList<String> urls;
	public ArrayList<Object> plugins;
	
	public Rootobject()
	{
		
	}
}
