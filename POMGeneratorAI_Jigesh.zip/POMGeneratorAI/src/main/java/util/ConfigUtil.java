package util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import model.ConfigDataModel;
import model.spec.SpecModel;
import testSettings.TestRunSettings;

public class ConfigUtil {

	public void readConfigData()
	{
		try
		{
        POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData = new ArrayList<String>();
        whereClause_TestData.add(TestRunSettings.ConfigFileColumnName+"::" + TestRunSettings.ConfigFileColumnValue);
        HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestRunSettings.ConfigurationFile, TestRunSettings.ConfigurationSheet, whereClause_TestData);

        if(result.isEmpty()==false)
        {
        	if(result.get(TestRunSettings.ConfigFileColumnName).size()>0)
        	{
        		
        		for(int i=0;i<result.get(TestRunSettings.ConfigFileColumnName).size();i++)
        		{
        			ConfigDataModel configDataModel= new ConfigDataModel();
        			configDataModel.setInputFileName(result.get("InputFileName").get(i));
        			configDataModel.setExcelFileName(result.get("ExcelFileName").get(i));
        			configDataModel.setExcelSheetName(result.get("ExcelSheetName").get(i));
        			configDataModel.setValidateElementPresent(result.get("ValidateElementPresent").get(i));
        			configDataModel.setPackageName(result.get("PackageName").get(i));
        			configDataModel.setClassName(result.get("ClassName").get(i));
        			configDataModel.setPrimaryMethodName(result.get("PrimaryMethodName").get(i));
        			
        			TestRunSettings.configDataModels.add(configDataModel);
        			
        		}
        		
        	}
        }

		}
		catch(Exception e)
		{
			System.out.println("Unable to retrieve the Data from Configuration File");
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			
			throw e;
		}
	
	}
	

	public void readConfigData_Specs()
	{
		try
		{
        POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData = new ArrayList<String>();
        whereClause_TestData.add(TestRunSettings.ConfigFileColumnName+"::" + TestRunSettings.ConfigFileColumnValue);
        HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestRunSettings.ConfigurationFile, TestRunSettings.ConfigurationSheet_Specs, whereClause_TestData);

        if(result.isEmpty()==false)
        {
        	if(result.get(TestRunSettings.ConfigFileColumnName).size()>0)
        	{
        		
        		for(int i=0;i<result.get(TestRunSettings.ConfigFileColumnName).size();i++)
        		{
        			ConfigDataModel configDataModel= new ConfigDataModel();
        			configDataModel.setInputFileName(result.get("InputFileName").get(i));
        			configDataModel.setInputSheetName(result.get("InputSheetName").get(i));
        			configDataModel.setExcelFileName(result.get("ExcelFileName").get(i));
        			configDataModel.setExcelSheetName(result.get("ExcelSheetName").get(i));
        			configDataModel.setValidateElementPresent(result.get("ValidateElementPresent").get(i));
        			configDataModel.setPackageName(result.get("PackageName").get(i));
        			configDataModel.setClassName(result.get("ClassName").get(i));
        			configDataModel.setPrimaryMethodName(result.get("PrimaryMethodName").get(i));
        			
        			TestRunSettings.configDataModels.add(configDataModel);
        			
        		}
        		
        	}
        }

		}
		catch(Exception e)
		{
			System.out.println("Unable to retrieve the Data from Configuration File");
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			
			throw e;
		}
	
	}

	
	public List<String> readTemplateData(String FilePath)
	{
		
		try {
			List<String> ImportFile = Files.readAllLines(Paths.get(FilePath));
			return ImportFile;
		} catch (IOException e1) {
			System.out.println("Failed to Read data from file " +FilePath);
			e1.printStackTrace();
		}
		return null;

	}


	
	public ArrayList<SpecModel> readSpecsData( HashMap<String, ArrayList<String>> result)
	{
		ArrayList<SpecModel> specModels= new ArrayList<SpecModel>(); 
		
		if(result.isEmpty()==false)
        {
        	if(result.get("ID").size()>0)
        	{
        		
        		for(int i=0;i<result.get("ID").size();i++)
        		{
        			SpecModel specModel= new SpecModel();
        
        			specModel.setScreenName(result.get("ScreenName").get(i));
        			specModel.setSectionName(result.get("SectionName").get(i));
        			specModel.setSubSectionName(result.get("SubSectionName").get(i));
        			specModel.setFieldName(result.get("FieldName").get(i));
        			specModel.setFieldType(result.get("FieldType").get(i));
        			specModel.setFieldType(result.get("ElementType").get(i));
        			specModel.setID(result.get("ID").get(i));

        			specModels.add(specModel);

        		}
        	}
        }
		
		return specModels;
	}
	
}
