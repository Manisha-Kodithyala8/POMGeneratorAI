package testSettings;

import model.ConfigDataModel;
import model.KeywordMappingModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TestRunSettings {

	public static ArrayList<ConfigDataModel> configDataModels= new ArrayList<ConfigDataModel>();
	public static ArrayList<KeywordMappingModel> keywordMappingModels= new ArrayList<KeywordMappingModel>();
	public static HashMap<String,ArrayList<String>> MasterData_Class= new HashMap<String,ArrayList<String>>();
	
	
	public static String homePath="";
	public static String resourcePath="";
	public static String configDirPath="";
	
	public static String KeywordMappingFile;
	public static String KeywordMappingSheet="";
	public static String KeywordMappingColumnValue="";
	public static String KeywordMappingColumnName="";
	
	public static String ConfigurationFile="";
	public static String ConfigurationSheet="";
	public static String ConfigurationSheet_Specs="";
	public static String ConfigFileColumnName="";
	public static String ConfigFileColumnValue="";

	public static String InputFileDir_JSON="";;
	public static String InputFileDir_Specs="";;

	public static String OutputFileDir="";
	public static String TemplateDir="";
	public static String ClassTemplateFile="";
	public static String ElementMethodTemplateFile="";
	public static String MainMethodTemplateFile1="";
	public static String MainMethodTemplateFile2="";
	public static String FindsByTemplateFile="";
	public static int ElementCounter=0;
	
	
	public static String DefaultCommand="";
	public static String VerifyCommand="";
	public static String ElementData;
	public static String ElementMethod;
	
	public static List<String> lst_ClassTemplate= new ArrayList<String>();
	public static List<String> lst_ElementTemplate= new ArrayList<String>();
	public static List<String> lst_MainMethodTemplate1= new ArrayList<String>();
	public static List<String> lst_MainMethodTemplate2= new ArrayList<String>();

	public static List<String> lst_FindsByTemplate= new ArrayList<String>();

	
	
	
}
