package constants;

public class prjConstants {

public static String prjPath="\\src\\main\\java\\";
public static String resourcesPath="\\src\\main\\resources\\";
public static String configFilePath="config\\config.properties";
public static String configDirPath="config\\";



public static String getPrjPath()
{
	 String projectRoot = System.getProperty("user.dir");
	return projectRoot+prjPath ;
	
}

public static String getResourcesPath()
{
	 String projectRoot = System.getProperty("user.dir");
	return projectRoot+resourcesPath ;
	
	
}

public static String getConfig()
{
	 String projectRoot = System.getProperty("user.dir");
	return projectRoot+resourcesPath +configFilePath ;
	
	
}

public static String getConfigDir()
{
	 String projectRoot = System.getProperty("user.dir");
	return projectRoot+resourcesPath +configDirPath ;
	
	
}
}
