package POM.SD;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;

public class Age {
private static final Logger logger =Logger.getLogger(Age.class.getName());
private WebDriver driver;
ReportCommon exceptionDetails = new ReportCommon();
Util util = new Util();

String ModuleName = ModuleConstants_SD._SD;
String ScreenName = ScreenConstants_SD.Age;
public Age(){ }
public Age(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
 public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }

@FindBy(how = How.CSS, using = "h1 > .english")
public WebElement ELE_Age_Header_English;

@FindBy(how = How.CSS, using = ".progressBarContainer .english")
public WebElement ELE_Age_ProgressBar_English;

@FindBy(how = How.CSS, using = "p:nth-child(1) > .english")
public WebElement ELE_Age_Para1_English;

@FindBy(how = How.CSS, using = "#ageError > .english")
public WebElement ELE_Age_Error_English;

@FindBy(how = How.ID, using = "ageInput")
public WebElement TXT_Age_AgeInput;

@FindBy(how = How.CSS, using = "#nextQuestionAgeBtn > .english")
public WebElement ELE_Age_Next_English;

@FindBy(how = How.CSS, using = "#languageToggle > .english")
public WebElement BTN_Age_LanguageToggle_Spanish;

@FindBy(how = How.CSS, using = "h1 > .spanish")
public WebElement ELE_Age_Header_Spanish;

@FindBy(how = How.CSS, using = ".progressBarContainer .spanish")
public WebElement ELE_Age_Para1_Spanish;

@FindBy(how = How.CSS, using = "p:nth-child(1) > .spanish")
public WebElement ELE_Age_Para2_Spanish;

@FindBy(how = How.CSS, using = ".spanish:nth-child(3)")
public WebElement ELE_Age_Label_Spanish;

@FindBy(how = How.CSS, using = "#ageError > .spanish")
public WebElement ELE_Age_Error_Spanish;

@FindBy(how = How.CSS, using = "#nextQuestionAgeBtn > .spanish")
public WebElement ELE_Age_Next_Spanish;

@FindBy(how = How.ID, using = "languageToggle")
public WebElement BTN_Age_LangiageToggle_Spanish;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Header_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Header_English(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Header_English";
action.PageActionDescription = "ELE_Age_Header_English";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Header_English,Data_Age_Header_English, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Header_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_ProgressBar_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_ProgressBar_English(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_ProgressBar_English";
action.PageActionDescription = "ELE_Age_ProgressBar_English";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_ProgressBar_English,Data_Age_ProgressBar_English, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_ProgressBar_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Para1_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Para1_English(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Para1_English";
action.PageActionDescription = "ELE_Age_Para1_English";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Para1_English,Data_Age_Para1_English, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Para1_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Error_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Error_English(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Error_English";
action.PageActionDescription = "ELE_Age_Error_English";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Error_English,Data_Age_Error_English, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Error_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  TXT_Age_AgeInput///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void TXT_Age_AgeInput(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "TXT_Age_AgeInput";
action.PageActionDescription = "TXT_Age_AgeInput";
try {
WebKeywords.Instance().SetText(driver,  TXT_Age_AgeInput,Data_Age_AgeInput, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  TXT_Age_AgeInput///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  verifyAge_AgeInput///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void verifyAge_AgeInput(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "verifyAge_AgeInput";
action.PageActionDescription = "verifyAge_AgeInput";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver,  TXT_Age_AgeInput,VerifyData_Age_AgeInput, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  verifyAge_AgeInput///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Next_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Next_English(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Next_English";
action.PageActionDescription = "ELE_Age_Next_English";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Next_English,Data_Age_Next_English, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Next_English///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  BTN_Age_LanguageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void BTN_Age_LanguageToggle_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "BTN_Age_LanguageToggle_Spanish";
action.PageActionDescription = "BTN_Age_LanguageToggle_Spanish";
try {
WebKeywords.Instance().Click(driver,  BTN_Age_LanguageToggle_Spanish,Data_Age_LanguageToggle_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  BTN_Age_LanguageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  verifyAge_LanguageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void verifyAge_LanguageToggle_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "verifyAge_LanguageToggle_Spanish";
action.PageActionDescription = "verifyAge_LanguageToggle_Spanish";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver,  BTN_Age_LanguageToggle_Spanish,VerifyData_Age_LanguageToggle_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  verifyAge_LanguageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Header_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Header_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Header_Spanish";
action.PageActionDescription = "ELE_Age_Header_Spanish";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Header_Spanish,Data_Age_Header_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Header_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Para1_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Para1_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Para1_Spanish";
action.PageActionDescription = "ELE_Age_Para1_Spanish";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Para1_Spanish,Data_Age_Para1_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Para1_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Para2_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Para2_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Para2_Spanish";
action.PageActionDescription = "ELE_Age_Para2_Spanish";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Para2_Spanish,Data_Age_Para2_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Para2_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Label_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Label_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Label_Spanish";
action.PageActionDescription = "ELE_Age_Label_Spanish";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Label_Spanish,Data_Age_Label_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Label_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Error_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Error_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Error_Spanish";
action.PageActionDescription = "ELE_Age_Error_Spanish";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Error_Spanish,Data_Age_Error_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Error_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ELE_Age_Next_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void ELE_Age_Next_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "ELE_Age_Next_Spanish";
action.PageActionDescription = "ELE_Age_Next_Spanish";
try {
WebKeywords.Instance().VerifyTextDisplayed(driver, ELE_Age_Next_Spanish,Data_Age_Next_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  ELE_Age_Next_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  BTN_Age_LangiageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void BTN_Age_LangiageToggle_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "BTN_Age_LangiageToggle_Spanish";
action.PageActionDescription = "BTN_Age_LangiageToggle_Spanish";
try {
WebKeywords.Instance().Click(driver,  BTN_Age_LangiageToggle_Spanish,Data_Age_LangiageToggle_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  BTN_Age_LangiageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  verifyAge_LangiageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void verifyAge_LangiageToggle_Spanish(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "verifyAge_LangiageToggle_Spanish";
action.PageActionDescription = "verifyAge_LangiageToggle_Spanish";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver,  BTN_Age_LangiageToggle_Spanish,VerifyData_Age_LangiageToggle_Spanish, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  verifyAge_LangiageToggle_Spanish///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void (TestCaseParam testCaseParam,String iteration) throws Exception  {
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "";
action.PageActionDescription = "";

boolean result=false;
try {
HashMap<String, ArrayList<String>> TestCaseData_SD = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,iteration);


String Data_Age_Header_English = TestCaseData_SD.get("Data_Age_Header_English").get(0);
String Data_Age_ProgressBar_English = TestCaseData_SD.get("Data_Age_ProgressBar_English").get(0);
String Data_Age_Para1_English = TestCaseData_SD.get("Data_Age_Para1_English").get(0);
String Data_Age_Error_English = TestCaseData_SD.get("Data_Age_Error_English").get(0);
String Data_Age_AgeInput = TestCaseData_SD.get("Data_Age_AgeInput").get(0);
String Data_Age_Next_English = TestCaseData_SD.get("Data_Age_Next_English").get(0);
String Data_Age_LanguageToggle_Spanish = TestCaseData_SD.get("Data_Age_LanguageToggle_Spanish").get(0);
String Data_Age_Header_Spanish = TestCaseData_SD.get("Data_Age_Header_Spanish").get(0);
String Data_Age_Para1_Spanish = TestCaseData_SD.get("Data_Age_Para1_Spanish").get(0);
String Data_Age_Para2_Spanish = TestCaseData_SD.get("Data_Age_Para2_Spanish").get(0);
String Data_Age_Label_Spanish = TestCaseData_SD.get("Data_Age_Label_Spanish").get(0);
String Data_Age_Error_Spanish = TestCaseData_SD.get("Data_Age_Error_Spanish").get(0);
String Data_Age_Next_Spanish = TestCaseData_SD.get("Data_Age_Next_Spanish").get(0);
String Data_Age_LangiageToggle_Spanish = TestCaseData_SD.get("Data_Age_LangiageToggle_Spanish").get(0);

String VerifyData_Age_Header_English = TestCaseData_SD.get("VerifyData_Age_Header_English").get(0);
String VerifyData_Age_ProgressBar_English = TestCaseData_SD.get("VerifyData_Age_ProgressBar_English").get(0);
String VerifyData_Age_Para1_English = TestCaseData_SD.get("VerifyData_Age_Para1_English").get(0);
String VerifyData_Age_Error_English = TestCaseData_SD.get("VerifyData_Age_Error_English").get(0);
String VerifyData_Age_AgeInput = TestCaseData_SD.get("VerifyData_Age_AgeInput").get(0);
String VerifyData_Age_Next_English = TestCaseData_SD.get("VerifyData_Age_Next_English").get(0);
String VerifyData_Age_LanguageToggle_Spanish = TestCaseData_SD.get("VerifyData_Age_LanguageToggle_Spanish").get(0);
String VerifyData_Age_Header_Spanish = TestCaseData_SD.get("VerifyData_Age_Header_Spanish").get(0);
String VerifyData_Age_Para1_Spanish = TestCaseData_SD.get("VerifyData_Age_Para1_Spanish").get(0);
String VerifyData_Age_Para2_Spanish = TestCaseData_SD.get("VerifyData_Age_Para2_Spanish").get(0);
String VerifyData_Age_Label_Spanish = TestCaseData_SD.get("VerifyData_Age_Label_Spanish").get(0);
String VerifyData_Age_Error_Spanish = TestCaseData_SD.get("VerifyData_Age_Error_Spanish").get(0);
String VerifyData_Age_Next_Spanish = TestCaseData_SD.get("VerifyData_Age_Next_Spanish").get(0);
String VerifyData_Age_LangiageToggle_Spanish = TestCaseData_SD.get("VerifyData_Age_LangiageToggle_Spanish").get(0);

Age_Header_English(testCaseParam,Data_Age_Header_English);
Age_ProgressBar_English(testCaseParam,Data_Age_ProgressBar_English);
Age_Para1_English(testCaseParam,Data_Age_Para1_English);
Age_Error_English(testCaseParam,Data_Age_Error_English);
Age_AgeInput(testCaseParam,Data_Age_AgeInput);
Age_Next_English(testCaseParam,Data_Age_Next_English);
Age_LanguageToggle_Spanish(testCaseParam,Data_Age_LanguageToggle_Spanish);
Age_Header_Spanish(testCaseParam,Data_Age_Header_Spanish);
Age_Para1_Spanish(testCaseParam,Data_Age_Para1_Spanish);
Age_Para2_Spanish(testCaseParam,Data_Age_Para2_Spanish);
Age_Label_Spanish(testCaseParam,Data_Age_Label_Spanish);
Age_Error_Spanish(testCaseParam,Data_Age_Error_Spanish);
Age_Next_Spanish(testCaseParam,Data_Age_Next_Spanish);
Age_LangiageToggle_Spanish(testCaseParam,Data_Age_LangiageToggle_Spanish);

verifyAge_Header_English(testCaseParam,VerifyData_Age_Header_English);
verifyAge_ProgressBar_English(testCaseParam,VerifyData_Age_ProgressBar_English);
verifyAge_Para1_English(testCaseParam,VerifyData_Age_Para1_English);
verifyAge_Error_English(testCaseParam,VerifyData_Age_Error_English);
verifyAge_AgeInput(testCaseParam,VerifyData_Age_AgeInput);
verifyAge_Next_English(testCaseParam,VerifyData_Age_Next_English);
verifyAge_LanguageToggle_Spanish(testCaseParam,VerifyData_Age_LanguageToggle_Spanish);
verifyAge_Header_Spanish(testCaseParam,VerifyData_Age_Header_Spanish);
verifyAge_Para1_Spanish(testCaseParam,VerifyData_Age_Para1_Spanish);
verifyAge_Para2_Spanish(testCaseParam,VerifyData_Age_Para2_Spanish);
verifyAge_Label_Spanish(testCaseParam,VerifyData_Age_Label_Spanish);
verifyAge_Error_Spanish(testCaseParam,VerifyData_Age_Error_Spanish);
verifyAge_Next_Spanish(testCaseParam,VerifyData_Age_Next_Spanish);
verifyAge_LangiageToggle_Spanish(testCaseParam,VerifyData_Age_LangiageToggle_Spanish);



  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
}
}

 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  #*MainMethodName*#///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

