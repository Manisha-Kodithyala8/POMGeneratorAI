package POM.SCR;
import Constants.ModuleConstants_SCR;
import Constants.ScreenConstants_SCR;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;

public class Screening {
private static final Logger logger =Logger.getLogger(Screening.class.getName());
private WebDriver driver;
ReportCommon exceptionDetails = new ReportCommon();
Util util = new Util();

String ModuleName = ModuleConstants_SCR._SCR;
String ScreenName = ScreenConstants_SCR.Screening;
public Screening(){ }
public Screening(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
 public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }

@FindBy(how = How.ID, using = "ScreeningName")
public WebElement ScreeningName;

@FindBy(how = How.ID, using = "Username")
public WebElement Username;

@FindBy(how = How.ID, using = "Date")
public WebElement Date;

@FindBy(how = How.ID, using = "Time")
public WebElement Time;

@FindBy(how = How.ID, using = "CallReason")
public WebElement ReasonfortheCall;

@FindBy(how = How.ID, using = "ScreeningNarrative")
public WebElement ScreeningNarrative;

@FindBy(how = How.ID, using = "Caller")
public WebElement Caller;

@FindBy(how = How.ID, using = "CallerFirstName")
public WebElement CallerFirstName;

@FindBy(how = How.ID, using = "SafelySurrenderedBaby")
public WebElement SafelySurrenderedBaby;

@FindBy(how = How.ID, using = "PhoneType")
public WebElement PhoneType;

@FindBy(how = How.ID, using = "ScreeningPersons")
public WebElement ScreeningPersons;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _ScreeningName///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _ScreeningName(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> ScreeningName";
action.PageActionDescription = " ==> ScreeningName";
try {
WebKeywords.Instance().Click(driver,  ScreeningName,Data_ScreeningName, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _ScreeningName///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _Username///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _Username(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> Username";
action.PageActionDescription = " ==> Username";
try {
WebKeywords.Instance().Click(driver,  Username,Data_Username, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _Username///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _Date///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _Date(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> Date";
action.PageActionDescription = " ==> Date";
try {
WebKeywords.Instance().Click(driver,  Date,Data_Date, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _Date///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _Time///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _Time(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> Time";
action.PageActionDescription = " ==> Time";
try {
WebKeywords.Instance().Click(driver,  Time,Data_Time, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _Time///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _ReasonfortheCall///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _ReasonfortheCall(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> ReasonfortheCall";
action.PageActionDescription = " ==> ReasonfortheCall";
try {
WebKeywords.Instance().Click(driver,  ReasonfortheCall,Data_ReasonfortheCall, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _ReasonfortheCall///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _ScreeningNarrative///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _ScreeningNarrative(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> ScreeningNarrative";
action.PageActionDescription = " ==> ScreeningNarrative";
try {
WebKeywords.Instance().Click(driver,  ScreeningNarrative,Data_ScreeningNarrative, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _ScreeningNarrative///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _Caller///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _Caller(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> Caller";
action.PageActionDescription = " ==> Caller";
try {
WebKeywords.Instance().Click(driver,  Caller,Data_Caller, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _Caller///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _CallerFirstName///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _CallerFirstName(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> CallerFirstName";
action.PageActionDescription = " ==> CallerFirstName";
try {
WebKeywords.Instance().Click(driver,  CallerFirstName,Data_CallerFirstName, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _CallerFirstName///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _SafelySurrenderedBaby///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _SafelySurrenderedBaby(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> SafelySurrenderedBaby";
action.PageActionDescription = " ==> SafelySurrenderedBaby";
try {
WebKeywords.Instance().Click(driver,  SafelySurrenderedBaby,Data_SafelySurrenderedBaby, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _SafelySurrenderedBaby///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _PhoneType///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _PhoneType(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> PhoneType";
action.PageActionDescription = " ==> PhoneType";
try {
WebKeywords.Instance().Click(driver,  PhoneType,Data_PhoneType, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _PhoneType///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  _ScreeningPersons///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void _ScreeningPersons(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = " ==> ScreeningPersons";
action.PageActionDescription = " ==> ScreeningPersons";
try {
WebKeywords.Instance().Click(driver,  ScreeningPersons,Data_ScreeningPersons, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  _ScreeningPersons///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method Start ===>  ///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void (TestCaseParam testCaseParam,String iteration) throws Exception  {
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "";
action.PageActionDescription = "";

boolean result=false;
try {
HashMap<String, ArrayList<String>> TestCaseData_SCR = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SCR,iteration);


String Data_ScreeningName = TestCaseData_SCR.get("Data_ScreeningName").get(0);
String Data_Username = TestCaseData_SCR.get("Data_Username").get(0);
String Data_Date = TestCaseData_SCR.get("Data_Date").get(0);
String Data_Time = TestCaseData_SCR.get("Data_Time").get(0);
String Data_ReasonfortheCall = TestCaseData_SCR.get("Data_ReasonfortheCall").get(0);
String Data_ScreeningNarrative = TestCaseData_SCR.get("Data_ScreeningNarrative").get(0);
String Data_Caller = TestCaseData_SCR.get("Data_Caller").get(0);
String Data_CallerFirstName = TestCaseData_SCR.get("Data_CallerFirstName").get(0);
String Data_SafelySurrenderedBaby = TestCaseData_SCR.get("Data_SafelySurrenderedBaby").get(0);
String Data_PhoneType = TestCaseData_SCR.get("Data_PhoneType").get(0);
String Data_ScreeningPersons = TestCaseData_SCR.get("Data_ScreeningPersons").get(0);

String VerifyData_ScreeningName = TestCaseData_SCR.get("VerifyData_ScreeningName").get(0);
String VerifyData_Username = TestCaseData_SCR.get("VerifyData_Username").get(0);
String VerifyData_Date = TestCaseData_SCR.get("VerifyData_Date").get(0);
String VerifyData_Time = TestCaseData_SCR.get("VerifyData_Time").get(0);
String VerifyData_ReasonfortheCall = TestCaseData_SCR.get("VerifyData_ReasonfortheCall").get(0);
String VerifyData_ScreeningNarrative = TestCaseData_SCR.get("VerifyData_ScreeningNarrative").get(0);
String VerifyData_Caller = TestCaseData_SCR.get("VerifyData_Caller").get(0);
String VerifyData_CallerFirstName = TestCaseData_SCR.get("VerifyData_CallerFirstName").get(0);
String VerifyData_SafelySurrenderedBaby = TestCaseData_SCR.get("VerifyData_SafelySurrenderedBaby").get(0);
String VerifyData_PhoneType = TestCaseData_SCR.get("VerifyData_PhoneType").get(0);
String VerifyData_ScreeningPersons = TestCaseData_SCR.get("VerifyData_ScreeningPersons").get(0);

ScreeningName_method(testCaseParam,Data_ScreeningName);
Username_method(testCaseParam,Data_Username);
Date_method(testCaseParam,Data_Date);
Time_method(testCaseParam,Data_Time);
ReasonfortheCall_method(testCaseParam,Data_ReasonfortheCall);
ScreeningNarrative_method(testCaseParam,Data_ScreeningNarrative);
Caller_method(testCaseParam,Data_Caller);
CallerFirstName_method(testCaseParam,Data_CallerFirstName);
SafelySurrenderedBaby_method(testCaseParam,Data_SafelySurrenderedBaby);
PhoneType_method(testCaseParam,Data_PhoneType);
ScreeningPersons_method(testCaseParam,Data_ScreeningPersons);

verifyScreeningName(testCaseParam,VerifyData_ScreeningName);
verifyUsername(testCaseParam,VerifyData_Username);
verifyDate(testCaseParam,VerifyData_Date);
verifyTime(testCaseParam,VerifyData_Time);
verifyReasonfortheCall(testCaseParam,VerifyData_ReasonfortheCall);
verifyScreeningNarrative(testCaseParam,VerifyData_ScreeningNarrative);
verifyCaller(testCaseParam,VerifyData_Caller);
verifyCallerFirstName(testCaseParam,VerifyData_CallerFirstName);
verifySafelySurrenderedBaby(testCaseParam,VerifyData_SafelySurrenderedBaby);
verifyPhoneType(testCaseParam,VerifyData_PhoneType);
verifyScreeningPersons(testCaseParam,VerifyData_ScreeningPersons);



  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
}
}

 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Method End ===>  #*MainMethodName*#///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

