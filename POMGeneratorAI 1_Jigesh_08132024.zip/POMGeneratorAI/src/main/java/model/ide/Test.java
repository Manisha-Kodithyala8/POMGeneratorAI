package model.ide;

import java.util.ArrayList;

public class Test {

	public String id;
	public String name;
	public ArrayList<Command> commands;
	
	public Test()
	{
		
	}
}
