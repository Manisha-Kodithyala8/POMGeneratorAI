package model.ide;

import java.util.ArrayList;

public class Command
{
	public String id ;
	public String comment ;
	public String command ;
	public String target ;
	public ArrayList<ArrayList<String>> targets ;
	public String value ;

	public Command()
	{
		
	}
}

