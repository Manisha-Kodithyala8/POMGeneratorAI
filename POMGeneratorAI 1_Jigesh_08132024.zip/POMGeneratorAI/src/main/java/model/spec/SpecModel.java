package model.spec;

public class SpecModel {

	public String ScreenName="";
	public String SectionName="";
	public String SubSectionName="";
	public String FieldName="";
	public String FieldType="";
	public String ElementType="";
	public String ID="";
	
	
	public String getScreenName() {
		return ScreenName;
	}
	public void setScreenName(String screenName) {
		ScreenName = screenName;
	}
	public String getSectionName() {
		return SectionName;
	}
	public void setSectionName(String sectionName) {
		SectionName = sectionName;
	}
	public String getSubSectionName() {
		return SubSectionName;
	}
	public void setSubSectionName(String subSectionName) {
		SubSectionName = subSectionName;
	}
	public String getFieldName() {
		return FieldName;
	}
	public void setFieldName(String fieldName) {
		FieldName = fieldName;
	}
	public String getFieldType() {
		return FieldType;
	}
	public void setFieldType(String fieldType) {
		FieldType = fieldType;
	}
	public String getElementType() {
		return ElementType;
	}
	public void setElementType(String elementType) {
		ElementType = elementType;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}

	
	
}
