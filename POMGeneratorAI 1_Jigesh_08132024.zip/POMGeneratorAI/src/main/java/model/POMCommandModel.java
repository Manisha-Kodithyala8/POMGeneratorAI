package model;

public class POMCommandModel 
{
	public String ClassName="";
	public String ModuleName="";
	public String ElementType="";
	public String ElementName="";
	public String Data_ElementName="";
	public String VerifyData_ElementName="";
	public String MainMethodName="";
	public String MethodName="";
	public String VerifyMethodName="";
	public String CommandDetails="";
	public String VerifyCommandDetails="";
	public String FindByString="";
	public String FindByString2="";
	
	public String MainMethodVariable="";
	public String VerifyMethodVariable="";
	public String MainMethodCall="";
	public String MainMethodVerifyCall="";
	public boolean isVerify=false;

	
}


