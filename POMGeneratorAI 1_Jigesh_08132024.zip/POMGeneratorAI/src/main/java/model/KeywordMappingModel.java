package model;

public class KeywordMappingModel {

	public  String IDE_Command="";	
	public  String CodeDrivenCommands="";
	public  String ElementType="";
	public  boolean isValidation=false;
	
	public  String getIDE_Command() {
		return IDE_Command;
	}
	
	public  void setIDE_Command(String ide_Command) {
		IDE_Command = ide_Command;
	}
	public  String getCodeDrivenCommands() {
		return CodeDrivenCommands;
	}
	public  void setCodeDrivenCommands(String codeDrivenCommands) {
		CodeDrivenCommands = codeDrivenCommands;
	}
	public  String getElementType() {
		return ElementType;
	}
	public  void setElementType(String elementType) {
		ElementType = elementType;
	}

	
	
}
