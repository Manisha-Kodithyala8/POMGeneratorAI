package model;


public class ConfigDataModel {
    private String inputFileName;
    private String inputSheetName;
    private String excelFileName;
    private String excelSheetName;
    private String validateElementPresent;
    private String packageName;
    private String className;
    private String primaryMethodName;

    public String getInputFileName() {
        return inputFileName;
    }

    public void setInputFileName(String inputFileName) {
        this.inputFileName = inputFileName;
    }

    
    public String getInputSheetName() {
		return inputSheetName;
	}

	public void setInputSheetName(String inputSheetName) {
		this.inputSheetName = inputSheetName;
	}

	public String getExcelFileName() {
        return excelFileName;
    }

    public void setExcelFileName(String excelFileName) {
        this.excelFileName = excelFileName;
    }

    public String getExcelSheetName() {
        return excelSheetName;
    }

    public void setExcelSheetName(String excelSheetName) {
        this.excelSheetName = excelSheetName;
    }

    public String getValidateElementPresent() {
        return validateElementPresent;
    }

    public void setValidateElementPresent(String validateElementPresent) {
        this.validateElementPresent = validateElementPresent;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getPrimaryMethodName() {
        return primaryMethodName;
    }

    public void setPrimaryMethodName(String primaryMethodName) {
        this.primaryMethodName = primaryMethodName;
    }
}

