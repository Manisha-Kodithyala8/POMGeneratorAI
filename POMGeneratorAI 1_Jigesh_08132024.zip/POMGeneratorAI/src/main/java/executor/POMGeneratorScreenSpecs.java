package executor;

import java.io.IOException;
import util.POI_ReadExcel;
import util.POMClassWriter;
import util.SeleniumIDEUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import util.CommandUtil;
import util.ConfigUtil;

import model.ConfigDataModel;
import model.ide.Command;
import model.spec.SpecModel;
import model.POMCommandModel;
import testSettings.TestRunSettings;
import testSettings.initializeTestSettings;

import java.io.*;
public class POMGeneratorScreenSpecs {

	public static void main(String[] args) throws IOException, Exception {
		
		initializeTestSettings initializetestSettings = new initializeTestSettings();
		initializetestSettings.initializeSettings();
		
		
		ConfigUtil configUtil= new ConfigUtil();
		configUtil.readConfigData_Specs();
		
		TestRunSettings.lst_ClassTemplate= configUtil.readTemplateData(TestRunSettings.ClassTemplateFile);
		TestRunSettings.lst_ElementTemplate=configUtil.readTemplateData(TestRunSettings.ElementMethodTemplateFile);
		TestRunSettings.lst_MainMethodTemplate1=configUtil.readTemplateData(TestRunSettings.MainMethodTemplateFile1);
		TestRunSettings.lst_MainMethodTemplate2=configUtil.readTemplateData(TestRunSettings.MainMethodTemplateFile2);
		TestRunSettings.lst_FindsByTemplate=configUtil.readTemplateData(TestRunSettings.FindsByTemplateFile);
		
		
		for(ConfigDataModel configDataModel:TestRunSettings.configDataModels )
		{
			
			CommandUtil commandUtil= new CommandUtil();
			SeleniumIDEUtil seleniumIDEUtil = new SeleniumIDEUtil();
			String InputFilePath=TestRunSettings.InputFileDir_Specs + configDataModel.getInputFileName();
			String InputSheetName=configDataModel.getInputSheetName();

			POI_ReadExcel poiObject = new POI_ReadExcel();
	        ArrayList<String> whereClause_TestData = new ArrayList<String>();
	        whereClause_TestData.add("ScreenName::" + configDataModel.getClassName());
	        HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(InputFilePath,InputSheetName, whereClause_TestData);

	        ArrayList<SpecModel> specModels=new ConfigUtil().readSpecsData(result);
			
			

			ArrayList<POMCommandModel> pomCommandModels=new ArrayList<POMCommandModel>();

			for(SpecModel specModel :specModels)
			{
				POMCommandModel pomCommandModel= new POMCommandModel();
				pomCommandModel.ClassName=configDataModel.getClassName();
				pomCommandModel.ModuleName=configDataModel.getPackageName();
				String ElementName=commandUtil.getElementName(specModel.FieldName.replace(" ", ""));
				String ElementType=commandUtil.getElementType(specModel.FieldType.replace(" ", ""));
				pomCommandModel.Data_ElementName="Data_"+ElementName;
				pomCommandModel.VerifyData_ElementName="VerifyData_"+ElementName;
				pomCommandModel.MethodName=ElementName; 
				pomCommandModel.VerifyMethodName= "verify" + ElementName;
				pomCommandModel.isVerify=commandUtil.isVerifyCommand(specModel.FieldType);
				pomCommandModel.ElementType=ElementType;

				if(ElementType.equals("")==false)
				{
					ElementName=ElementType+"_"+ElementName;
				}
				
				
				
				pomCommandModel.ElementName=ElementName;
				
				pomCommandModel.FindByString=commandUtil.getFindByStringID(specModel.ID);
				pomCommandModel.FindByString2=commandUtil.getFindByString2(ElementName);
				
				pomCommandModel.CommandDetails=commandUtil.getElementCommand(specModel.ElementType);
				pomCommandModel.CommandDetails=pomCommandModel.CommandDetails.replace("#*ElementName*#", ElementName);
				pomCommandModel.CommandDetails=pomCommandModel.CommandDetails.replace("#*TestData*#",pomCommandModel.Data_ElementName);
				
				pomCommandModel.VerifyCommandDetails=TestRunSettings.VerifyCommand;
				pomCommandModel.VerifyCommandDetails=pomCommandModel.VerifyCommandDetails.replace("#*ElementName*#", ElementName);
				pomCommandModel.VerifyCommandDetails=pomCommandModel.VerifyCommandDetails.replace("#*TestData*#",pomCommandModel.VerifyData_ElementName);

				
				pomCommandModel.MainMethodVariable=commandUtil.MainMethodVariable(pomCommandModel.Data_ElementName,pomCommandModel.ModuleName);
				pomCommandModel.VerifyMethodVariable=commandUtil.MainMethodVariable(pomCommandModel.VerifyData_ElementName,pomCommandModel.ModuleName);
				
				pomCommandModel.MainMethodCall=commandUtil.MainMethodCall(pomCommandModel.MethodName,pomCommandModel.Data_ElementName);
				pomCommandModel.MainMethodVerifyCall=commandUtil.MainMethodCall(pomCommandModel.VerifyMethodName,pomCommandModel.VerifyData_ElementName);

				
				pomCommandModels.add(pomCommandModel);
				
			}
			
			
			POMClassWriter pomClassWriter= new POMClassWriter();
			pomClassWriter.updateClassTemplate(pomCommandModels.get(0));
			pomClassWriter.updateFindByTemplate(pomCommandModels);
			pomClassWriter.updateMethodDetails(pomCommandModels);
			pomClassWriter.updateMainMethod_1(pomCommandModels);
			pomClassWriter.updateMainMethod_Data(pomCommandModels);
			pomClassWriter.updateMainMethod_2(pomCommandModels);
			
			

		}
		
		for(String hash : TestRunSettings.MasterData_Class.keySet())
		{
			ArrayList<String> hashData= TestRunSettings.MasterData_Class.get(hash);
			
		File file = new File(TestRunSettings.OutputFileDir+hash + ".java");
		System.out.println("FilePath : "+ TestRunSettings.OutputFileDir+hash + ".java");
		FileWriter fileWriter = new FileWriter(file);
		BufferedWriter buffer = new BufferedWriter(fileWriter);
		for(String s : hashData) {
			buffer.write(s);
			buffer.newLine();
		}
		buffer.close();
		}
	}
}
