package util;


import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;
import model.ide.Rootobject;

public class ReadJSONData {

	public String DeSerializeJSONData(Rootobject RO) throws Exception
	{
		String JSONData="";
		ObjectMapper mapper = new ObjectMapper();
		try {
			
			JSONData=mapper.writeValueAsString(RO);
			System.out.println(JSONData);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
		
		return JSONData;
		
	}
	public void DeSerializeJSONDataWriteToFile(Rootobject RO,String FilePath) throws Exception
	{
		File file = new File(FilePath);
		ObjectMapper mapper = new ObjectMapper();

		try {
			
			mapper.writeValue(file, RO);
			String JSONData=mapper.writeValueAsString(RO);
			System.out.println(JSONData);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
			
	}
	
	
	public Rootobject SerializeJSONDatafromString(String CaseData) throws Exception
	{

		Rootobject RO = new Rootobject();
		ObjectMapper mapper = new ObjectMapper();
		try {
			
			RO= mapper.readValue(CaseData, Rootobject.class);
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
		
		return RO;
		
	}
	
	public Rootobject SerializeJSONDatafromFile(String FilePath) throws Exception
	{

		Rootobject RO = new Rootobject();
		ObjectMapper mapper = new ObjectMapper();
		try {
			
			RO= mapper.readValue(new File(FilePath), Rootobject.class);
			System.out.println("ReadJSONData ----> " + RO.name);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
		
		return RO;
		
	}
	
}

