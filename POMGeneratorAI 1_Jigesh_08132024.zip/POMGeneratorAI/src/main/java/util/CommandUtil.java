package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import testSettings.TestRunSettings;
import model.KeywordMappingModel;
public class CommandUtil {

	
	public void setCommandMapping()
	{
		
		POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData = new ArrayList<String>();
        whereClause_TestData.add(TestRunSettings.KeywordMappingColumnName+"::" + TestRunSettings.KeywordMappingColumnValue);
        HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestRunSettings.KeywordMappingFile, TestRunSettings.KeywordMappingSheet, whereClause_TestData);

        
        if(result.isEmpty()==false)
        {
        	if(result.get(TestRunSettings.KeywordMappingColumnName).size()>0)
        	{
        		
        		for(int i=0;i<result.get(TestRunSettings.KeywordMappingColumnName).size();i++)
        		{
        			KeywordMappingModel keywordMappingModel= new KeywordMappingModel();
        			
        			keywordMappingModel.setIDE_Command(result.get("IDE_Command").get(i));
        			keywordMappingModel.setCodeDrivenCommands(result.get("CodeDrivenCommands").get(i));
        			keywordMappingModel.setElementType(result.get("ElementType").get(i));
      
        			if(result.get("ValidationKeyword").get(i).equalsIgnoreCase("Y"))
        			{
        				keywordMappingModel.isValidation=true;
        			}
        			
        			TestRunSettings.keywordMappingModels.add(keywordMappingModel);
        		}
        	}
        }
	}
	
    public String getElementName(String Comment)
    {
          String elementName="";
          if(Comment.equals(""))
          {
                 elementName="Element_" + TestRunSettings.ElementCounter;
                 TestRunSettings.ElementCounter++;
          }
          else
          {
                 Comment=Comment.replaceAll(" ", "_");
                 elementName=Comment;
          }
          
          return elementName;

    }

    
    
    public String getElementCommand(String commandValue)
    {
    	Optional<KeywordMappingModel> result = TestRunSettings.keywordMappingModels.stream()
    		    .filter(model -> model.IDE_Command.equals(commandValue))
    		    .findFirst();

    		// Handling the result
    		if (result.isPresent()) {
    			return result.get().CodeDrivenCommands;
    			
    		} else {
    			return TestRunSettings.DefaultCommand;
    		}
    	
    	
		
    }
    
    public String getElementType(String commandValue)
    {
    	Optional<KeywordMappingModel> result = TestRunSettings.keywordMappingModels.stream()
    		    .filter(model -> model.IDE_Command.equals(commandValue))
    		    .findFirst();

    		// Handling the result
    		if (result.isPresent()) {
    			return result.get().ElementType;
    			
    		} else {
    			return "";
    		}
    	
    	
		
    }

    
		public String getFindByString(String ElementValue)
		{
			String HowText="";
			String elementValue="";
			
			if(ElementValue.startsWith("id="))
			{
				HowText="How.ID";
				elementValue=ElementValue.replace("id=", "");
				elementValue=elementValue.replace("\"", "\\\"");
			}
			else if(ElementValue.startsWith("name="))
			{
				HowText="How.NAME";
				elementValue=ElementValue.replace("name=", "");
				elementValue=elementValue.replace("\"", "\\\"");
			}
			else if(ElementValue.startsWith("xpath="))
			{
				HowText="How.XPATH";
				elementValue=ElementValue.replace("xpath=", "");
				elementValue=elementValue.replace("\"", "\\\"");
			}
			else if(ElementValue.startsWith("css="))
			{
				HowText="How.CSS";
				elementValue=ElementValue.replace("css=", "");
				elementValue=elementValue.replace("\"", "\\\"");
			}
			else if(ElementValue.startsWith("linkText="))
			{
				HowText="How.LINK_TEXT";
				elementValue=ElementValue.replace("linkText=", "");
				elementValue=elementValue.replace("\"", "\\\"");
			}
			else if(ElementValue.startsWith("partialLinkText="))
			{
				HowText="How.PARTIAL_LINK_TEXT";
				elementValue=ElementValue.replace("partialLinkText=", "");
				elementValue=elementValue.replace("\"", "\\\"");
			}
			else
			{
				HowText="How.XPATH";
				elementValue=ElementValue.replace("xpath=", "");
				elementValue=elementValue.replace("\"", "\\\"");
			}
			
			String FindsBy="@FindBy(how = "+HowText+", using = \""+elementValue+"\")";
			return FindsBy;
		}
		

	
		public String getFindByString2(String ElementName)
		{
			String FindByString2="public WebElement #*ElementName*#;";
			FindByString2=FindByString2.replace("#*ElementName*#", ElementName);
			return FindByString2;
		}
		

		public String getFindByStringID(String ElementValue)
		{
			String HowText="";
			
				HowText="How.ID";
				String FindsBy="@FindBy(how = "+HowText+", using = \""+ElementValue+"\")";
				return FindsBy;

				
			}

		
		public String MainMethodVariable(String DataVariable,String ModuleName)
		{
			String DataString="String #*DataVariable*# = TestCaseData_#*ModuleName*#.get(\"#*DataVariable*#\").get(0);";
			DataString=DataString.replace("#*DataVariable*#", DataVariable);
			DataString=DataString.replace("#*ModuleName*#", ModuleName);
			return DataString;
		}
		
		
		public String MainMethodCall(String MethodName,String DataVariable)
		{
			String DataString="#*MethodName*#(testCaseParam,#*DataVariable*#);";
			DataString=DataString.replace("#*DataVariable*#", DataVariable);
			DataString=DataString.replace("#*MethodName*#", MethodName);
			return DataString;
		}

		public boolean isVerifyCommand(String command) {
		Optional<KeywordMappingModel> result =TestRunSettings.keywordMappingModels.stream().filter(model -> model.IDE_Command.equals(command)).findFirst();
		KeywordMappingModel keywordMappingModel=result.get();
		
		
		
		return keywordMappingModel.isValidation;
		
		}
		
	
		
		
		
}
