package util;

import java.io.File;
import java.util.ArrayList;
import model.ide.Rootobject;
import model.ide.Command;

public class SeleniumIDEUtil {

	
	public ArrayList<Command> getCommands(String filePath) {
		ArrayList<Command> commandList = new ArrayList<Command>();
		try {
			ReadJSONData RJD = new ReadJSONData();
			Rootobject RO = RJD.SerializeJSONDatafromFile(filePath);
			commandList = RO.tests.get(0).commands;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return commandList;
	}

	public Rootobject getObjects(String filePath) {
		Rootobject rObject = new Rootobject();
		try {
			ReadJSONData RJD = new ReadJSONData();
			rObject = RJD.SerializeJSONDatafromFile(filePath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rObject;
	}
}
