package util;

import java.util.ArrayList;

import model.POMCommandModel;
import testSettings.TestRunSettings;

public class POMClassWriter {

	public void updateClassTemplate(POMCommandModel pomCommandModel)

	{
		ArrayList<String> classData= new ArrayList<String>();
		if(TestRunSettings.MasterData_Class.containsKey(pomCommandModel.ClassName)){
			classData=TestRunSettings.MasterData_Class.get(pomCommandModel.ClassName);
		}
		else
		{
			TestRunSettings.MasterData_Class.put(pomCommandModel.ClassName, classData);
		}
		
		for(String s:TestRunSettings.lst_ClassTemplate) {
			s=s.replace("#*ModuleName*#", pomCommandModel.ModuleName);
			s=s.replace("#*ClassName*#", pomCommandModel.ClassName);
			classData.add(s);
		}
		
		TestRunSettings.MasterData_Class.put(pomCommandModel.ClassName, classData);
	}
	
	
	public void updateFindByTemplate(ArrayList<POMCommandModel> pomCommandModels)

	{
		
		if(pomCommandModels.size()>0)
		{
		ArrayList<String> classData= new ArrayList<String>();
		if(TestRunSettings.MasterData_Class.containsKey(pomCommandModels.get(0).ClassName)){
			classData=TestRunSettings.MasterData_Class.get(pomCommandModels.get(0).ClassName);
		}
		else
		{
			TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		}
		
		for(POMCommandModel pomCommandModel:pomCommandModels)
		{
			classData.add(pomCommandModel.FindByString);
			classData.add(pomCommandModel.FindByString2);
			classData.add("");
		}

		TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		}
	}
	
	
	public void updateMethodDetails(ArrayList<POMCommandModel> pomCommandModels)

	{
		
		if(pomCommandModels.size()>0)
		{
		ArrayList<String> classData= new ArrayList<String>();
		if(TestRunSettings.MasterData_Class.containsKey(pomCommandModels.get(0).ClassName)){
			classData=TestRunSettings.MasterData_Class.get(pomCommandModels.get(0).ClassName);
		}
		else
		{
			TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		}
		
		for(POMCommandModel pomCommandModel:pomCommandModels)
		{
			for(String s:TestRunSettings.lst_ElementTemplate) {
				s=s.replace("#*ElementName*#", pomCommandModel.MethodName);
				s=s.replace("#*ElementCall*#", pomCommandModel.CommandDetails);
				classData.add(s);
			}
			classData.add("");
			
			
			if(pomCommandModel.isVerify==false)
			{
				for(String s:TestRunSettings.lst_ElementTemplate) {

					s=s.replace("#*ElementName*#", pomCommandModel.VerifyMethodName);
					s=s.replace("#*ElementCall*#", pomCommandModel.VerifyCommandDetails);
					classData.add(s);
				}
			}
			classData.add("");
		}

		TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		
		}
	}
	
	
	public void updateMainMethod_1(ArrayList<POMCommandModel> pomCommandModels)

	{
		if(pomCommandModels.size()>0)
		{
		ArrayList<String> classData= new ArrayList<String>();
		if(TestRunSettings.MasterData_Class.containsKey(pomCommandModels.get(0).ClassName)){
			classData=TestRunSettings.MasterData_Class.get(pomCommandModels.get(0).ClassName);
		}
		else
		{
			TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		}
		
		
			for(String s:TestRunSettings.lst_MainMethodTemplate1) {
				s=s.replace("#*MainMethodName*#", pomCommandModels.get(0).MainMethodName);
				s=s.replace("#*ModuleName*#", pomCommandModels.get(0).ModuleName);
			
				classData.add(s);
			}
			classData.add("");
		
		TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		
		}
		
	}
	
	
	public void updateMainMethod_Data(ArrayList<POMCommandModel> pomCommandModels)

	{
		if(pomCommandModels.size()>0)
		{
		ArrayList<String> classData= new ArrayList<String>();
		if(TestRunSettings.MasterData_Class.containsKey(pomCommandModels.get(0).ClassName)){
			classData=TestRunSettings.MasterData_Class.get(pomCommandModels.get(0).ClassName);
		}
		else
		{
			TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		}
		
		
		for(POMCommandModel pomCommandModel:pomCommandModels)
		{
			classData.add(pomCommandModel.MainMethodVariable);
		}
			classData.add("");

		for(POMCommandModel pomCommandModel:pomCommandModels)
			{
			if(pomCommandModel.isVerify==false)
			{
				classData.add(pomCommandModel.VerifyMethodVariable);
			}
			}
				classData.add("");
	
				for(POMCommandModel pomCommandModel:pomCommandModels)
				{
					classData.add(pomCommandModel.MainMethodCall);
				}
					classData.add("");


					for(POMCommandModel pomCommandModel:pomCommandModels)
					{
						if(pomCommandModel.isVerify==false)
						{
						classData.add(pomCommandModel.MainMethodVerifyCall);
						}
					}
						classData.add("");

				
		TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		
		}
		
	}
	
	
	public void updateMainMethod_2(ArrayList<POMCommandModel> pomCommandModels)

	{
		if(pomCommandModels.size()>0)
		{
		ArrayList<String> classData= new ArrayList<String>();
		if(TestRunSettings.MasterData_Class.containsKey(pomCommandModels.get(0).ClassName)){
			classData=TestRunSettings.MasterData_Class.get(pomCommandModels.get(0).ClassName);
		}
		else
		{
			TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		}
		
		
		
			for(String s:TestRunSettings.lst_MainMethodTemplate2) {
					s=s.replace("#*MainMethodName*#", pomCommandModels.get(0).MainMethodName);
				
				
							classData.add(s);
			}
			classData.add("");
		
		TestRunSettings.MasterData_Class.put(pomCommandModels.get(0).ClassName, classData);
		
		}
		
	}
	
}
