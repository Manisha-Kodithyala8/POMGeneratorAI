package testSettings;
import java.util.Properties;

import constants.prjConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class initializeTestSettings {

	  Properties prop=new Properties();
	
	public void initializeSettings() throws IOException, Exception
	{
		 prop=loadProperties(prjConstants.getConfig());
		TestRunSettings.homePath = prjConstants.getPrjPath();
		TestRunSettings.resourcePath =prjConstants.getResourcesPath();
		TestRunSettings.configDirPath =prjConstants.getConfigDir();

		TestRunSettings.KeywordMappingFile=TestRunSettings.configDirPath+prop.getProperty("KeywordMappingFile");
		TestRunSettings.KeywordMappingSheet=prop.getProperty("KeywordMappingSheet");
		TestRunSettings.KeywordMappingColumnName=prop.getProperty("KeywordMappingColumnName");
		TestRunSettings.KeywordMappingColumnValue=prop.getProperty("KeywordMappingColumnValue");
		
		TestRunSettings.ConfigurationFile=TestRunSettings.configDirPath+prop.getProperty("ConfigurationFile");
		TestRunSettings.ConfigurationSheet=prop.getProperty("ConfigurationSheetName");
		TestRunSettings.ConfigurationSheet_Specs=prop.getProperty("ConfigurationSheetName_Specs");
		TestRunSettings.ConfigFileColumnName=prop.getProperty("ConfigFileColumnName");
		TestRunSettings.ConfigFileColumnValue=prop.getProperty("ConfigFileColumnValue");
	
		TestRunSettings.InputFileDir_JSON=TestRunSettings.resourcePath+prop.getProperty("InputFileDir_JSON");
		TestRunSettings.InputFileDir_Specs=TestRunSettings.resourcePath+prop.getProperty("InputFileDir_Specs");
		
		TestRunSettings.OutputFileDir=TestRunSettings.resourcePath+prop.getProperty("OutputFileDir");
		TestRunSettings.TemplateDir=TestRunSettings.resourcePath+prop.getProperty("TemplateDir");
		TestRunSettings.ClassTemplateFile=TestRunSettings.TemplateDir+prop.getProperty("ClassTemplateFile");
		
		TestRunSettings.ElementMethodTemplateFile=TestRunSettings.TemplateDir+prop.getProperty("ElementMethodTemplateFile");

		TestRunSettings.MainMethodTemplateFile1=TestRunSettings.TemplateDir+prop.getProperty("MainMethodTemplateFile1");
		TestRunSettings.MainMethodTemplateFile2=TestRunSettings.TemplateDir+prop.getProperty("MainMethodTemplateFile2");
		
		TestRunSettings.FindsByTemplateFile=TestRunSettings.TemplateDir+prop.getProperty("FindsByTemplateFile");
		TestRunSettings.ElementData=prop.getProperty("ElementData");
		TestRunSettings.ElementMethod=prop.getProperty("ElementMethod");
		
		
		TestRunSettings.DefaultCommand=prop.getProperty("DefaultCommand");
		TestRunSettings.VerifyCommand=prop.getProperty("VerifyCommand");
		
	}
	
    public Properties loadProperties(String Filepath) throws IOException,Exception
    {
    	

        FileInputStream propsInput = new FileInputStream(Filepath);

        Properties prop = new Properties();

        prop.load(propsInput);

       
    	return prop;
    }

}
