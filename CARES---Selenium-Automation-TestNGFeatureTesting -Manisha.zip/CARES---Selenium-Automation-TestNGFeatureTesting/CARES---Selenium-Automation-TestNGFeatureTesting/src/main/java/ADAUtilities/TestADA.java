package ADAUtilities;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpResponse;

import com.deque.html.axecore.providers.FileAxeScriptProvider;
import com.deque.html.axecore.results.Node;
import com.deque.html.axecore.results.Results;
import com.deque.html.axecore.results.Rule;
import com.deque.html.axecore.selenium.AxeBuilder;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestADA {
//	static List<String> tags = Arrays.asList("best-practice"); 
//	static List<String> rules = Arrays.asList(); 
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		// Because Firefox use the geckodriver, so set the geckodriver.exe path to the system property webdriver.gecko.driver's value.
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ronashah\\Desktop\\project\\GPS\\Workspace\\GPSCommon\\GPSAutomation\\GPSCommon\\src\\main\\resources\\BrowserDrivers\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.setAcceptInsecureCerts(true);
  //      options.setHeadless(true);
       // Create the FirefoxDriver object with the above FirefoxOptions object and start the Firefox web browser.
        WebDriver driver = new ChromeDriver(options);
//		  System.setProperty("webdriver.gecko.driver", "C:\\Users\\ronashah\\Desktop\\project\\GPS\\Workspace\\GPSCommon\\GPSAutomation\\GPSCommon\\src\\main\\resources\\BrowserDrivers\\geckodriver.exe");
//          
//	       // Create the FirefoxDriver object with the above FirefoxOptions object and start the Firefox web browser.
//	        WebDriver driver = new FirefoxDriver();
        driver.manage().window().maximize();
  //      driver.get("http://usmumnymecmproj:9081/LoginServlet?ACTION=LOGIN&PAGE_ID=SELOG&fromIndex=true");
        driver.get("https://10.187.55.103:8443/LoginServlet?ACTION=LOGIN&PAGE_ID=SELOG&fromIndex=true");
        Thread.sleep(5000);

        ADAScan(driver,"Login");
        
        driver.findElement(By.xpath("//input[@name='userId']")).sendKeys("adarsgupta");
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("password");
        driver.findElement(By.xpath("//input[@name='LoginBtn']")).click();
      
        Thread.sleep(10000);
        driver.findElement(By.xpath("//div[@id='ARTOP']")).click();

        Thread.sleep(3000);
        ADAScan(driver,"ARStep1");
        
	    // Close the WebDriver
	    driver.quit();
	}

	public static void ADAScan(WebDriver driver,String ScreenName)
	{
		    String strHelp = "";
	        String strImpact = "";
	        String strDescription = "";
	        String strHelpUrl = "";
	        String strId = "";
	        String strTags = "";
	     
	        StringBuilder axeResults = new StringBuilder();
	     

//	             Commons.waitTillPageLoad(driver, wait);
//	             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        		
	               AxeBuilder builder = new AxeBuilder();
	               String timeoutFilePath = "C:\\Users\\ronashah\\Desktop\\project\\GPS\\Workspace\\GPSCommon\\GPSAutomation\\GPSCommon\\src\\main\\resources\\axe.min.js";
	               axeResults.append("Screen Name,Help,Impact,Description,Help Url,Id,Tags");
	               axeResults.append(System.lineSeparator());
	               try {
	                     FileAxeScriptProvider axeScriptProvider;
	                     axeScriptProvider = new FileAxeScriptProvider(timeoutFilePath);
	                      builder.setAxeScriptProvider(axeScriptProvider);
//	            	   	builder.withTags(tags);
	                  
//	            	   	builder.withRules(rules);
	                     builder.include(Arrays.asList("html"));
	                     Results result = builder.analyze(driver);
	                     List<Rule> violations = result.getViolations();
	                     System.out.println("ScreenName"+ ScreenName + result.getError());
	                     System.out.println("ScreenName"+ result.getErrorMessage());
	                     
	                     
	                     String url=driver.getCurrentUrl();
	                     String PageID = url.substring(url.lastIndexOf("/") + 1, url.length());
	  
	                     System.out.println("Violation of the Screen "+ScreenName+":"+violations.size());

	                     if (violations.size() == 0) {
	                         
	                            System.out.println("No violations found: " + ScreenName + " with PageID: " + PageID+"No violations found: " + ScreenName);
	                                        
	                     } 
	                     else {
	                    	 System.out.println("ADA violations exists on the page: " + ScreenName + " with PageID: " + PageID+" Violations found");
	                                 
	                     }

	                     for (Rule element : violations) {
	                            strHelp = element.getHelp();
	                            strImpact = element.getImpact();
	                            strDescription = "\"" + element.getDescription() + "\"";
	                            strHelpUrl = element.getHelpUrl();
	                            strId = element.getId();
	                            strTags = "\"" + String.join(",", element.getTags()) + "\"";
//	                            if (!strTags.contains("cat"))
//	                            {
	                            axeResults.append(ScreenName + "," + strHelp + "," + strImpact + "," + strDescription + ","
	                                         + strHelpUrl + "," + strId + "," + strTags);
	                            axeResults.append(System.lineSeparator());
//	                            }
	                            if (element.getNodes() != null && !element.getNodes().isEmpty()) {
	                                  for (Node item : element.getNodes()) {
	                                         if (item.getHtml().trim().length() > 0 && item.getTarget().toString().trim().length() > 0) {
	                                               String htmlContent = item.getHtml();
	                                              htmlContent = htmlContent.replace(",", "_");   
	                                              htmlContent = htmlContent.replaceAll("\\s", "");   
	                                               axeResults.append(ScreenName + "," + strHelp + "," + strImpact + "," + strDescription
	                                                             + "," + strHelpUrl + "," + "\"" + htmlContent + "\"" + "," + "\""
	                                                             + item.getTarget() + "\"");
	                                                axeResults.append(System.lineSeparator());
	                                         }
	                                  }
	                            }
	                     }
//	                  
	                     BufferedWriter writer = null;
	                     
	                     File file = new File("C:\\ADATestReports" + "\\AccessibilityReport_"
	                                               + ScreenName + ".csv");
	                     try {
	                            writer = new BufferedWriter(new FileWriter(file));
	                            writer.write(axeResults.toString());
	                     } catch (Exception e1) {

	                     } finally {
	                            if (writer != null) {
	                                  try {
	                                         writer.close();
	                                  } catch (IOException e) {
	                                         // TODO Auto-generated catch block
	                                         e.printStackTrace();
	                                  }
	                            }
	                     }
	               } catch (Exception e) {
	                     // TODO Auto-generated catch block
	                     e.printStackTrace();
	               }

	}
}	
