package CommonUtilities.Common.ActionKeywords;

//import io.appium.java_client.android.AndroidElement;

public class AndroidKeywords
{

    private static final AndroidKeywords _instance = new AndroidKeywords();
    
    public static AndroidKeywords Instance()
    {
            return _instance;

    }


}
