package CommonUtilities.Common.ActionKeywords;


//import io.appium.java_client.ios.IOSElement;

public class IOSKeywords
{

    private static final IOSKeywords _instance = new IOSKeywords();
    
    public static IOSKeywords Instance()
    {
            return _instance;

    }
    

}
