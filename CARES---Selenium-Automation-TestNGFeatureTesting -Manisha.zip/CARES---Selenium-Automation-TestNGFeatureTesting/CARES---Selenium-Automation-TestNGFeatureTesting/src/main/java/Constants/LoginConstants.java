package Constants;

import java.util.ArrayList;
import java.util.HashMap;

public class LoginConstants
{
    
	public static String URL = "";
	public static String CSusername = "";
    public static String CSpassword = "";
    

        
        
    public void loadLoginData(HashMap<String, ArrayList<String>> LoginData)
    {

//        URL = LoginData.get("URL").get(0);
//        CSusername = LoginData.get("CSusername").get(0);
//        CSpassword = LoginData.get("CSpassword").get(0);

        

    }
}