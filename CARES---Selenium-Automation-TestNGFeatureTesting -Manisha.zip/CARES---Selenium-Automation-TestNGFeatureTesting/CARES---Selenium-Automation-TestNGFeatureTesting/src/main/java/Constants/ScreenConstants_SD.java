package Constants;

public class ScreenConstants_SD {

	public static final String SauceLogin = "SauceLogin";
	public static final String SauceProduct = "SauceProduct";
	public static final String SauceDetails = "SauceDetails";
	public static final String SauceCheckout = "SauceCheckout";
	public static final String SauceConfirmation = "SauceConfirmation";
	
	
	public static final String Login = "Login";

	public static final String Headers_Page = "Header";
	public static final String Screenings_Page = "Screenings";
	public static final String InitialScreenings_Page = "InitialScreening";
	
}
