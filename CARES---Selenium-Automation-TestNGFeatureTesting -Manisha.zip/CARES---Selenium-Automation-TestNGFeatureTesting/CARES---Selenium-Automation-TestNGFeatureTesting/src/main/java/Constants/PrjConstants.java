package Constants;

import java.util.ArrayList;
import java.util.Arrays;

public class PrjConstants {

	public static final String ConfigFile="/config.properties";
//	public static final String Prereq = "_Prereq";
	public static final long Delay = 10;
	
//	public static final ArrayList<String> ProgramCodes = new ArrayList<String>(Arrays.asList("KT", "SN", "MA","QP","KC","CC"));
//	public static final long Delay = 10;
	
//	public  enum ProgramType{MA,KTAP,SNAP,CCAP,SS,QP};
//	public static String InitializeMethod="InitializePage";
}
