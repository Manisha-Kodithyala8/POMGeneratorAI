package Constants;

public class ModuleConstants_SD {

	public static final String SD = "SD";

}
