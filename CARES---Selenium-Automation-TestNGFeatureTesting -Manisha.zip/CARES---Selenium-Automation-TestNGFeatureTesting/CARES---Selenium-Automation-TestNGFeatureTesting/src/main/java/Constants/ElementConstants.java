package Constants;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class ElementConstants 
{
	
	
	
    public static final By WP_PageLoader=By.xpath("//*[@src='/Content/themes/default/images/load_icon.gif']");
    public static final By WP_PageTitle=By.xpath("//*[@alt='Print' and @tabindex='0' and @class='vertical-align-middle cursor-hand height-20px printDoc']/.././../div/h2/span/label");
    public static final By WP_CitizenSearchLoader=By.xpath("//*[@id='loadingIconId']");
    public static final By Shopping_PageLoader=By.xpath("//*[@alt='Spinner']");
    
    
    public static final By KLOCS_PageTitle=By.xpath("//*[@class='pageHeader padding-left-5px']");
  

    //benefits/resource/1623835252000/sspLoadingIcon/sspLoadingImage/loadingIcon.gif
    public static final By BTN_AR_ReadOnly_Next=By.xpath("(//input[@class='btn btn-primary active btnReadOnlyNext'])[1]");
    public static final By BTN_EditRecord=By.xpath("(//*[@src='/Images/edit_blue.png'])[1]");

    public static final By LBL_NoAccess=By.xpath("//*[@id='mainDiv']//preceding-sibling::div[text()='You have no access to this page!']");
    public static final By WP_Next_BTN=By.xpath("(//*[@class='btn btn-primary active btnNext'])[1]");
    public static final By WP_Previous_BTN=By.xpath("//input[@class='btn btn-primary active btnPrevious editWarning']");
    
   //PLAN MANAGEMENT Portal
    public static final By PM_PageHeader=By.xpath("//*[@class='pageHeader']");
    public static String PM_RedBannerError="//div[@class='message']/div";
    
    //MWMA
  //*[@id='loadingIconId']
    public static final By MWMA_PageLoader =By.xpath("(//*[@id='loadingIconId' and @class='loadingIcon'])[2]");
    
    //TABLE ELEMENT CONSTANT
    public static String WP_TableConstant="//*[@class='dataTables_wrapper no-footer']/table/tbody/tr/td";
    public static String WP_TableHeadingConstant="//*[@class='dataTables_wrapper no-footer']/table/thead/tr/th";
    public static String WP_SummaryTableHeadingConstant="/ancestor::div[1]/table/thead/tr/th";
    
    //SUMMARY TABLE ELEMENT CONSTANTS
    public static String WP_TableConstant_LiquidResourceSummary="//*[@class='dataTables_wrapper no-footer' and contains(@id,'LiquidResource')]/table/tbody/tr/td";
    public static String WP_TableConstant_EarnedIncomeSummary="//*[@class='EarnedIncome']/div/div/table/tbody/tr/td";
    public static String WP_TableConstant_UnEarnedIncomeSummary="//*[@class='UnearnedIncome']/div/div/table/tbody/tr/td";
    public static String WP_TableConstant_SelfEmploymentIncomeSummary="//*[@class='SelfEarnedIncome']/div/div/table/tbody/tr/td";

    public static String WP_TableConstant_ChildSupportExpenseSummary="//*[@class='dataTables_wrapper no-footer' and contains(@id,'childSupportAlimonyExpense')]/table/tbody/tr/td";
    public static String WP_TableConstant_MedicalExpenseSummary="//*[@class='dataTables_wrapper no-footer' and contains(@id,'medicalExpense')]/table/tbody/tr/td";
    public static String WP_TableConstant_SUAExpenseSummary="//*[@class='dataTables_wrapper no-footer' and contains(@id,'UtilityExpenseAllowance')]/table/tbody/tr/td";
}
