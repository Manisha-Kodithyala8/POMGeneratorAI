package TestSettings;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;
import CommonUtilities.Common.POI_ReadExcel;


public class SessionData {


	public static String TimeTravelDate= "";
	public static String FirstDayofMonth="";
	public static String LastDayofMonth="";
	public static String FirstDayofPreviousMonth="";
	public static String LastDayofPreviousMonth="";
	public static String FirstDayofNextMonth="";
	public static String LastDayofNextMonth="";
	public static String FirstDayofCustomMonth = "";
	public static String LastDayofFutureCustomMonth="";
	public static String FirstDayofPastCustomMonth="";
	public static String LastDayofPastCustomMonth="";												

	
	public static String CaseNumber="";
	public static String RandomData="";
	public static String PnPRefferalCode="";
	public static String CoPayAmount="";
	public static String Amount="";	
	public static String CalculationID="";

	public static String TaskId="";
	public static HashMap<String,String> DBPlaceHolder= new HashMap<String,String>();
	public static HashMap<String,String> SessionKeys= new HashMap<String,String>();
	public static HashMap<String, ArrayList<String>> LoginData = new HashMap<String, ArrayList<String>>();

	public static String LoggingConnectionString="";
	public static String LoggingTableName="";
	public static String ApplicationNumber="";
	
	
	public static void setDBPlaceHolderData(String DBKey, String DBValue, TestCaseParam testCaseParam)
	{
		DBPlaceHolder.put(testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+"_"+ testCaseParam.Browser + "_"+ testCaseParam.Iteration+"_"+DBKey,DBValue);

	}
	

	public static String getDBPlaceHolderData(String DBKey, TestCaseParam testCaseParam)
	{
		return DBPlaceHolder.get(testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+"_"+ testCaseParam.Browser + "_"+ testCaseParam.Iteration+"_"+DBKey);

	}

	
	public static void setSessionData(TestCaseParam testCaseParam,String Key, String Value)
	{
		SessionKeys.put(testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+"_"+ testCaseParam.Browser + "_"+ testCaseParam.Iteration+"_"+Key,Value);
	}
	

	public static String getSessionData(TestCaseParam testCaseParam,String Key)
	{
		return SessionKeys.get(testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+"_"+ testCaseParam.Browser + "_"+ testCaseParam.Iteration+"_"+Key);		
	}
	
	public static String replaceSessionData(TestCaseParam testCaseParam,String Key)
	{
		
		for(String s : SessionKeys.keySet())
		{
			s= s.replace(testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+"_"+ testCaseParam.Browser + "_"+ testCaseParam.Iteration+"_", "");
			if(Key.contains(s))
			{
				Key=Key.replace(s, SessionKeys.get(testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+"_"+ testCaseParam.Browser + "_"+ testCaseParam.Iteration+"_"+s));
			}
		}
		return Key;		
	}
	
	
	
	
	public static boolean SessionDataContainsKey(TestCaseParam testCaseParam,String Key)
	{
		if( SessionKeys.containsKey(testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+"_"+ testCaseParam.Browser + "_"+ testCaseParam.Iteration+"_"+Key))
		{
			return true;
		}
		else
		{
			return false;			
		}
	}
	
	public static String getLoginData(String Key)
	{
		return LoginData.get(Key).get(0);
	}
	
	
	public static String getTimeTravelDate() 
	{
		return TimeTravelDate;
	}
	
	public static void setTimeTravelDate(String ttdate) 
	{
		TimeTravelDate=ttdate;
	}
	
	public static String getCalculationID() 
	{
		return CalculationID;
	}
	
	public static void setCalculationID(String CalcID) 
	{
		CalculationID=CalcID;
	}
	
	public static String getFirstDayofCurrentMonth() 
	{
		return FirstDayofMonth;
	}
	
	public static String getTaskId() 
	{
		return TaskId;
	}

	
	public static void setTaskID(String taskID) 
	{
		TaskId=taskID;
	}
	
	
	

	public static String getLastDayofCurrentMonth() 
	{
		return LastDayofMonth;
	}

	
	public static void setFirstDayofCurrentMonth(String incomeDate) 
	{
		FirstDayofMonth=incomeDate;
	}
	
	public static String getFirstDayofCustomMonth() 
	{
		return FirstDayofCustomMonth;
	}
	public static void setFirstDayofCustomMonth(String incomeDate) 
	{
		FirstDayofCustomMonth=incomeDate;
	}
	
	public static String getFirstDayofPreviousMonth() 
	{
		return FirstDayofPreviousMonth;
	}

	
	public static String getLastDayofPreviousMonth() 
	{
		return LastDayofPreviousMonth;
	}

	public static void setFirstDayofPreviousMonth(String incomeDate) 
	{
		FirstDayofPreviousMonth=incomeDate;
	}
	
	
	public static String getFirstDayofNextMonth() 
	{
		return FirstDayofNextMonth;
	}

	
	public static String getLastDayofNextMonth() 
	{
		return LastDayofNextMonth;
	}

	public static String getCaseNumber() 
	{
		return CaseNumber;
	}

	
	public static String getFirstMonth() 
	{
		return TimeTravelDate;
	}

	
	public static String IncreamentDateByMonths(int NoOfMonths) 
	{
		LocalDate LDate=LocalDate.parse(TimeTravelDate);
		LDate=LDate.plusMonths(NoOfMonths);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("YYYY-MM-DD");
        return dtf.format(LDate);
	}

	
	public static String IncreamentDateByDays(int NoOfDays) 
	{
		LocalDate LDate=LocalDate.parse(TimeTravelDate);
		LDate=LDate.plusDays(NoOfDays);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("YYYY-MM-DD");
        return dtf.format(LDate);
		
	}
	
	public static String IncreamentDateByYears(int NoOfYears) 
	{
		LocalDate LDate=LocalDate.parse(TimeTravelDate);
		LDate=LDate.plusMonths(NoOfYears);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("YYYY-MM-DD");
        return dtf.format(LDate);
		
	}
	
	public static String getRandomData() 
	{
		return RandomData;
	}

	
	
	public static void setRandomData(String Data) 
	{
		RandomData=Data;
	}
	
	
	public static void setPnPReferralCode(TestCaseParam testCaseParam,String PnpReferralCode) 
	{
		PnPRefferalCode=PnpReferralCode;
	}
	public static String getPnPReferralCode() 
	{
		return PnPRefferalCode;
	}
	public static void setCoPayAmount(TestCaseParam testCaseParam,String coPayAmount) 
	{
		CoPayAmount=coPayAmount;
	}
	public static String getCoPayAmount() 
	{
		return CoPayAmount;
	}
	
}
