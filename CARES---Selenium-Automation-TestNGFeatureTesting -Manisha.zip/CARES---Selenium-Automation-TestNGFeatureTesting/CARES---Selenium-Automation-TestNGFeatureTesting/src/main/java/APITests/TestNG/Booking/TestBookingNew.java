package APITests.TestNG.Booking;

import java.util.ArrayList;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import APIUtilities.APIHelpers.APIController;
import APIUtilities.APIHelpers.TestCaseHelper;
import APITests.TestNG.Common.APITestNGCommon;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APITestSettings;

public class TestBookingNew extends APITestNGCommon {


	 @Test(groups = { "Booking" })
	    public void CreateToken() throws Exception
	    {
		 
		 TestCaseHelper testCaseHelper= new TestCaseHelper();
		 
		 testCaseHelper.getTestCaseDetails(APITestSettings.apiTestSettings.APITestSuiteFileName, APITestSettings.apiTestSettings.APITestSuiteSheetName);
		 
		 testCaseHelper.ExecuteTestCases();
		 
	    }


}
