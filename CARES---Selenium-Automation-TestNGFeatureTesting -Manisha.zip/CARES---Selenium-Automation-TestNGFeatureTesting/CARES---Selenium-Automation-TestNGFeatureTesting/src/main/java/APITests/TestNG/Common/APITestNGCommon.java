package APITests.TestNG.Common;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;

import APIUtilities.APIHelpers.APIController;
import ReportUtilities.Common.ReportCommon;
import InitializeScripts.InitializeTestSettings;
import ReportUtilities.Model.TestCaseParam;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APITestSettings;

public class APITestNGCommon {

	
	@BeforeSuite
    public static void TestRunSetUp() throws Exception
    {
	
		  Path currentRelativePath = Paths.get(""); 
		  String PrjPath=currentRelativePath.toAbsolutePath().toString();

		  
		  	InitializeTestSettings initObj = new InitializeTestSettings();
			initObj.LoadConfigData(PrjPath);
			
		
			
		
    }
	
	
	public void executeAPI(TestCaseParam testCaseParam,  String APIName,String APIModuleName,String APIFileName) throws Exception
    {
		 
 	
	 	String FilePath =APITestSettings.apiTestSettings.APIDirectory + "\\" + APIFileName;
	 
		APIController apiController = new APIController();
		ArrayList<APIReportModel> reportData=apiController.ExecuteAPI(testCaseParam.TestCaseName,APIModuleName,APIName,testCaseParam.Browser,String.valueOf(testCaseParam.Iteration),FilePath);

		  ReportCommon TestStepLogDetails = new ReportCommon(); 
	         //TestStepLogDetails.logModuleAndAPIDetails(testCaseParam,APIModuleName, APIName);
	         
	         LocalDateTime startTime =LocalDateTime.now();
	         
//	         TestStepLogDetails.logAPITestStepDetails(testCaseParam, "URL  ==> "+ reportData.get(0).URL , startTime, "Info" );
//	         TestStepLogDetails.logAPITestStepDetails(testCaseParam, "Request  ==>  <br> "+ reportData.get(0).Request , startTime, "Info" );
//	         TestStepLogDetails.logAPITestStepDetails(testCaseParam, "Response  ==> <br> "+ reportData.get(0).Response , startTime, "Info" );

	         
	         for(APIReportModel apiReportModel : reportData)
	         {
//	        	   TestStepLogDetails.logAPITestStepDetails(testCaseParam, "Validation :  "+ apiReportModel.XPathJSONKey , startTime, "Info" );
//	        	   TestStepLogDetails.logVerificationDetailsAPI( testCaseParam,  APIName, startTime, apiReportModel.TestStepResult, apiReportModel.ExpectedResponse, apiReportModel.ActualResponse);
	         }

    }
}
