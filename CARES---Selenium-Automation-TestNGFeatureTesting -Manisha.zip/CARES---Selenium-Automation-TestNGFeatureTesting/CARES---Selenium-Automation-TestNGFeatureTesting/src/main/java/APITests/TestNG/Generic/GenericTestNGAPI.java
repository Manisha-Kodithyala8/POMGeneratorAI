package APITests.TestNG.Generic;

import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import APIUtilities.APIHelpers.APIController;

import APIUtilities.Models.APIReportModel;


import APIUtilities.TestSettings.APITestSettings;

import ReportUtilities.Model.TestCaseParam;
import TestSettings.TestRunSettings;
import UITests.TestNG.Common.TestNGCommon;
import APIUtilities.APIHelpers.APIReport;
public class GenericTestNGAPI extends TestNGCommon {
    TestCaseParam testCaseParam = new TestCaseParam();
    APIReport apiReport=new APIReport();
	public GenericTestNGAPI(){

	}

	@Parameters({"TestCase","Module","UserStory","APIName","Iteration","APIFileName"})
	@Test
	public void ExecuteTestByAPI(String TestCase,String Module, String UserStory, String APIName,String Iteration,String APIFileName) throws Exception
	{

		
		 	testCaseParam.TestCaseName = TestCase;
	        testCaseParam.ModuleName = Module;
	        testCaseParam.Browser = TestRunSettings.Browser;
	        testCaseParam.TestCaseDescription = testCaseParam.TestCaseName;
	        InitializeTestCase(testCaseParam);

		String FilePath =APITestSettings.apiTestSettings.APIDirectory + "\\" + APIFileName;

			APIController apiController = new APIController();
			ArrayList<APIReportModel> reportData=apiController.ExecuteAPI(TestCase,Module,APIName,TestRunSettings.Browser, Iteration,FilePath);
			apiReport.AddTestStep(testCaseParam, reportData);
		
	}
	
	
	@AfterMethod
    public void TearDownMethod()
    {
    	EndTestCase(testCaseParam);
    }


}
