package APITests.TestNG.Booking;

import java.util.ArrayList;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import APIUtilities.APIHelpers.APIController;
import APIUtilities.APIHelpers.TestCaseHelper;
import APITests.TestNG.Common.APITestNGCommon;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APITestSettings;
import TestSettings.TestRunSettings;

public class TestBooking extends APITestNGCommon {

	 @Parameters({"TestCase","Module","UserStory","APIName","Iteration","APIFileName"})
	 @Test
	    public void CreateToken(String TestCase,String Module, String UserStory, String APIName,String Iteration,String APIFileName) throws Exception
	    {
		 
		 TestCaseHelper testCaseHelper= new TestCaseHelper();
		 
		 testCaseHelper.getTestCaseDetails(APITestSettings.apiTestSettings.APITestSuiteFileName, APITestSettings.apiTestSettings.APITestSuiteSheetName);
		 
		 testCaseHelper.ExecuteTestCases();
		 
	    }


}
