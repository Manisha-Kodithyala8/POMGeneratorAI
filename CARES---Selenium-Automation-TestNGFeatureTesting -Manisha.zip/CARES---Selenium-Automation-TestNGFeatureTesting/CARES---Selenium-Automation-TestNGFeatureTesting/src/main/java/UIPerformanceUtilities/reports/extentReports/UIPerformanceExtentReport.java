package UIPerformanceUtilities.reports.extentReports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.model.ExceptionInfo;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


import TestSettings.TestRunSettings;

import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.apache.poi.util.IOUtils;
import UIPerformanceUtilities.constants.UIPerformanceConstants;
import UIPerformanceUtilities.model.EntryModel;
import UIPerformanceUtilities.model.UIPerformanceModel;

import java.awt.BorderLayout;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.sql.Date;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.*;

public class UIPerformanceExtentReport
{

	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;

	public static HashMap<String, String> Sheet_ScreenHashMap = new HashMap<String,String>();
	public static HashMap<String, String> ScreenNameSheetNameMap = new HashMap<String, String>();
	public static HashMap<String, Integer> screenNameTotalTestCases = new HashMap<String, Integer>();
	public static HashMap<String, ArrayList<String>> screenNameToTestCasesMap = new HashMap<String,ArrayList<String>>();
	public static  HashMap<String,String> sheets=new HashMap<String,String>();


	// Create a workbook
	static XSSFWorkbook workbook = new XSSFWorkbook();




	public void CreateExtentReport_Category(String ReportPath,String BrowserName, String ExecutedBy) throws Exception
	{

		try
		{
		try
			{
				File dir = new File(ReportPath);
				if (!dir.exists()) dir.mkdirs();
				System.out.println("Directory Created ===> "+ReportPath);

			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw e;

			}
			String ReportFilePath = ReportPath + "/UIPerformance.html"; 
			int count=1;
			XSSFSheet dashboardSheet = workbook.createSheet("Dashboard");
			ExtentHtmlReporter htmlReporter_lcl = new ExtentHtmlReporter(ReportFilePath);
			ExtentReports extent_lcl = new ExtentReports();
			try
			{
				extent_lcl.attachReporter(htmlReporter_lcl);

			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());
				throw e;	
			}
			//extent_lcl.setSystemInfo("Username", ExecutedBy);


			if (UIPerformanceConstants.UIPerfData != null)
			{


				for (String  ScreenName : UIPerformanceConstants.UIPerfData.keySet())
				{
					String result = "";
					ExtentTest test = extent_lcl.createTest(ScreenName);

					test.assignCategory(BrowserName);

					ArrayList<UIPerformanceModel> uiPerfModels=UIPerformanceConstants.UIPerfData.get(ScreenName);


					for(UIPerformanceModel uiPerfModel:uiPerfModels)
					{
						ExtentTest MultiTCNode=test.createNode("Test Case : "+ uiPerfModel.TestCaseName + "  :: ModuleName : " + uiPerfModel.ModuleName + " :: BrowserName : " + uiPerfModel.BrowserName);	

						if(uiPerfModel.ResponseTimeMillisecond<=UIPerformanceConstants.ExpectedResponseTimeinMilliSecond)
						{
							for(String s:uiPerfModel.entries) {
								result=result+"\n "+ s;
							}
							MultiTCNode.pass(" SourceScreen : " + uiPerfModel.SourceScreen+ "<br>  "
									+ " DestinationScreen : " + uiPerfModel.DestinationScreen+ "<br>  "
									+ " Source_DestinationScreen : " + uiPerfModel.Source_DestinationScreen+ "<br>  "
									+ " ResponseTime : " + uiPerfModel.ResponseTime+ "<br>  "
									+ " ResponseTimeMillisecond : " + uiPerfModel.ResponseTimeMillisecond+ "<br>  "
									+ " TestCaseName : " + uiPerfModel.TestCaseName+ "<br>  "
									+ " ModuleName : " + uiPerfModel.ModuleName+ "<br>  "
									+ " BrowserName : " + uiPerfModel.BrowserName+ "<br>  "
									+ " StartTime : " + uiPerfModel.StartTime+ "<br>  "
									+ " EndTime : " + uiPerfModel.EndTime+ "<br>  "
									+ " PageLoadTime : " + uiPerfModel.PageLoadTime+ "<br> "
									+ " TTFB : " +uiPerfModel.TTFB+ "<br> "
									+ " EndToEndResponseTime : "+uiPerfModel.EndtoendRespTime+ "<br> "
									);

							//MultiTCNode.info(WriteDataToTextFile(ReportPath, "CSV_DetailedReport_"+uiPerfModel.Source_DestinationScreen+"_"+uiPerfModel.TestCaseName+ "_"+  uiPerfModel.ModuleName+ "_"+  uiPerfModel.BrowserName, result,".csv" ));
							//MultiTCNode.info(WriteDataToTextFile(ReportPath, "TXT_DetailedReport_"+uiPerfModel.Source_DestinationScreen+"_"+uiPerfModel.TestCaseName+ "_"+  uiPerfModel.ModuleName+ "_"+  uiPerfModel.BrowserName, result,".txt" ));


						}
						else
						{

							for(String s:uiPerfModel.entries) {
								result=result+"\n "+ s;
							}
							MultiTCNode.fail(" SourceScreen : " + uiPerfModel.SourceScreen+ "<br>  "
									+ " DestinationScreen : " + uiPerfModel.DestinationScreen+ "<br>  "
									+ " Source_DestinationScreen : " + uiPerfModel.Source_DestinationScreen+ "<br>  "
									+ " ResponseTime : " + uiPerfModel.ResponseTime+ "<br>  "
									+ " ResponseTimeMillisecond : " + uiPerfModel.ResponseTimeMillisecond+ "<br>  "
									+ " TestCaseName : " + uiPerfModel.TestCaseName+ "<br>  "
									+ " ModuleName : " + uiPerfModel.ModuleName+ "<br>  "
									+ " BrowserName : " + uiPerfModel.BrowserName+ "<br>  "
									+ " StartTime : " + uiPerfModel.StartTime+ "<br>  "
									+ " EndTime : " + uiPerfModel.EndTime+ "<br>  "
									+ " PageLoadTime : " + uiPerfModel.PageLoadTime+ "<br> "
									+ " TTFB : " +uiPerfModel.TTFB+ "<br> "
									+ " EndToEndResponseTime : "+uiPerfModel.EndtoendRespTime+ "<br> "
									);

							for(String resourceType: uiPerfModel.MapEntryModel.keySet())
							{
								ExtentTest ResourceTypeNode=MultiTCNode.createNode("Resource  Type : "+ resourceType);	
								ArrayList<EntryModel> lstEntryModel=uiPerfModel.MapEntryModel.get(resourceType);
								for (EntryModel entryModel :lstEntryModel)
								{

									ResourceTypeNode.log(Status.FAIL,
											"EntryName : "+ entryModel.EntryName
											+"<br>EntryType : "+ entryModel.EntryType
											+"<br>InitiatorType : "+ entryModel.InitiatorType
											+"<br>StartTime : "+ entryModel.StartTime
											+"<br>EndTime : "+ entryModel.EndTime
											+"<br>Duration : "+ entryModel.Duration
											+"<br>TransferSize : "+ entryModel.transferSize);
								}
							}
						}
						String sheetName=null;
						if(sheets.containsKey(ScreenName)) {
							for(String s:TestRunSettings.UIPerformanceResultsMap.keySet()) {
								if(s.contains(sheets.get(ScreenName))) {
									count++;
								}
							}
							if(ScreenName.length()>25) {
								String newScreenName=ScreenName.substring(0,Math.min(ScreenName.length(), 25));
								sheetName=newScreenName+"_"+count;

							}else {
								sheetName=ScreenName+"_"+count;
							}
						}else {
							count=1;
							if(ScreenName.length()>25) {
								String newScreenName=ScreenName.substring(0,Math.min(ScreenName.length(), 25));
								sheetName=newScreenName+"_"+count;

							}else {
								sheetName=ScreenName+"_"+count;
							}
						}
						sheets.put(ScreenName,sheetName);
						TestRunSettings.UIPerformanceResultsMap.put(sheetName, result);
						ScreenNameSheetNameMap.put(sheetName, uiPerfModel.TestCaseName);
						ArrayList<String> s=new ArrayList<String>();

						s.add(uiPerfModel.TestCaseName);
						Sheet_ScreenHashMap.put(sheetName,ScreenName);
						if(screenNameToTestCasesMap.get(ScreenName)==null) {
							screenNameToTestCasesMap.put(ScreenName, s);
						}else {
						screenNameToTestCasesMap.get(ScreenName).add(uiPerfModel.TestCaseName);
						}
						writetoExcel(workbook,result,sheetName, ReportPath);
						writeworkbook(workbook, ReportPath);

					}



				}

				createDashboard(workbook,ReportPath);
				writeworkbook(workbook, ReportPath);

			}

			extent_lcl.flush();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;	
		}
	}
	private static XSSFCellStyle getDataCellStyle(XSSFWorkbook workbook){
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setWrapText(true);		
		BorderStyle borderStyle = BorderStyle.THIN;
		cellStyle.setBorderLeft(borderStyle);
		cellStyle.setBorderRight(borderStyle);
		cellStyle.setBorderBottom(borderStyle);
		cellStyle.setBorderTop(borderStyle);
		cellStyle.setAlignment(HorizontalAlignment.LEFT);
		cellStyle.setVerticalAlignment(VerticalAlignment.TOP);		
		return cellStyle;
	}	

	private static XSSFCellStyle headerCellStyle(XSSFWorkbook workbook){
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setWrapText(true);		
		BorderStyle borderStyle = BorderStyle.THIN;
		cellStyle.setBorderLeft(borderStyle);
		cellStyle.setBorderRight(borderStyle);
		cellStyle.setBorderBottom(borderStyle);
		cellStyle.setBorderTop(borderStyle);
		cellStyle.setAlignment(HorizontalAlignment.LEFT);
		cellStyle.setVerticalAlignment(VerticalAlignment.TOP);	
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		cellStyle.setFont(headerFont);
		cellStyle.setFont(headerFont);
		cellStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
		cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		return cellStyle;
	}	

	public static void writetoExcel(XSSFWorkbook workbook,String data,String SheetName, String ReportPath) throws Exception {

		Sheet sheet = workbook.createSheet(SheetName);
		XSSFCellStyle cellstyle = getDataCellStyle(workbook);
		XSSFCellStyle headerStyle = headerCellStyle(workbook);
		// Split data into lines
		String[] lines = data.split("\n");

		// Create headers
		String headerLine=lines[1].trim(); //taking iteration as 1 because 0th iteration is empty
		String[] headers = headerLine.split("\\|"); // Split first line by pipe (|)
		int colIndex = 0;
		Row headerRow = sheet.createRow(0);

		for (String header : headers) {
			Cell headerCell = headerRow.createCell(colIndex++);
			headerCell.setCellValue(header);
			headerCell.setCellStyle(headerStyle);

		}



		// Write data rows
		sheet.setColumnWidth(0, 30 * 270); 
		for (int rowIndex = 1; rowIndex < lines.length-2; rowIndex++) {
			String[] values = lines[rowIndex+2].split("\\|");
			colIndex = 0;
			Row dataRow = sheet.createRow(rowIndex);
			for (String value : values) {
				Cell dataCell = dataRow.createCell(colIndex++);
				dataCell.setCellValue(value);
				dataCell.setCellStyle(cellstyle);
				sheet.setColumnWidth(rowIndex, 30 * 270); 
			}
		}
	}
	public static void writeworkbook(XSSFWorkbook workbook, String ReportPath) throws Exception {
		// Save the workbook
		String filepath = ReportPath+"/"+"UIPerformanceReport"+".xlsx";
		FileOutputStream outputStream = new FileOutputStream(filepath);
		workbook.write(outputStream);
		outputStream.close();
		System.out.println("Data written to Excel file: "+"UIPerformanceReport"+".xlsx");
	}

	public String WriteDataToTextFile(String FilePath, String FileName,String FileContent,String FileFormat)
	{
		FilePath = FilePath + "/" + FileName + FileFormat;
		try
		{

			BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath));
			writer.write(FileContent);

			writer.close();

			FilePath= FilePath.replace("\\","/");

			FilePath = "<a href = 'file:///"+ FilePath + "'>"+ FileName + "</a>";
			return FilePath;
		}

		catch (Exception e)
		{
			return FilePath;
		}
	}

	public static void createDashboard(XSSFWorkbook workbook,String ReportPath) {
		try {
			HashMap<String, Double> screenNameToMedian = new HashMap<>();
			HashMap<String, Double> screenNameToTotalMean = new HashMap<>();
			HashMap<String, Double> screenNameToMinimum = new HashMap<>();
			HashMap<String, Double> screenNameToMaximun = new HashMap<>();
			HashMap<String, Double> screenNameToMedian_New = new HashMap<>();
			HashMap<String, Double> screenNameToTotalMean_New  = new HashMap<>();
			HashMap<String, Double> screenNameToMinimum_New  = new HashMap<>();
			HashMap<String, Double> screenNameToMaximun_New  = new HashMap<>();
			XSSFSheet dashboardSheet = workbook.getSheet("Dashboard");

			CreationHelper createHelper = workbook.getCreationHelper();
			int rowNum = 1;




			for (String screenName : TestRunSettings.UIPerformanceResultsMap.keySet()) {
				String Results = TestRunSettings.UIPerformanceResultsMap.get(screenName);
				String arrayResult[]=Results.split("\n");
				int totalRows = arrayResult.length - 1; // Exclude header


				double mean=calculateMean(screenName);
				screenNameToTotalMean.put(screenName, mean);
				double median=calculateMedian(screenName);
				screenNameToMedian.put(screenName, median);
				double min=calculateMinimunDuration(screenName);
				screenNameToMinimum.put(screenName, min);
				double max=calculateMaximunDuration(screenName);
				screenNameToMaximun.put(screenName, max);

			}
			screenNameToTotalMean_New=MaximunValueForDashboard(screenNameToTotalMean);
			screenNameToMedian_New=MaximunValueForDashboard(screenNameToMedian);
			screenNameToMinimum_New=MaximunValueForDashboard(screenNameToMinimum);
			screenNameToMaximun_New=MaximunValueForDashboard(screenNameToMaximun);

			/*	for(String k:TestRunSettings.UIPerformanceResultsMap.keySet()) {
				double maxAccountValue = Double.MIN_VALUE;
				String latestKey=null;

				String keyTrimmed=k.split("_")[0];

				for (Map.Entry<String, Double> entry : screenNameToTotalMean.entrySet()) {
					String key = entry.getKey();

					Double value = entry.getValue();
					if (key.startsWith(keyTrimmed)) {
						maxAccountValue = Math.max(maxAccountValue, value);
						latestKey=key;
					} 

				}
				screenNameToTotalMean_New.put(latestKey, maxAccountValue);
			}*/
			// Create a cell style with borders and color for HEADER

			CellStyle headerStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerStyle.setFont(headerFont);
			headerStyle.setFont(headerFont);
			headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
			
			headerStyle.setBorderBottom(BorderStyle.THICK);
			headerStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			headerStyle.setBorderLeft(BorderStyle.THICK);
			headerStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			headerStyle.setBorderRight(BorderStyle.THICK);
			headerStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			headerStyle.setBorderTop(BorderStyle.THICK);
			headerStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
			// Create a cell style with borders and color
			CellStyle style = workbook.createCellStyle();
			style.setBorderBottom(BorderStyle.THIN);
			style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderLeft(BorderStyle.THIN);
			style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderRight(BorderStyle.THIN);
			style.setRightBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());

			Row headerRow = dashboardSheet.createRow(0);
			Cell headerCell1 = headerRow.createCell(0);
			headerCell1.setCellValue("S.No.");
			headerCell1.setCellStyle(headerStyle);
			Cell headerCell2 = headerRow.createCell(1);
			headerCell2.setCellValue("Screename");
			headerCell2.setCellStyle(headerStyle);
			Cell headerCell3 = headerRow.createCell(2);
			headerCell3.setCellValue("Average Duration (ms)");
			headerCell3.setCellStyle(headerStyle);
			Cell headerCell4 = headerRow.createCell(3);
			headerCell4.setCellValue("Median Duration (ms)");
			headerCell4.setCellStyle(headerStyle);
			Cell headerCell5 = headerRow.createCell(4);
			headerCell5.setCellValue("Min Duration (ms)");
			headerCell5.setCellStyle(headerStyle);
			Cell headerCell6 = headerRow.createCell(5);
			headerCell6.setCellValue("Max Duration (ms)");
			headerCell6.setCellStyle(headerStyle);
			Cell headerCell7 = headerRow.createCell(6);
			headerCell7.setCellValue("Count of TestCase");
			headerCell7.setCellStyle(headerStyle);
			Cell headerCell8 = headerRow.createCell(7);
			headerCell8.setCellValue("All TestCases");
			headerCell8.setCellStyle(headerStyle);
			Cell headerCell9 = headerRow.createCell(8);
			headerCell9.setCellValue("Max Avrg Duration TestCase");
			headerCell9.setCellStyle(headerStyle);

			//hyperlink config
			CellStyle hyperlinkStyle = workbook.createCellStyle();
			Font hyperlinkFont = workbook.createFont();
			hyperlinkFont.setUnderline(Font.U_SINGLE);
			hyperlinkFont.setColor(IndexedColors.BLUE.getIndex());
			hyperlinkStyle.setFont(hyperlinkFont);
			hyperlinkStyle.setBorderBottom(BorderStyle.THIN);
			hyperlinkStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			hyperlinkStyle.setBorderLeft(BorderStyle.THIN);
			hyperlinkStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			hyperlinkStyle.setBorderRight(BorderStyle.THIN);
			hyperlinkStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			hyperlinkStyle.setBorderTop(BorderStyle.THIN);
			hyperlinkStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());


			for (String entry : screenNameToTotalMean_New.keySet()) {
				Row row = dashboardSheet.createRow(rowNum++);
				Cell cell1=row.createCell(0);
				cell1.setCellValue(rowNum - 1);
				cell1.setCellStyle(style);
				String screenName = entry;
				row.createCell(1).setCellValue(screenName);
				// Add hyperlink to the screen name
				Cell cell = row.getCell(1);
				cell.setCellStyle(style);
				cell.setCellValue(screenName);

				/*	cell.setCellStyle(hyperlinkStyle);
				Hyperlink link = createHelper.createHyperlink(Hyperlink.LINK_DOCUMENT);
				link.setAddress("'" + screenName + "'!A1"); // Sheet name followed by cell reference
				cell.setHyperlink(link);*/
				// End of hyperlink addition
				Cell cell2=row.createCell(2);
				cell2.setCellValue(screenNameToTotalMean_New.get(entry));
				cell2.setCellStyle(style);
				Cell cell3=row.createCell(3);
				cell3.setCellValue(screenNameToMedian.get(entry));
				cell3.setCellStyle(style);
				Cell cell4=row.createCell(4);
				cell4.setCellValue(screenNameToMinimum.get(entry));
				cell4.setCellStyle(style);
				Cell cell5=row.createCell(5);
				cell5.setCellValue(screenNameToMaximun.get(entry));
				cell5.setCellStyle(style);
				String arrayData="";
				boolean f=true;
				int count=0;
				String keyDataForSheetName=Sheet_ScreenHashMap.get(entry);
				for(String s:screenNameToTestCasesMap.get(keyDataForSheetName)) {
					if(f) {
						arrayData+=s;
						f=false;
					}else {
					arrayData+=":"+s;
					}
					count++;
				}
				
				Cell cell6=row.createCell(6);
				cell6.setCellValue(count);
				cell6.setCellStyle(style);
			
				Cell cell7=row.createCell(7);
				cell7.setCellValue(arrayData);
				cell7.setCellStyle(style);
			
				Cell cell8=row.createCell(8);
				cell8.setCellValue(ScreenNameSheetNameMap.get(entry));
				cell8.setCellStyle(hyperlinkStyle);
				Hyperlink link = createHelper.createHyperlink(HyperlinkType.DOCUMENT);
				link.setAddress("'" + screenName + "'!A1"); // Sheet name followed by cell reference
				cell8.setHyperlink(link);

			}

			// Set column widths
			dashboardSheet.setColumnWidth(0, 10 * 250); // 20 characters width
			dashboardSheet.setColumnWidth(1, 20 * 250); // 200 units width
			dashboardSheet.setColumnWidth(2, 20 * 250); // 20 characters width
			dashboardSheet.setColumnWidth(3, 20 * 250); // 20 characters width
			dashboardSheet.setColumnWidth(4, 20 * 250); // 200 units width
			dashboardSheet.setColumnWidth(5, 20 * 250); // 20 characters width
			dashboardSheet.setColumnWidth(6, 20 * 250); // 20 characters width
			dashboardSheet.setColumnWidth(7, 20 * 250); // 20 characters width
			dashboardSheet.setColumnWidth(8, 20 * 250); // 20 characters width


		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static double calculateMean(String screenName) {

		int columnIndex = 2; // For the third column, index is 2
		List<Double> numbers = new ArrayList<>();
		XSSFSheet sheet = workbook.getSheet(screenName);

		for (Row row : sheet) {
			Cell cell = row.getCell(columnIndex);
			if (cell != null ) {
				String cellValue = cell.getStringCellValue();
				try {
					double number = Double.parseDouble(cellValue);
					numbers.add(number);
				} catch (NumberFormatException e) {
					// Ignore cells that do not contain parseable doubles
				}
			}
		}

		double sum = 0;
		for (double number : numbers) {
			sum += number;
		}
		double mean = numbers.isEmpty() ? 0 : sum / numbers.size();
		System.out.println("Mean: for screen "+screenName +" ::"+ mean);
		return mean;

	}

	private static double calculateMedian(String screenName) {

		XSSFSheet sheet = workbook.getSheet(screenName);

		int columnIndex = 2; // For the third column, index is 2
		List<Double> numbers = new ArrayList<>();

		for (Row row : sheet) {
			Cell cell = row.getCell(columnIndex);
			if (cell != null) {
				String cellValue = cell.getStringCellValue();
				try {
					double number = Double.parseDouble(cellValue);
					numbers.add(number);
				} catch (NumberFormatException e) {
					// Ignore cells that do not contain parseable doubles
				}
			}
		}

		Collections.sort(numbers); // Sort the numbers

		double median;
		int size = numbers.size();
		if (size % 2 == 0) {
			median = (numbers.get(size / 2 - 1) + numbers.get(size / 2)) / 2.0;
		} else {
			median = numbers.get(size / 2);
		}

		System.out.println("Median: " + median);

		return median;

	}

	private static double calculateMinimunDuration(String screenName) {

		XSSFSheet sheet = workbook.getSheet(screenName);

		int columnIndex = 2; // For the third column, index is 2
		List<Double> numbers = new ArrayList<>();

		for (Row row : sheet) {
			Cell cell = row.getCell(columnIndex);
			if (cell != null) {
				String cellValue = cell.getStringCellValue();
				try {
					double number = Double.parseDouble(cellValue);
					numbers.add(number);
				} catch (NumberFormatException e) {
					// Ignore cells that do not contain parseable doubles
				}
			}
		}

		double minValue = Collections.min(numbers); // Sort the numbers


		System.out.println("Minimum: " + minValue);

		return minValue;

	}
	private static double calculateMaximunDuration(String screenName) {

		XSSFSheet sheet = workbook.getSheet(screenName);

		int columnIndex = 2; // For the third column, index is 2
		List<Double> numbers = new ArrayList<>();

		for (Row row : sheet) {
			Cell cell = row.getCell(columnIndex);
			if (cell != null) {
				String cellValue = cell.getStringCellValue();
				try {
					double number = Double.parseDouble(cellValue);
					numbers.add(number);
				} catch (NumberFormatException e) {
					// Ignore cells that do not contain parseable doubles
				}
			}
		}

		double maxValue = Collections.max(numbers); // Sort the numbers


		System.out.println("Maximun: " + maxValue);

		return maxValue;

	}


	public static HashMap<String,Double> MaximunValueForDashboard(HashMap<String,Double> screenNameToTotalMean) {
		HashMap<String, Double> screenNameResult = new HashMap<>();

		for(String k:TestRunSettings.UIPerformanceResultsMap.keySet()) {

			double maxAccountValue = Double.MIN_VALUE;
			String latestKey=null;

			String keyTrimmed=k.split("_")[0];

			for (Map.Entry<String, Double> entry : screenNameToTotalMean.entrySet()) {
				String key = entry.getKey();

				Double value = entry.getValue();
				if (key.startsWith(keyTrimmed)) {
					if(value>maxAccountValue) {
						latestKey=key;
						maxAccountValue=value;
					}
					
				} 

			}
			screenNameResult.put(latestKey, maxAccountValue);
		}
		return screenNameResult;
	}
}
