package UIPerformanceUtilities.reports.jsonReports;

import java.io.File;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;

import UIPerformanceUtilities.model.UIPerformanceModel;


public class JSONUtility {

	public void DeSerializeTCDataWriteToFile( ArrayList<UIPerformanceModel> UIPerfModels,String FilePath) throws Exception
	{
		File file = new File(FilePath);
		ObjectMapper mapper = new ObjectMapper();

		try {
			
			mapper.writeValue(file, UIPerfModels);
			String JSONData=mapper.writeValueAsString(UIPerfModels);
			System.out.println(JSONData);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
			
	}
	
	public UIPerformanceModel SerializeTCDatafromFile(String FilePath) throws Exception
	{

		UIPerformanceModel UIPerf = new UIPerformanceModel();
		ObjectMapper mapper = new ObjectMapper();
		try {
			
			UIPerf= mapper.readValue(new File(FilePath), UIPerformanceModel.class);
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
		
		return UIPerf;
		
	} 
	
	
	
	
}
