package UIPerformanceUtilities.constants;

import java.util.ArrayList;
import java.util.HashMap;

import UIPerformanceUtilities.model.UIPerformanceModel;



public class UIPerformanceConstants {

	public static HashMap<String,ArrayList<UIPerformanceModel>> UIPerfData= new HashMap<String,ArrayList<UIPerformanceModel>>();

	public static long ExpectedResponseTimeinMilliSecond=1000;
	
	public void addUIPerfData(String SourceScreen,String DestinationScreen,UIPerformanceModel uiPerfModel)
	{
		ArrayList<UIPerformanceModel> uiPerfModels= new ArrayList<UIPerformanceModel>();
		uiPerfModels.add(uiPerfModel);
		UIPerfData.put(SourceScreen +"_"+ DestinationScreen, uiPerfModels);
	}
	
	public void addUpdatePerfData(String SourceScreen,UIPerformanceModel uiPerfModel)
	{
		
		if(UIPerfData.containsKey(SourceScreen))
		{
			ArrayList<UIPerformanceModel> uiPerfModels=UIPerfData.get(SourceScreen );
			uiPerfModels.add(uiPerfModel);
			UIPerfData.put(SourceScreen , uiPerfModels);
		}
		else
		{
			ArrayList<UIPerformanceModel> uiPerfModels= new ArrayList<UIPerformanceModel>();
			uiPerfModels.add(uiPerfModel);
			UIPerfData.put(SourceScreen , uiPerfModels);	
		}
	}
	
	public ArrayList<UIPerformanceModel> getPerfData(String SourceScreen,String DestinationScreen)
	{
		if(UIPerfData.containsKey(SourceScreen +"_"+ DestinationScreen))
		{
			return UIPerfData.get(SourceScreen +"_"+ DestinationScreen);
		}
		else
		{
			return null;	
		}
	}
}