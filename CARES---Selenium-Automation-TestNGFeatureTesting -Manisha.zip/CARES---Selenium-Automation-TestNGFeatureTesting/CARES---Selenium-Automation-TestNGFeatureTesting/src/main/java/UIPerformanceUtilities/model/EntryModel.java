package UIPerformanceUtilities.model;

public class EntryModel {

	public String EntryName="";
	public String EntryType="";
	public String InitiatorType="";
	public String Duration="";
	public String transferSize="";
	public String StartTime="";
	public String EndTime="";
	
}
