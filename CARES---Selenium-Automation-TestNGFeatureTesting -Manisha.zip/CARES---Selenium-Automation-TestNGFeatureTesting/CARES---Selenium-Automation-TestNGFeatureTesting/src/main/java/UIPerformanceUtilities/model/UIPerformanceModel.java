package UIPerformanceUtilities.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;

//import KeywordDriverUtil.KeywordDriver;
import  UIPerformanceUtilities.utilities.NavigationTimeHelper;
import UIPerformanceUtilities.utilities.UIPerfUtilities;

public class UIPerformanceModel {

	public String SourceScreen="";
	public String DestinationScreen="";
	public String Source_DestinationScreen="";
	public int ScreenCount=0;
	public String ResponseTime="";
	public long ResponseTimeMillisecond=0;
	public String TestCaseName="";
	public String ModuleName="";
	public String BrowserName="";
	public String StartTime="";
	public String EndTime="";
	public long PageLoadTime=0;
	public long TTFB=0;
	public long EndtoendRespTime=0;
	
	public String NavigationTimeDetails="";
	public long connectEnd=0;
	public String connectStart="";
	public String domComplete="";
	public String domContentLoadedEventEnd="";
	public String domContentLoadedEventStart="";
	public String domInteractive="";
	public String domLoading="";
	public String domainLookupEnd="";
	public String domainLookupStart="";
	public String fetchStart="";
	public String loadEventEnd="";
	public String loadEventStart="";
	public String navigationStart="";
	public String redirectEnd="";
	public String redirectStart="";
	public String requestStart="";
	public String responseEnd="";
	public String responseStart="";
	public String secureConnectionStart="";
	public String unloadEventEnd="";
	public String unloadEventStart="";
	public ArrayList<String> entries = new ArrayList<String>();
	public ArrayList<EntryModel> entryModel = new ArrayList<EntryModel>();
	public ArrayList<EntryModel> LstEntryModel = new ArrayList<EntryModel>();
	public HashMap<String,ArrayList<EntryModel>> MapEntryModel = new HashMap<String,ArrayList<EntryModel>>();
	
	NavigationTimeHelper navigationTimeHelper = new NavigationTimeHelper(); 
	
	public UIPerformanceModel()
	{
		
	}
	
	
	public UIPerformanceModel AddUIPerfModel(String SourceScreen, String TestCaseName, String ModuleName, String BrowserName,
			long StartTime,WebDriver driver)
	{
		
		long endTime= System.currentTimeMillis();
		UIPerfUtilities uiPerfUtilities = new UIPerfUtilities();
		
		UIPerformanceModel uiPerfModel= new UIPerformanceModel();
		
		uiPerfModel.SourceScreen=SourceScreen;
		uiPerfModel.DestinationScreen=DestinationScreen;
		uiPerfModel.Source_DestinationScreen=SourceScreen;
		uiPerfModel.ScreenCount=ScreenCount;
		uiPerfModel.TestCaseName=TestCaseName;
		uiPerfModel.ModuleName=ModuleName;
		uiPerfModel.BrowserName=BrowserName;
		uiPerfModel.StartTime=uiPerfUtilities.LocalDateTimeToString(StartTime);
		uiPerfModel.EndTime=uiPerfUtilities.LocalDateTimeToString(endTime);
		uiPerfModel.PageLoadTime=navigationTimeHelper.getPageLoadTime(driver);
		uiPerfModel.TTFB=navigationTimeHelper.getTTFB(driver);
		uiPerfModel.EndtoendRespTime=navigationTimeHelper.getEndtoendRespTime(driver);
		uiPerfModel.entries=navigationTimeHelper.getPerfEntries(driver);
		uiPerfModel.LstEntryModel=navigationTimeHelper.getEntryModelDetails(driver,StartTime);
		uiPerfModel.MapEntryModel=navigationTimeHelper.GroupedEntryMap(uiPerfModel.LstEntryModel);
		
		uiPerfModel.ResponseTimeMillisecond=uiPerfUtilities.getDurationinMillisecond(StartTime, endTime);
		uiPerfModel.ResponseTime=uiPerfUtilities.getDuration(StartTime, endTime);
		return uiPerfModel;
	}
	
}
