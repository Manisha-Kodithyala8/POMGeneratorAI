package UIPerformanceUtilities.utilities;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.fasterxml.jackson.annotation.JsonProperty;

import UIPerformanceUtilities.model.EntryModel;

import org.json.*;
import org.json.JSONException;
import org.json.JSONObject;




public class NavigationTimeHelper {

	  Map<String, Object> timings = null; 
	  private final String JavaScriptForPerformance = "var performance = window.performance || window.webkitPerformance || window.mozPerformance || window.msPerformance || {};var timings = performance.timing || {};return timings;"; 
	   
	  public String getAllTiming(WebDriver driver) throws JSONException{
		   JavascriptExecutor jsrunner = (JavascriptExecutor) driver;
	        var timings = jsrunner.executeScript(JavaScriptForPerformance); 
	        
	        String strTimings = timings.toString();
	        String s1 = strTimings.replace('=', ':');
	        JSONObject json = new JSONObject(s1); 
	   //   System.out.println(json.get("connectEnd")); 
	        
	        return timings.toString();	  
	        
	    }
	  
	  public class RootGetAllTimings{
		  
		  public RootGetAllTimings() {
		  }
		  
		  	@JsonProperty("unloadEventEnd")
		    public int unloadEventEnd;
		  	@JsonProperty("responseEnd")
		    public long responseEnd;
		  	@JsonProperty("responseStart")
		    public long responseStart;
		  	@JsonProperty("domInteractive")
		    public long domInteractive;
		  	@JsonProperty("domainLookupEnd")
		    public long domainLookupEnd;
		  	@JsonProperty("unloadEventStart")
		    public int unloadEventStart;
		  	@JsonProperty("domComplete")
		    public long domComplete;
		  	@JsonProperty("domContentLoadedEventStart")
		    public long domContentLoadedEventStart;
		  	@JsonProperty("domainLookupStart")
		    public long domainLookupStart;
		  	@JsonProperty("redirectEnd")
		    public int redirectEnd;
		  	@JsonProperty("redirectStart")
		    public int redirectStart;
		  	@JsonProperty("connectEnd")
		    public long connectEnd;
		  	@JsonProperty("connectStart")
		    public long connectStart;
		  	@JsonProperty("loadEventStart")
		    public long loadEventStart;
		  	@JsonProperty("navigationStart")
		    public long navigationStart;
		  	@JsonProperty("requestStart")
		    public long requestStart;
		  	@JsonProperty("secureConnectionStart")
		    public long secureConnectionStart;
		  	@JsonProperty("fetchStart")
		    public long fetchStart;
		  	@JsonProperty("domContentLoadedEventEnd")
		    public long domContentLoadedEventEnd;
		  	@JsonProperty("domLoading")
		    public long domLoading;
		  	@JsonProperty("loadEventEnd")
		    public long loadEventEnd;
		}

	   public long getPageLoadTime(WebDriver driver) {
		   
		   JavascriptExecutor jsrunner = (JavascriptExecutor) driver;
		   
		   long pageLoadTime = (Long)jsrunner.executeScript("return (window.performance.timing.loadEventEnd-window.performance.timing.responseStart)");
	
		   return pageLoadTime;
	   }
	   
	   public long getTTFB(WebDriver driver) {
		   
		   JavascriptExecutor jsrunner = (JavascriptExecutor) driver;
		   
		   long TTFB= (Long)jsrunner.executeScript("return (window.performance.timing.responseStart-window.performance.timing.navigationStart)");
		   return TTFB;
	   }
	   
	   public long getEndtoendRespTime(WebDriver driver) {
		   
		   JavascriptExecutor jsrunner = (JavascriptExecutor) driver;
		   
           long endtoendRespTime= (Long)jsrunner.executeScript("return (window.performance.timing.loadEventEnd-window.performance.timing.navigationStart)");
           return endtoendRespTime;
           
	   }
	   
	   public String getDomComplete(WebDriver driver) {
		   
		   JavascriptExecutor jsrunner = (JavascriptExecutor) driver;  
		   
           var domComplete = jsrunner.executeScript("return window.performance.getEntries()");
           
           String dom = domComplete.toString();
	       String s2 = dom.replace('=', ':');
	   
	       
           return domComplete.toString();	   
	   }
	   
	   public ArrayList<String> getPerfEntries(WebDriver driver) {
		   
		   JavascriptExecutor jsrunner = (JavascriptExecutor) driver;
		   var domComplete = jsrunner.executeScript("return window.performance.getEntries().length");
			 
			 int entriesDOM = Integer.parseInt(domComplete.toString());
			 
			 ArrayList<String> entries = new ArrayList<String>();	 
			 ArrayList<String> entriesNameString = new ArrayList<String>();
			 
			 for (int i =0;i<entriesDOM;i++)
			 {
				 try {
					 var domNameEntries = jsrunner.executeScript("return window.performance.getEntries()["+i+"].name");
					 entriesNameString.add(domNameEntries.toString());
				 }
				 catch(Exception e) {
					e.printStackTrace();
				 }
				
			 } 		 
			 entries.add("Name|EntryType|Duration(ms)|InitiatorType|Size");
			for(int j=0;j<entriesNameString.size();j++) {
				
				String result = "";
			
			//	System.out.println("URL/Name :  "+entriesNameString.get(j));
				
				
				boolean resultCheck = true;
				
	            var pageLoadTime = jsrunner.executeScript("return (window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].loadEventEnd-window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].responseStart)");
	            var TTFB= jsrunner.executeScript("return (window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].responseStart-window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].navigationStart)"); 
	            var endtoendRespTime= jsrunner.executeScript("return (window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].loadEventEnd-window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].navigationStart)");
	            var duration =  jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].duration");
	            var entryType =  jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].entryType");
	            var InitiatorType =  jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].initiatorType");
	            var Size =  jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].transferSize");
	            
	            String  StrEntryType="";
	            String  StrInitiatorType="";
	            String  StrSize="";
	            String StrDuration="";
	            
	            if(entryType==null)
	            {
	            	StrEntryType="N/A";
	            }
	            else
	            {
	            	StrEntryType=entryType.toString();
	            }
	            
	            if(InitiatorType==null)
	            {
	            	 StrInitiatorType="N/A";
	            }
	            else
	            {
	            	StrInitiatorType=InitiatorType.toString();
	            }

	            if(Size==null)
	            {
	            	  StrSize="N/A";
	            }
	            else
	            {
	            	StrSize=Size.toString();
	            }
	            if(duration==null)
	            {
	            	  StrDuration="N/A";
	            }
	            else
	            {
	            	StrDuration=duration.toString();
	            }
	            

	            if(resultCheck == true) {
	            	
	            	 
	   				result = entriesNameString.get(j) + " | " + StrEntryType + " | " +StrDuration + " | " +StrInitiatorType + " | " +StrSize;
	            }
	         
	            entries.add(result);
	            System.out.println(entries);
	            
			}
	            return entries;
	            
			}
	   
	
	   
	   public HashMap <String,ArrayList<EntryModel>> GroupedEntryMap(ArrayList<EntryModel> entryModelList)
	   {
		   HashMap <String,ArrayList<EntryModel>> mapEntryModel= new HashMap <String,ArrayList<EntryModel>>();
		   for(EntryModel entryModel: entryModelList)
		   {
			   if(mapEntryModel.containsKey(entryModel.InitiatorType))
			   {
				   ArrayList<EntryModel> lclentryModelList= mapEntryModel.get(entryModel.InitiatorType);
				   lclentryModelList.add(entryModel);
				   mapEntryModel.put(entryModel.InitiatorType, lclentryModelList);   
			   }
			   
			   else
			   {
				   ArrayList<EntryModel> lclentryModelList= new ArrayList<EntryModel>();
				   lclentryModelList.add(entryModel);
				   mapEntryModel.put(entryModel.InitiatorType, lclentryModelList);
			   }
		   }
		   
		   return mapEntryModel;
	   }
	   
	   
	   
	   
	   public ArrayList<EntryModel> getEntryModelDetails(WebDriver driver,long starttime)
	   {

		   ArrayList<EntryModel> entryModelList= new ArrayList<EntryModel>();
		   UIPerfUtilities uiperfutil= new UIPerfUtilities();
		   

		   JavascriptExecutor jsrunner = (JavascriptExecutor) driver;
		   var domComplete = jsrunner.executeScript("return window.performance.getEntries().length");
			 
			 int entriesDOM = Integer.parseInt(domComplete.toString());
			 

			 ArrayList<String> entriesNameString = new ArrayList<String>();
			 
			 for (int i =0;i<entriesDOM;i++)
			 {
				 try {
					 var domNameEntries = jsrunner.executeScript("return window.performance.getEntries()["+i+"].name");
					 entriesNameString.add(domNameEntries.toString());
				 }
				 catch(Exception e) {
					e.printStackTrace();
				 }
				
			 } 		 
			 
			for(int j=0;j<entriesNameString.size();j++) 
			{
				
			
				EntryModel entryModel= new EntryModel();
	            var Duration = jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].duration");
	            var entryType = jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].entryType");
	            var initiatorType = jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].initiatorType");
	            var StartTime=jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].startTime");
	            var transferSize=jsrunner.executeScript("return window.performance.getEntriesByName("+"'" +entriesNameString.get(j)+"'"+ ")[0].transferSize");	        
	            
	            long start_time=0;
          		long duration_long=0;


	            
	            String  StrEntryType="";
	            String  StrInitiatorType="";
	            String  StrSize="";

          		if(entryType==null)
	            {
	            	StrEntryType="N/A";
	            }
	            else
	            {
	            	StrEntryType=entryType.toString();
	            }
	            
	            if(initiatorType==null)
	            {
	            	 StrInitiatorType="N/A";
	            }
	            else
	            {
	            	StrInitiatorType=initiatorType.toString();
	            }

	            if(transferSize==null)
	            {
	            	  StrSize="N/A";
	            }
	            else
	            {
	            	StrSize=transferSize.toString();
	            }
	            

          		if(StartTime!=null && (StartTime.toString().equals("0")==false))
	            { 
	            	start_time=Long.parseLong(StartTime.toString().split("\\.")[0]);
	            	
	            }
	            
	            if(Duration!=null && (Duration.toString().equals("0")==false))
	            { 
	            	System.out.println("Duration: "+ Duration);
	            	duration_long=Long.parseLong(Duration.toString().split("\\.")[0]);
	            }
	            
	            entryModel.EntryName=entriesNameString.get(j);
	            entryModel.Duration=String.valueOf(duration_long);
	            entryModel.EntryType=StrEntryType;
	            entryModel.InitiatorType=StrInitiatorType;
	            entryModel.transferSize=StrSize;
	            entryModel.StartTime=uiperfutil.AddTimeinMilliseconds(starttime, start_time);
	            entryModel.EndTime=uiperfutil.AddTimeinMilliseconds(starttime,start_time+duration_long);
	            
	            
	            
	            
	            entryModelList.add(entryModel);
	            
			}
	            return entryModelList;

		   
	   }
}
