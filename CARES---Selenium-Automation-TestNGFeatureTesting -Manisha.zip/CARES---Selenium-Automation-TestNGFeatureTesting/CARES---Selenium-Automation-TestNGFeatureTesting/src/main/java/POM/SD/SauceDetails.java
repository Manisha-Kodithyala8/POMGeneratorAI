package POM.SD;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.LoggerFactory;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;

import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.SessionData;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;
import Reusable.SessionDetails;

public class SauceDetails {
private static final Logger logger =LoggerFactory.getLogger(SauceDetails.class.getName());

private WebDriver driver;
ReportCommon exceptionDetails = new ReportCommon();
Util util = new Util();

String ModuleName = ModuleConstants_SD.SD;
String ScreenName = ScreenConstants_SD.SauceDetails;
public SauceDetails(){ }
public SauceDetails(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
 public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }

@FindBy(how = How.ID, using = "first-name")
public WebElement Txt_FirstName;

@FindBy(how = How.ID, using = "last-name")
public WebElement Txt_LastName;

@FindBy(how = How.ID, using = "postal-code")
public WebElement Txt_ZipCode;

@FindBy(how = How.ID, using = "continue")
public WebElement BTN_ContinueButton;


@FindBy(how = How.ID, using = "finish")
public WebElement BTN_FinishButton;

public void Enter_FirstName(TestCaseParam testCaseParam ,String FirstName)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute FirstName";
action.PageActionDescription = "Execute FirstName";
try {
	WebKeywords.Instance().SetText(driver, Txt_FirstName, FirstName, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Enter_LastName(TestCaseParam testCaseParam ,String LastName)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute LastName";
action.PageActionDescription = "Execute LastName";
try {
	WebKeywords.Instance().SetText(driver, Txt_LastName, LastName, testCaseParam,action);

  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Enter_ZipCode(TestCaseParam testCaseParam ,String ZipCode)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute ZipCode";
action.PageActionDescription = "Execute ZipCode";
try {
	WebKeywords.Instance().SetText(driver, Txt_ZipCode, ZipCode, testCaseParam,action);

  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Click_BTN_ContinueButton(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_ContinueButton";
action.PageActionDescription = "Click BTN_ContinueButton";
try {
WebKeywords.Instance().Click(driver, BTN_ContinueButton,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }


public void Click_BTN_FinishButton(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_ContinueButton";
action.PageActionDescription = "Click BTN_ContinueButton";
try {
WebKeywords.Instance().Click(driver, BTN_FinishButton,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_FirstName(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword FirstName";
action.PageActionDescription = "VerifyKeyword FirstName";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, Txt_FirstName,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_LastName(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword LastName";
action.PageActionDescription = "VerifyKeyword LastName";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, Txt_LastName,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_ZipCode(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword ZipCode";
action.PageActionDescription = "VerifyKeyword ZipCode";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, Txt_ZipCode,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_ContinueButton(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_ContinueButton";
action.PageActionDescription = "VerifyKeyword BTN_ContinueButton";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_ContinueButton,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void ProcessSauceDetails(TestCaseParam testCaseParam, String iteration) throws Exception  {
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Process  SauceDetails";
action.PageActionName = "Process  SauceDetails";
try {
HashMap<String, ArrayList<String>> TestCaseData_SD = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,iteration);

String FirstName = TestCaseData_SD.get("FirstName").get(0);
SessionDetails sessionDetails = new SessionDetails();
SessionData.setSessionData(testCaseParam, "FirstName", FirstName);

String LastName = TestCaseData_SD.get("LastName").get(0);
String ZipCode = TestCaseData_SD.get("ZipCode").get(0);
String ContinueButton = TestCaseData_SD.get("ContinueButton").get(0);
String FinishButton = TestCaseData_SD.get("FinishButton").get(0);

String VerifyFirstName = TestCaseData_SD.get("VerifyFirstName").get(0);
String VerifyLastName = TestCaseData_SD.get("VerifyLastName").get(0);
String VerifyZipCode = TestCaseData_SD.get("VerifyZipCode").get(0);
String VerifyContinueButton = TestCaseData_SD.get("VerifyZipCode").get(0);

Enter_FirstName(testCaseParam,FirstName);
Enter_LastName(testCaseParam,LastName);
Enter_ZipCode(testCaseParam,ZipCode);
VerifyKeyword_FirstName(testCaseParam,VerifyFirstName);
VerifyKeyword_LastName(testCaseParam,VerifyLastName);
VerifyKeyword_ZipCode(testCaseParam,VerifyZipCode);
VerifyKeyword_BTN_ContinueButton(testCaseParam,VerifyContinueButton);
Click_BTN_ContinueButton(testCaseParam,ContinueButton);
Click_BTN_FinishButton(testCaseParam,FinishButton);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
}

