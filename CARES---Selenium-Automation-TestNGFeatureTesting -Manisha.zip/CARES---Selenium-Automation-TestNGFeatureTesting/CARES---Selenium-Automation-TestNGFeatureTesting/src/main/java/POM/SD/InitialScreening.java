package POM.SD;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Utilities.Util;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.PageDetails;
import TestSettings.TestRunSettings;
import UITests.TestNG.Common.CommonOperations;

public class InitialScreening {
	private static final Logger logger =LoggerFactory.getLogger(InitialScreening.class.getName());
	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();
	CommonOperations objcommonOperations = null;

	String ModuleName = ModuleConstants_SD.SD;
	String ScreenName = ScreenConstants_SD.InitialScreenings_Page;
	public InitialScreening(){ }
	
	public InitialScreening(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
	
	public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
	    {
	    	 driver = _driver;
	         PageFactory.initElements(driver, this);
	         ReportCommon TestStepLogDetails = new ReportCommon(); 
	         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
	         objcommonOperations = new CommonOperations(_driver);
	    }
	
	@FindBy(how = How.XPATH, using = "//label[text()='Date']//parent::div//input")
	public WebElement Date_TB;
	
	@FindBy(how = How.XPATH, using = "//button[contains(@name,'ReasonForCall')]")
	public WebElement ReasonForCall_DD;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Screening Name']//following-sibling::div/input")
	public WebElement ScreeningName_TB;
	
	@FindBy(how = How.XPATH, using = "//div[@aria-label='Screening Narrative']//div[contains(@class,'rich-text-area')]")
	public WebElement ScreeningNarrative_TB;
	
	@FindBy(how = How.XPATH, using = "//h1[text()='Caller Type']")
	public WebElement CallerType_RB;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Caller First Name']//following-sibling::div/input")
	public WebElement CallerFN_TB;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Caller Last Name']//following-sibling::div/input")
	public WebElement CallerLN_TB;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Preferred Method to Receive ERNRD']//parent::div/div//div//button")
	public WebElement PreferredMethod_DD;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Mandated Reporter Type']//parent::div/div//div//button")
	public WebElement MandatedReporterType_DD;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Phone Type']//parent::div/div//div//button")
	public WebElement PhoneType_DD;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Phone']//following-sibling::div/input")
	public WebElement Phone_TB;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Call Back Required']")
	public WebElement CallBackRequired;
	
	
	@FindBy(how = How.XPATH, using = "//label[text()='Call Back Required']//parent::div/div//div//button")
	public WebElement CallBackRequired_DD;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Save and Proceed']")
	public WebElement SaveAndproceed_Btn;
	

	
	
	public void addInitialScreeningInfo(TestCaseParam testCaseParam, String iteration) throws Exception  {

		PageDetails action = new PageDetails();
		LocalDateTime StartTime= LocalDateTime.now();
		action.PageActionName = "Process Initial Screening";
		action.PageActionDescription = "Process Initial Screening";
		try {
			HashMap<String, ArrayList<String>> TestCaseData_SD = new HashMap<String, ArrayList<String>>();
			TestCaseData_SD = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,iteration);

			String Date = TestCaseData_SD.get("TodaysDate").get(0);
			String ReasonForTheCallValue = TestCaseData_SD.get("ReasonForTheCall").get(0);
			String ScreeningName = TestCaseData_SD.get("ScreeningName").get(0);
			String ScreeningNarrrative = TestCaseData_SD.get("ScreeningNarrrative").get(0);
			String CallerType = TestCaseData_SD.get("MandatedReporter").get(0);
			String CallerFN = TestCaseData_SD.get("FirstName").get(0);
			String CallerLN = TestCaseData_SD.get("LastName").get(0);
			String PerferredMethod = TestCaseData_SD.get("PreferredMethodToReceiveERNRD").get(0);
			String MandatedReporterType = TestCaseData_SD.get("MandatedReporterType").get(0);
			String PhoneType = TestCaseData_SD.get("PhoneType").get(0);
			String PhoneTextBox = TestCaseData_SD.get("PhoneTextBox").get(0);
			String CallBackRequiredValue = TestCaseData_SD.get("CallBackRequired").get(0);
						
			WebKeywords.Instance().SetText(driver, Date_TB, CommonOperations.getDate("MM/dd/YYYY",Date), testCaseParam,action);
			
			WebKeywords.Instance().Click(driver, ReasonForCall_DD,"", testCaseParam,action);
			CommonOperations.selectDropdownvalue(driver,"Reason for the Call", ReasonForTheCallValue);
			
			WebKeywords.Instance().SetText(driver, ScreeningName_TB, ScreeningName, testCaseParam,action);
			WebKeywords.Instance().Click(driver, ScreeningNarrative_TB,"", testCaseParam,action);
			WebKeywords.Instance().SetText(driver, ScreeningNarrative_TB, ScreeningNarrrative, testCaseParam,action);
			
			WebKeywords.Instance().ScrollIntoViewElement(driver, CallerType_RB);
			
			WebElement mandateReporter = CommonOperations.radiobutton(driver,CallerType);
			WebKeywords.Instance().JSClick(driver, mandateReporter, testCaseParam, action,2000);
	    	
			WebKeywords.Instance().SetText(driver, CallerFN_TB, CallerFN, testCaseParam,action);
			WebKeywords.Instance().SetText(driver, CallerLN_TB, CallerLN, testCaseParam,action);
			
			WebKeywords.Instance().Click(driver, PreferredMethod_DD,"", testCaseParam,action);
			CommonOperations.selectDropdownvalue(driver,"Preferred Method to Receive ERNRD", PerferredMethod);
			
			WebKeywords.Instance().Click(driver, MandatedReporterType_DD,"", testCaseParam,action);
			CommonOperations.selectDropdownvalue(driver,"Mandated Reporter Type",MandatedReporterType);
	    	
			WebKeywords.Instance().Click(driver, PhoneType_DD,"", testCaseParam,action);
			CommonOperations.selectDropdownvalue(driver,"Phone Type",PhoneType);
			
			WebKeywords.Instance().SetText(driver, Phone_TB, PhoneTextBox, testCaseParam,action);
			WebKeywords.Instance().ScrollIntoViewElement(driver, CallBackRequired);
			
			WebKeywords.Instance().Click(driver, CallBackRequired_DD,"", testCaseParam,action);
			CommonOperations.selectDropdownvalue(driver,"Call Back Required",CallBackRequiredValue);
			
			WebKeywords.Instance().Click(driver, SaveAndproceed_Btn,"", testCaseParam,action);
			objcommonOperations.pageRefresh(driver);
		}
		catch (Exception e)
		{
			logger.error("Failed == " + action.PageActionDescription);
			exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
			throw e;
		}
	}

}
