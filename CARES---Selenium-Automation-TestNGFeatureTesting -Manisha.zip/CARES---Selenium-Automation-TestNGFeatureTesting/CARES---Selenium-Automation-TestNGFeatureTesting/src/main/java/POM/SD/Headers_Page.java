package POM.SD;

import java.time.LocalDateTime;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Utilities.Util;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.PageDetails;

public class Headers_Page {
	private static final Logger logger =LoggerFactory.getLogger(Headers_Page.class.getName());
	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();

	String ModuleName = ModuleConstants_SD.SD;
	String ScreenName = ScreenConstants_SD.Headers_Page;
	public Headers_Page(){ }
	
	public Headers_Page(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}

	public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }
	
	@FindBy(how = How.XPATH, using = "//a[@title='Home']/span")
	public WebElement Home;

	@FindBy(how = How.XPATH, using = "//a[@title='Screenings']")
	public WebElement Screenings;

	@FindBy(how = How.XPATH, using = "//a[@title='Folio']")
	public WebElement Folio;

	
	public void selectHeaderTab(TestCaseParam testCaseParam,String headerName) throws Exception{
		
		PageDetails action = new PageDetails();
		LocalDateTime StartTime= LocalDateTime.now();
		action.PageActionName = "Select Headers";
		action.PageActionDescription = "Select Headers";
		
		try {
			switch(headerName) {
			case "Home":

				WebKeywords.Instance().Clickwithaction(driver, Home, testCaseParam, action,"");
				break;
			case "Screenings":

				WebKeywords.Instance().JSClick(driver, Screenings, testCaseParam, action,2000);
				break;
			case "Folio":

				WebKeywords.Instance().JSClick(driver, Folio, testCaseParam, action,2000);
				break;
			default :
				System.out.println(headerName + " not selected");
				break;
			}
		}catch (Exception e)
		{
			logger.error("Failed == " + action.PageActionDescription);
			exceptionDetails.logExceptionDetails(driver,testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
			throw e;
		}
	}

}
