package POM.SD;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;

public class SauceCheckout {
	
private static final Logger logger =LoggerFactory.getLogger(SauceCheckout.class.getName());
private WebDriver driver;
ReportCommon exceptionDetails = new ReportCommon();
Util util = new Util();

String ModuleName = ModuleConstants_SD.SD;
String ScreenName = ScreenConstants_SD.SauceCheckout;
public SauceCheckout(){ }
public SauceCheckout(WebDriver _driver,ReportUtilities.Model.TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
 public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }

@FindBy(how = How.ID, using = "remove-sauce-labs-bike-light")
public WebElement BTN_RemoveProduct_Bike;

@FindBy(how = How.ID, using = "checkout")
public WebElement BTN_Checkout;

public void Click_BTN_RemoveProduct_Bike(TestCaseParam testCaseParam,String TestData)throws Exception{
	PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_RemoveProduct_Bike";
action.PageActionDescription = "Click BTN_RemoveProduct_Bike";
try {
WebKeywords.Instance().Click(driver, BTN_RemoveProduct_Bike,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Click_BTN_Checkout(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_Checkout";
action.PageActionDescription = "Click BTN_Checkout";
try {
WebKeywords.Instance().Click(driver, BTN_Checkout,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_RemoveProduct_Bike(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_RemoveProduct_Bike";
action.PageActionDescription = "VerifyKeyword BTN_RemoveProduct_Bike";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_RemoveProduct_Bike,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_Checkout(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_Checkout";
action.PageActionDescription = "VerifyKeyword BTN_Checkout";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_Checkout,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void ProcessSauceCheckout(TestCaseParam testCaseParam, String iteration) throws Exception  {
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Process  SauceCheckout";
action.PageActionName = "Process  SauceCheckout";
try {
HashMap<String, ArrayList<String>> TestCaseData_SD = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,iteration);

String RemoveBike = TestCaseData_SD.get("RemoveBike").get(0);
String Checkout = TestCaseData_SD.get("Checkout").get(0);
String VerifyCheckout = TestCaseData_SD.get("VerifyCheckout").get(0);
String VerifyRemoveBike = TestCaseData_SD.get("VerifyRemoveBike").get(0);

VerifyKeyword_BTN_Checkout(testCaseParam, VerifyCheckout);
VerifyKeyword_BTN_RemoveProduct_Bike(testCaseParam, VerifyRemoveBike);
Click_BTN_RemoveProduct_Bike(testCaseParam,RemoveBike);
Click_BTN_Checkout(testCaseParam,Checkout);


  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
}

