package POM.SD;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


import CommonUtilities.Common.ActionKeywords.WebKeywords;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;


public class SauceProduct {
private static final Logger logger =LoggerFactory.getLogger(SauceProduct.class.getName());
private WebDriver driver;
ReportCommon exceptionDetails = new ReportCommon();
Util util = new Util();

String ModuleName = ModuleConstants_SD.SD;
String ScreenName = ScreenConstants_SD.SauceProduct;
public SauceProduct(){ }
public SauceProduct(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
 public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }

@FindBy(how = How.ID, using = "add-to-cart-sauce-labs-backpack")
public WebElement BTN_Product1;

@FindBy(how = How.ID, using = "add-to-cart-sauce-labs-bike-light")
public WebElement BTN_Product2;

@FindBy(how = How.ID, using = "add-to-cart-sauce-labs-bolt-t-shirt")
public WebElement BTN_Product3;

@FindBy(how = How.XPATH, using = "//div[@id='shopping_cart_container']/a")
public WebElement BTN_AddToCart;

public void Click_BTN_Product1(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_Product1";
action.PageActionDescription = "Click BTN_Product1";
try {
WebKeywords.Instance().Click(driver, BTN_Product1,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Click_BTN_Product2(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_Product2";
action.PageActionDescription = "Click BTN_Product2";
try {
WebKeywords.Instance().Click(driver, BTN_Product2,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Click_BTN_Product3(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_Product3";
action.PageActionDescription = "Click BTN_Product3";
try {
WebKeywords.Instance().Click(driver, BTN_Product3,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Click_BTN_AddToCart(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_AddToCart";
action.PageActionDescription = "Click BTN_AddToCart";
try {
WebKeywords.Instance().Click(driver, BTN_AddToCart,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_Product1(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_Product1";
action.PageActionDescription = "VerifyKeyword BTN_Product1";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_Product1,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_Product2(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_Product2";
action.PageActionDescription = "VerifyKeyword BTN_Product2";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_Product2,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_Product3(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_Product3";
action.PageActionDescription = "VerifyKeyword BTN_Product3";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_Product3,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_AddToCart(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_AddToCart";
action.PageActionDescription = "VerifyKeyword BTN_AddToCart";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_AddToCart,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void ProcessSauceProduct(TestCaseParam testCaseParam, String iteration) throws Exception  {
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Process  SauceProduct";
action.PageActionName = "Process  SauceProduct";
try {
    HashMap<String, ArrayList<String>> TestCaseData_SD = new HashMap<String, ArrayList<String>>();
TestCaseData_SD = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,iteration);

String BTN_Product1 = TestCaseData_SD.get("BTN_Product1").get(0);
String BTN_Product2 = TestCaseData_SD.get("BTN_Product2").get(0);
String BTN_Product3 = TestCaseData_SD.get("BTN_Product3").get(0);
String BTN_AddToCart = TestCaseData_SD.get("BTN_AddToCart").get(0);
String verifyBTN_Product1 = TestCaseData_SD.get("verifyBTN_Product1").get(0);
String verifyBTN_Product2 = TestCaseData_SD.get("verifyBTN_Product2").get(0);
String verifyBTN_Product3 = TestCaseData_SD.get("verifyBTN_Product3").get(0);
String verifyBTN_AddToCart = TestCaseData_SD.get("verifyBTN_AddToCart").get(0);




Click_BTN_Product1(testCaseParam,BTN_Product1);
Click_BTN_Product2(testCaseParam,BTN_Product2);
Click_BTN_Product3(testCaseParam,BTN_Product3);
Click_BTN_AddToCart(testCaseParam,BTN_AddToCart);

VerifyKeyword_BTN_Product1(testCaseParam,verifyBTN_Product1);
VerifyKeyword_BTN_Product2(testCaseParam,verifyBTN_Product2);
VerifyKeyword_BTN_Product3(testCaseParam,verifyBTN_Product3);
VerifyKeyword_BTN_AddToCart(testCaseParam,verifyBTN_AddToCart);

}
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
}

