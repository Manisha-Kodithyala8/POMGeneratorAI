package POM.SD;

import java.time.LocalDateTime;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Utilities.Util;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.PageDetails;

public class Screenings_Page {
	private static final Logger logger =LoggerFactory.getLogger(Screenings_Page.class.getName());
	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();

	String ModuleName = ModuleConstants_SD.SD;
	String ScreenName = ScreenConstants_SD.Screenings_Page;
	
	public Screenings_Page(){ }
	
	public Screenings_Page(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}

	public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }
	
	@FindBy(how = How.XPATH, using = "(//a[@title='New'])[1]")
	public WebElement NewButton;

	public void clickNewBtn(TestCaseParam testCaseParam) throws Exception{

		PageDetails action = new PageDetails();
		LocalDateTime StartTime= LocalDateTime.now();
		action.PageActionName = "Select New Button";
		action.PageActionDescription = "Select New Button";
		try {
			WebKeywords.Instance().Click(driver, NewButton,"",testCaseParam,action);
		}catch (Exception e)
		{
			logger.error("Failed == " + action.PageActionDescription);
			exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
			throw e;
		}
    }

}
