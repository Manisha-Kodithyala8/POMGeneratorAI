package POM.SD;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.LoggerFactory;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;

public class SauceLogin {
private static final Logger logger =LoggerFactory.getLogger(SauceLogin.class.getName());
private WebDriver driver;
ReportCommon exceptionDetails = new ReportCommon();
Util util = new Util();

String ModuleName = ModuleConstants_SD.SD;
String ScreenName = ScreenConstants_SD.SauceLogin;
public SauceLogin(){ }
public SauceLogin(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
 public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }

@FindBy(how = How.CSS, using = ".login_logo")
public WebElement HomePageLogo;

@FindBy(how = How.CSS, using = "*[data-test=\"username\"]")
public WebElement TXT_UserName;

@FindBy(how = How.CSS, using = "*[data-test=\"password\"]")
public WebElement TXT_Password;

@FindBy(how = How.ID, using = "login-button")
public WebElement BTN_LoginButton;


public void Enter_URL(TestCaseParam testCaseParam ,String URL )throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute UserName";
action.PageActionDescription = "Execute UserName";
try {
	WebKeywords.Instance().Navigate(driver,  URL, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }


public void Enter_UserName(TestCaseParam testCaseParam ,String UserName )throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute UserName";
action.PageActionDescription = "Execute UserName";
try {
	WebKeywords.Instance().SetText(driver, TXT_UserName, UserName, testCaseParam,action);
	//WebKeywords.Instance().Select(driver, TXT_UserName, SelectType.SelectByText, UserName, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Enter_Password(TestCaseParam testCaseParam ,String Password )throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute Password";
action.PageActionDescription = "Execute Password";
try {
	WebKeywords.Instance().SetText(driver, TXT_Password, Password, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Click_BTN_LoginButton(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_LoginButton";
action.PageActionDescription = "Click BTN_LoginButton";
try {
WebKeywords.Instance().Click(driver, BTN_LoginButton,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_HomePageLogo(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword HomePageLogo";
action.PageActionDescription = "VerifyKeyword HomePageLogo";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, HomePageLogo,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_UserName(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword UserName";
action.PageActionDescription = "VerifyKeyword UserName";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, TXT_UserName,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_Password(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword Password";
action.PageActionDescription = "VerifyKeyword Password";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver,TXT_Password,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_LoginButton(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_LoginButton";
action.PageActionDescription = "VerifyKeyword BTN_LoginButton";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_LoginButton,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void ProcessSauceLogin(TestCaseParam testCaseParam, String iteration) throws Exception  {
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Process  SauceLogin";
action.PageActionDescription = "Process  SauceLogin";
try {
    HashMap<String, ArrayList<String>> TestCaseData_SD = new HashMap<String, ArrayList<String>>();
    TestCaseData_SD = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,iteration);
	

    
    String URL = TestCaseData_SD.get("URL").get(0);
	String UserName = TestCaseData_SD.get("UserName").get(0);
	
	String Password = TestCaseData_SD.get("Password").get(0);
	String SubmitButton = TestCaseData_SD.get("SubmitButton").get(0);

	String VerifyHomePageLogo = TestCaseData_SD.get("VerifyHomePageLogo").get(0);
	String VerifyUserName = TestCaseData_SD.get("VerifyUserName").get(0);	
	String VerifyPassword = TestCaseData_SD.get("VerifyPassword").get(0);
	String VerifySubmitButton = TestCaseData_SD.get("VerifySubmitButton").get(0);
	
	Enter_URL(testCaseParam,URL);
	Enter_UserName(testCaseParam,UserName);
	Enter_Password(testCaseParam,Password);

	VerifyKeyword_HomePageLogo(testCaseParam,VerifyHomePageLogo);
	VerifyKeyword_UserName(testCaseParam,VerifyUserName);
	VerifyKeyword_Password(testCaseParam,VerifyPassword);
	VerifyKeyword_BTN_LoginButton(testCaseParam,VerifySubmitButton);

	
	Click_BTN_LoginButton(testCaseParam,SubmitButton);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
}

