package POM.SD;
import Constants.ModuleConstants_SD;
import Constants.ScreenConstants_SD;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.LoggerFactory;

import com.google.common.base.Verify;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;

public class SauceConfirmation {
private static final Logger logger =LoggerFactory.getLogger(SauceConfirmation.class.getName());
private WebDriver driver;
ReportCommon exceptionDetails = new ReportCommon();
Util util = new Util();

String ModuleName = ModuleConstants_SD.SD;
String ScreenName = ScreenConstants_SD.SauceConfirmation;
public SauceConfirmation(){ }
public SauceConfirmation(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);}
 public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception 
    {
    	 driver = _driver;
         PageFactory.initElements(driver, this);
         ReportCommon TestStepLogDetails = new ReportCommon(); 
         TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
    }

@FindBy(how = How.CSS, using = ".complete-header")
public WebElement OrderConfirmationHeader;

@FindBy(how = How.CSS, using = ".complete-text")
public WebElement OrderConfirmationText;

@FindBy(how = How.ID, using = "back-to-products")
public WebElement BTN_BackToProducts;

public boolean VerifySauceConfirmationHeader(TestCaseParam testCaseParam ,String HeaderData )throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute OrderConfirmationHeader";
action.PageActionDescription = "Execute OrderConfirmationHeader";
try {


return	WebKeywords.Instance().VerifyTextDisplayed(driver, OrderConfirmationHeader, HeaderData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public boolean VerifyOrderConfirmationText(TestCaseParam testCaseParam ,String ConfirmationText)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Execute OrderConfirmationText";
action.PageActionDescription = "Execute OrderConfirmationText";
try {

return	WebKeywords.Instance().VerifyTextDisplayed(driver, OrderConfirmationText, ConfirmationText, testCaseParam,action);

  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void Click_BTN_BackToProducts(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Click BTN_BackToProducts";
action.PageActionDescription = "Click BTN_BackToProducts";
try {
WebKeywords.Instance().Click(driver, BTN_BackToProducts,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_OrderConfirmationHeader(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword OrderConfirmationHeader";
action.PageActionDescription = "VerifyKeyword OrderConfirmationHeader";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, OrderConfirmationHeader,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_OrderConfirmationText(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword OrderConfirmationText";
action.PageActionDescription = "VerifyKeyword OrderConfirmationText";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, OrderConfirmationText,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public void VerifyKeyword_BTN_BackToProducts(TestCaseParam testCaseParam,String TestData)throws Exception{
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "VerifyKeyword BTN_BackToProducts";
action.PageActionDescription = "VerifyKeyword BTN_BackToProducts";
try {
WebKeywords.Instance().VerifyElementDisplayed(driver, BTN_BackToProducts,TestData, testCaseParam,action);
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }

public boolean ProcessSauceConfirmation(TestCaseParam testCaseParam,String iteration) throws Exception  {
PageDetails action = new PageDetails();
LocalDateTime StartTime= LocalDateTime.now();
action.PageActionName = "Process  SauceConfirmation";
action.PageActionName = "Process  SauceConfirmation";

boolean result=false;
try {
HashMap<String, ArrayList<String>> TestCaseData_SD = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,iteration);

String OrderConfirmationHeader = TestCaseData_SD.get("OrderConfirmationHeader").get(0);
String OrderConfirmationText = TestCaseData_SD.get("OrderConfirmationText").get(0);
String BackToProducts = TestCaseData_SD.get("BackToProducts").get(0);
String VerifyBackToProducts = TestCaseData_SD.get("VerifyBackToProducts").get(0);
boolean resultheader=VerifySauceConfirmationHeader(testCaseParam,OrderConfirmationHeader);
boolean resultText=VerifyOrderConfirmationText(testCaseParam,OrderConfirmationText);
VerifyKeyword_BTN_BackToProducts(testCaseParam, VerifyBackToProducts);
Click_BTN_BackToProducts(testCaseParam,BackToProducts);

Thread.sleep(0);
if(resultheader==false || resultText==false)
{
	result=false;
}
else
{
	result=true;
}
return result;
  }
            catch (Exception e)
            {
                logger.error("Failed == " + action.PageActionDescription);
                exceptionDetails.logExceptionDetails(driver, testCaseParam, action.PageActionName, action.PageActionDescription, StartTime,e);
                throw e;
            }
 }
}

