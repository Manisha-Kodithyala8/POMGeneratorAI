package Common;

public class IndividualDetails 
{
	public static String ApplicationNumber="";
	
	
	
	

}
