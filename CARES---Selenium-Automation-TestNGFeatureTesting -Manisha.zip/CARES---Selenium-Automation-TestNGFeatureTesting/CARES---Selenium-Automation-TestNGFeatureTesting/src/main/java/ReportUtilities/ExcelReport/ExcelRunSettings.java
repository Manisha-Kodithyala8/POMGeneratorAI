package ReportUtilities.ExcelReport;

import org.apache.poi.ss.usermodel.Sheet;

import java.util.HashMap;

public class ExcelRunSettings {

	
	public static int DashboardRowCounter=0;
	public static HashMap<String, Sheet> TCSheetMapping= new HashMap<String, Sheet>();
}
