package ReportUtilities.HTMLReport;

import ReportUtilities.Constants.HTMLReportContants;

public class InitializeHTMLReports {

	
	
	public void initHTMLReports(String PrjPath,String ReportPath) throws InterruptedException
	{
		HTMLReportContants.HTMLReportsDir=ReportPath+HTMLReportContants.HTMLReportsDirName;
		HTMLReports htmlReports= new HTMLReports();
		String FileLocation=PrjPath+"/"+ HTMLReportContants.HTMLFileLocation;
		HTMLReportContants.PlaceHolder_HTMLIndex=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLIndex);
		HTMLReportContants.PlaceHolder_ScreenShot=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_ScreenShot);
		HTMLReportContants.PlaceHolder_HTMLTestCase=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLTestCase);
		HTMLReportContants.PlaceHolder_TestStepPre=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_TestStepPre);
		HTMLReportContants.PlaceHolder_CurrentTestStep=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_CurrentTestStep);
		HTMLReportContants.PlaceHolder_HTMLSummary=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLSummary);
		HTMLReportContants.PlaceHolder_HTMLSummary_BrowserRow=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLSummary_ModuleBrowserRow);
		HTMLReportContants.PlaceHolder_HTMLSummary_ModuleRow=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLSummary_ModuleBrowserRow);
		HTMLReportContants.PlaceHolder_HTMLSummary_TCRow=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLSummary_TCRow);
Thread.sleep(0);
		HTMLReportContants.PlaceHolder_HTMLTCLiveRow=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLTCLiveRow);
		HTMLReportContants.PlaceHolder_HTMLTCLiveTemplate=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.Template_HTMLTCLiveTemplate);

		
		HTMLReportContants.SummaryData_HTML=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.SummaryDashboard);
		HTMLReportContants.SummaryData_CSS=htmlReports.ReadFileLineByLine(FileLocation + HTMLReportContants.SummaryCSS);
		HTMLReportContants.HTMLSummaryData_JS=htmlReports.ReadFileLineByLine(FileLocation + HTMLReportContants.SummaryJS);
		
		HTMLReportContants.TestCaseData_HTML=htmlReports.ReadDataFromTextFile(FileLocation + HTMLReportContants.TestCaseHTML);
		HTMLReportContants.TestCaseData_CSS=htmlReports.ReadFileLineByLine(FileLocation + HTMLReportContants.TestCaseCSS);
		HTMLReportContants.TestCaseData_JS=htmlReports.ReadFileLineByLine(FileLocation + HTMLReportContants.TestCaseJS);

		HTMLReportContants.SummaryJSONFilePath= HTMLReportContants.HTMLReportsDir+ HTMLReportContants.SummaryJSON;

		
	}
}
