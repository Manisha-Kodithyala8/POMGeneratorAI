package ReportUtilities.Model.ExtentModel;

import ReportUtilities.Common.BrowserType;
import ReportUtilities.Constants.ReportContants;
import ReportUtilities.ExtentReport.ExtentReport;
import ReportUtilities.HTMLReport.HTMLReports;
import ReportUtilities.Model.HTML.TestManager;
import ReportUtilities.Model.HTML.TestStep;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.TestStepModel;
import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class ExtentUtilities
{
	public TestCaseDetails InitializeNewTestCase(String testcasename, String testcasedescription,
		String module,String TestCaseCategory,String CaseNumber, String ApplicationNumber, String Browser, int... iteration)
	{
		
		
		HashMap<UUID, TestCaseDetails> TCDetails = new HashMap<UUID, TestCaseDetails>();

		LocalDateTime starttime =LocalDateTime.now();
		TestCaseDetails testCaseDetails = new TestCaseDetails();

		if(iteration.length>0)
		{
			TCDetails = testCaseDetails.AddNewTestCase(testcasename,testcasename + "_" + module + "_" + Browser, testcasedescription,
			module, Browser,TestCaseCategory,CaseNumber,ApplicationNumber, starttime, iteration[0]);

		}
		else
		{

			TCDetails = testCaseDetails.AddNewTestCase(testcasename,testcasename + "_" + module + "_" + Browser, testcasedescription,
			module, Browser,TestCaseCategory,CaseNumber,ApplicationNumber, starttime);
			ExtentReport extentReport = new ExtentReport();
			extentReport.StartTest(testcasename, module, Browser, testcasedescription);

		}
		
		
		
		
		HTMLReports htmlReports = new HTMLReports();
		String TCLiveFilePath=htmlReports.CreateTCHTML(testcasename, module, Browser, testcasedescription);
		
	  
		htmlReports.CreateTCHTMLLive(testcasename, module, Browser,ReportContants.Status_InProgress, TCLiveFilePath);
		htmlReports.Create_Dashboard_HTMLLiveSummary();

	
		TestManager.addTestCase(testcasename, module, Browser);
		
		TestRunDetails.TestCaseRepository.add(TCDetails);
		HashMap<String, UUID> tcMapping = new HashMap<String, UUID>();
	
		tcMapping.put(TCDetails.get(TCDetails.entrySet().stream().findFirst().get().getKey()).TestCaseFullName, TCDetails.entrySet().stream().findFirst().get().getKey());
		TestRunDetails.TestCaseMapping.add(tcMapping);
		return testCaseDetails;
	}


	public UUID getTestCaseID(String TestCaseName, String Module, String Browser)
	{

		for (HashMap<String, UUID> DictKey : TestRunDetails.TestCaseMapping)
		{
			if (DictKey.containsKey(TestCaseName + "_" + Module + "_" + Browser))
			{
				return DictKey.get(TestCaseName + "_" + Module + "_" + Browser);
			}
		}

		return null;
	}

	public void endTestCase(String TestCaseName, String Module, String Browser)
	{
		HTMLReports htmlReports = new HTMLReports();
		htmlReports.UpdateTCHTMLLive(TestCaseName, Module, Browser, ReportContants.Status_Completed);
	}


	public void Log(TestCaseParam testCaseParam,TestStepModel testStepModel)
	{

		BrowserType BT = new BrowserType();
		String Browser = testCaseParam.Browser;
		UUID TCID = getTestCaseID(testCaseParam.TestCaseName, testCaseParam.ModuleName, Browser);

		/*
		 * TestRunDetails.TestCaseRepository.First(x => x.ContainsKey(TCID)).First()
		 * .Value.stepDetails.Add(new TestStepDetails().
		 * AddTestStepDetails(testStepModel.TestStepName,
		 * testStepModel.TestStepDescription, testStepModel.StartTime,
		 * testStepModel.EndTime, testStepModel.TestStepStatus,
		 * testStepModel.ScreenShotData));
		 */
		
		
		
		TestStepDetails TSDetail= new  TestStepDetails().
				AddTestStepDetails(testStepModel.TestStepName,
				  testStepModel.TestStepDescription, testStepModel.StartTime,
				  testStepModel.EndTime, testStepModel.TestStepStatus,
				 testStepModel.ScreenShotData,testStepModel.ErrorMessage,
				 testStepModel.ErrorDetails,
				 testStepModel.ExpectedResponse,testStepModel.ActualResponse,
				 testStepModel.ModuleName,testStepModel.ScreenName,
				 testStepModel.testStepType,testStepModel.testStepFormat);
		
		
		TestRunDetails.TestCaseRepository.stream().filter(x->x.containsKey(TCID)).findFirst().get().get(TCID).stepDetails.add(TSDetail);
		TestRunDetails.TestCaseRepository.stream().filter(x->x.containsKey(TCID)).findFirst().get().get(TCID).Browser=testCaseParam.Browser;
		
		ExtentReport extentReport= new ExtentReport();
		extentReport.addTestStepsLogs(testCaseParam, TSDetail);
		
		HTMLReports htmlReports = new HTMLReports();
		htmlReports.addTestStepsLogs(testCaseParam, TSDetail);
		
		try {
			
			 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			 
		        String startTime = TSDetail.StartTime.format(formatter);
		        String endTime = TSDetail.EndTime.format(formatter);

		        String TSstatus = TSDetail.ExtentStatus.toString().toUpperCase();
		        TestStep TS =new TestStep();
		        TS=TS.addTestStep(TSDetail.StepName,TSstatus ,startTime, endTime, TSDetail.Duration);
		        
			TestManager.addTestStep(testCaseParam.TestCaseName, testCaseParam.ModuleName, testCaseParam.Browser,TS );
			
		} catch (StreamWriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabindException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		}

	public ArrayList<HashMap<UUID, TestCaseDetails>> getTestRunDetails()
	{

		return TestRunDetails.TestCaseRepository;
	}
	
	public void Logpdf(TestCaseParam testCaseParam,TestStepModel testStepModel)
	{

		BrowserType BT = new BrowserType();
		String Browser = testCaseParam.Browser;
		UUID TCID = getTestCaseID(testCaseParam.TestCaseName, testCaseParam.ModuleName, Browser);

		/*
		 * TestRunDetails.TestCaseRepository.First(x => x.ContainsKey(TCID)).First()
		 * .Value.stepDetails.Add(new TestStepDetails().
		 * AddTestStepDetails(testStepModel.TestStepName,
		 * testStepModel.TestStepDescription, testStepModel.StartTime,
		 * testStepModel.EndTime, testStepModel.TestStepStatus,
		 * testStepModel.ScreenShotData));
		 */
		
		
		
		TestStepDetails TSDetail= new  TestStepDetails().
				AddTestStepDetailsPdf(testStepModel.TestStepName,
				  testStepModel.TestStepDescription, testStepModel.StartTime,
				  testStepModel.EndTime, testStepModel.TestStepStatus,
				 testStepModel.ErrorMessage);	
		TestRunDetails.TestCaseRepository.stream().filter(x->x.containsKey(TCID)).findFirst().get().get(TCID).stepDetails.add(TSDetail);
		TestRunDetails.TestCaseRepository.stream().filter(x->x.containsKey(TCID)).findFirst().get().get(TCID).Browser=testCaseParam.Browser;
		}
	
	

}
