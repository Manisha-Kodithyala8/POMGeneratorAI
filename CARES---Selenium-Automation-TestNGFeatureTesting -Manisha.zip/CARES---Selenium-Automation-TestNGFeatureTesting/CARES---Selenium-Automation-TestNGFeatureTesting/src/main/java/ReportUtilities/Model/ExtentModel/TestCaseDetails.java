package ReportUtilities.Model.ExtentModel;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class TestCaseDetails
{
	
	@JsonProperty("TestCaseId")
    public UUID  TestCaseId;
	
	@JsonProperty("TestCaseFullName")
    public String TestCaseFullName;
	
	@JsonProperty("TestCaseName")
    public String TestCaseName;

	@JsonProperty("TestCaseDescription")
    public String TestCaseDescription;
	
	@JsonProperty("Module")
    public String Module;
	
	@JsonProperty("Browser")
    public String Browser;
	
	@JsonProperty("TestCaseCategory")
    public String TestCaseCategory;
	
	@JsonProperty("Iteration")
    public int Iteration=1;
	
	@JsonProperty("StartTime")
    public LocalDateTime StartTime;
	
	@JsonProperty("EndTime")
    public LocalDateTime EndTime;
	
	@JsonProperty("Duration")
    public BigDecimal  Duration;
	
	@JsonProperty("testCaseStatus")
    public String testCaseStatus = "Unknown";

	@JsonProperty("ErrorMessage")
    public String ErrorMessage = "";
	
	//******temp changes//
	@JsonProperty("CaseNumber")
    public String CaseNumber = "";
	@JsonProperty("ApplicationNumber")
    public String ApplicationNumber = "";

    public TestCaseDetails()
    {
    	
    }
    public ArrayList<TestStepDetails> stepDetails = new ArrayList<TestStepDetails>();

    public UUID  getUniqueTestCaseID()
    {
        TestCaseId = UUID.randomUUID();
        return TestCaseId;
    }

    public HashMap<UUID , TestCaseDetails> AddNewTestCase(String testcasename, String TestCaseFullName,String testcasedescription,
        String module,String Browser,String TestCaseCategory, String CaseNumber, String ApplicationNumber,
         LocalDateTime starttime, int... iteration)
    {

        HashMap<UUID, TestCaseDetails> NewTestCase = new HashMap<UUID, TestCaseDetails>();

       TestCaseId = UUID.randomUUID();
        TestCaseDetails testCaseDetails = new TestCaseDetails();
        testCaseDetails.TestCaseId = TestCaseId;
        testCaseDetails.TestCaseName = testcasename;
        testCaseDetails.TestCaseFullName = TestCaseFullName;
        testCaseDetails.TestCaseDescription = testcasedescription;
        testCaseDetails.Module = module;
        testCaseDetails.TestCaseCategory = TestCaseCategory;
        
        //Temp changes//
        testCaseDetails.CaseNumber=CaseNumber;
        testCaseDetails.ApplicationNumber=ApplicationNumber;
        //
        if(iteration.length>0)
        {
        	testCaseDetails.Iteration = iteration[0];
        }
        else
        {
        	testCaseDetails.Iteration=1;
        }
        testCaseDetails.StartTime = starttime;

        //HashMap<String, Guid> tcMapping = new HashMap<String, Guid>();
        //tcMapping.Add(TestCaseName + "_" + Module + "_" + Browser, TestCaseId);
        //TestRunDetails.TestCaseMapping.Add(tcMapping);

        NewTestCase.put(TestCaseId, testCaseDetails);
        return NewTestCase;
    }



}
