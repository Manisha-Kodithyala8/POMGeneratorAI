package ReportUtilities.Model.ExtentModel;

import ReportUtilities.Model.TestStepModel;
import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class TestStepDetails
{
	public enum TestStepType{MultiTC,Module,Screen,TestStep,Verification,Exception,Module_Screen};
	
	public enum TestStepFormat{Plain,HTML,Code,XML,JSON,Table};


	@JsonProperty("StepName")
	public String StepName="" ;
	
	@JsonProperty("StepDescription")
	public String StepDescription="";
	
	@JsonProperty("StartTime")
	public LocalDateTime StartTime=LocalDateTime.now();
	
	@JsonProperty("EndTime")
	public LocalDateTime EndTime=LocalDateTime.now();
	
	@JsonProperty("Duration")
	public String Duration="";
	
	@JsonProperty("testCaseStatus")
	public String testCaseStatus = "";
	
	@JsonProperty("ExtentStatus")
	public Status ExtentStatus=Status.SKIP;
	
	@JsonProperty("ScreenShotData")
	public String ScreenShotData = "";
	
	@JsonProperty("ErrorMessage")
	public String ErrorMessage="";
	
	@JsonProperty("ErrorDetails")
	public String ErrorDetails="";
	
	@JsonProperty("ActualResponse")
	public String ActualResponse="";
	
	@JsonProperty("ExpectedResponse")
	public String ExpectedResponse="";

	@JsonProperty("ModuleName")
	public String ModuleName="";
	
	@JsonProperty("ScreenName")
	public String ScreenName="";
	
	@JsonProperty("TestStepType")
	public TestStepType testStepType=TestStepType.TestStep;
	
	@JsonProperty("TestStepFormat")
	public TestStepFormat testStepFormat=TestStepFormat.Plain;

	public TestStepDetails()
	{
		
	}
	public TestStepDetails AddTestStepDetails(String teststepname, String testcasedescription,
		LocalDateTime starttime, LocalDateTime endtime, String testStepStatus )
	{

		TestStepDetails testStepDetails = new TestStepDetails();
		testStepDetails.StepName = teststepname;
		testStepDetails.StepDescription = testcasedescription;
		testStepDetails.StartTime = starttime;
		testStepDetails.EndTime = endtime;
		testStepDetails.Duration = String.valueOf(endtime.getSecond()-starttime.getSecond());
		testStepDetails.testCaseStatus = testStepStatus;
		testStepDetails.ExtentStatus=getExtentStatus(testStepStatus);
		
		return testStepDetails;
	}
	
	public TestStepDetails AddTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata )
		{

		TestStepDetails testStepDetails = new TestStepDetails();
		testStepDetails.StepName = teststepname;
		testStepDetails.StepDescription = testcasedescription;
		testStepDetails.StartTime = starttime;
		testStepDetails.EndTime = endtime;
		testStepDetails.Duration = String.valueOf(endtime.getSecond()-starttime.getSecond());
		testStepDetails.testCaseStatus = testStepStatus;
		testStepDetails.ExtentStatus=getExtentStatus(testStepStatus);
			testStepDetails.ScreenShotData = screenshotdata;

			return testStepDetails;
		}

	
	public TestStepDetails AddTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String errormessage,String errordetails )
		{

		TestStepDetails testStepDetails = new TestStepDetails();
		testStepDetails.StepName = teststepname;
		testStepDetails.StepDescription = testcasedescription;
		testStepDetails.StartTime = starttime;
		testStepDetails.EndTime = endtime;
		testStepDetails.Duration = String.valueOf(endtime.getSecond()-starttime.getSecond());
		testStepDetails.testCaseStatus = testStepStatus;
		testStepDetails.ExtentStatus=getExtentStatus(testStepStatus);
		testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.ErrorMessage = errormessage;
			testStepDetails.ErrorDetails = errordetails;

			return testStepDetails;
		}

	
	
	public TestStepDetails AddTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus,
			String screenshotdata,String ErrorMessage,String ErrorDetails,
			String ExpectedResponse,String ActualResponse,
			String ModuleName,String ScreenName,
			TestStepModel.TestStepType testStepType,TestStepModel.TestStepFormat testStepFormat )

		{
		

			TestStepDetails testStepDetails = new TestStepDetails();
			testStepDetails.StepName = teststepname;
			testStepDetails.StepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime = endtime;
			testStepDetails.Duration =  formatDuration(starttime, endtime);
			testStepDetails.ExtentStatus = getExtentStatus(testStepStatus);
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.ErrorMessage = ErrorMessage;
			testStepDetails.ErrorDetails = ErrorDetails;
			testStepDetails.ExpectedResponse = ExpectedResponse;
			testStepDetails.ActualResponse = ActualResponse;
//			testStepDetails.ActualTableData = ActualTableData;
//			testStepDetails.ExpectedTableData = ExpectedTableData;
			testStepDetails.ModuleName = ModuleName;
			testStepDetails.ScreenName = ScreenName;
			testStepDetails.testStepType=getTestStepType(testStepType);
			testStepDetails.testStepFormat=getTestStepFormat(testStepFormat);

			return testStepDetails;
		}

	public TestStepDetails AddTestStepDetailsPdf(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus,String Results )
	{

		TestStepDetails testStepDetails = new TestStepDetails();
		testStepDetails.StepName = teststepname;
		testStepDetails.StepDescription = testcasedescription;
		testStepDetails.StartTime = starttime;
		testStepDetails.EndTime = endtime;
		testStepDetails.testCaseStatus = testStepStatus;
		testStepDetails.ExtentStatus=getExtentStatus(testStepStatus);
		testStepDetails.ErrorMessage = Results;


		return testStepDetails;
	}
	
	public String getStartTime()
	{
	    LocalDateTime today = StartTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    String date = today.format(format);
	    return date;
	}
	
	public String getEndTime()
	{
	    LocalDateTime today = EndTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    String date = today.format(format);
	    return date;
	}
	
	public Status getExtentStatus(String TCStatus)
	{
		if(TCStatus.equalsIgnoreCase("PASS"))
		{
			return Status.PASS;
		}
		else if(TCStatus.equalsIgnoreCase("FAIL"))
		{
			return Status.FAIL;
		}
		else
		{
			return Status.INFO;
		}

	}
	
	public TestStepType getTestStepType(TestStepModel.TestStepType testStepType)
	{
		switch(testStepType)
		{
		case Module:
			return TestStepType.Module;
			
		case Module_Screen:
			return TestStepType.Module_Screen;
			
		case MultiTC:
			return TestStepType.MultiTC;
			
		case Screen:
			return TestStepType.Screen;
			
		case TestStep:
			return TestStepType.TestStep;

		case Verification:
			return TestStepType.Verification;

		case Exception:
			return TestStepType.Exception;
		
		
		default:
				return TestStepType.TestStep;	
		}
		
	}
	
	public TestStepFormat getTestStepFormat(TestStepModel.TestStepFormat testStepFormat)
	{
		switch(testStepFormat)
		{
		case Plain:
			return TestStepFormat.Plain;
			

		case HTML:
			return TestStepFormat.HTML;
			
		case Code:
			return TestStepFormat.Code;
			
		case XML:
			return TestStepFormat.XML;
			
		case JSON:
			return TestStepFormat.JSON;
				
		case Table:
			return TestStepFormat.Table;
			
		
		default:
				return TestStepFormat.Plain;	
		}
		
	}
	
	public TestStepDetails getTestStepDetails()
	{
		TestStepDetails testStepDetails=new TestStepDetails();
//		testStepDetails.StepName = TestStepDetails.StepName;
//		testStepDetails.StepDescription = testcasedescription;
//		testStepDetails.StartTime = starttime;
//		testStepDetails.EndTime = endtime;
//		testStepDetails.Duration =  String.valueOf(endtime.getSecond()-starttime.getSecond());
//		testStepDetails.ExtentStatus = getExtentStatus(testStepStatus);
//		testStepDetails.ScreenShotData = screenshotdata;
//		testStepDetails.ErrorMessage = ErrorMessage;
//		testStepDetails.ErrorDetails = ErrorDetails;
//		testStepDetails.ExpectedResponse = ExpectedResponse;
//		testStepDetails.ActualResponse = ActualResponse;
////		testStepDetails.ActualTableData = ActualTableData;
////		testStepDetails.ExpectedTableData = ExpectedTableData;
//		testStepDetails.ModuleName = ModuleName;
//		testStepDetails.ScreenName = ScreenName;
//		testStepDetails.testStepType=getTestStepType(testStepType);
//		testStepDetails.testStepFormat=getTestStepFormat(testStepFormat);
//		
		return testStepDetails;
		
	}
	private static String formatDuration(LocalDateTime startTime,LocalDateTime endTime) {
		java.time.Duration duration= java.time.Duration.between(startTime, endTime);
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long seconds = duration.toSecondsPart();

        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}