package ReportUtilities.Model.HTML;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CurrentStepData {
	@JsonProperty("currentStep")
    private String currentStep;
	@JsonProperty("status")
    private String status;

	
	public CurrentStepData() {
		
	}
    // Getters and setters
    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
