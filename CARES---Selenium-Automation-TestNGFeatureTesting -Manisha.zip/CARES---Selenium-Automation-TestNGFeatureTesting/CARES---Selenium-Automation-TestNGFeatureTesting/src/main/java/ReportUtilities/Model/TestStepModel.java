package ReportUtilities.Model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestStepModel
{
	
	public enum TestStepType{MultiTC,Module,Screen,TestStep,Verification,Exception,Module_Screen};
	public enum TestStepFormat{Plain,HTML,Code,XML,JSON,Table};


	
	public TestStepType testStepType=TestStepType.TestStep;
	public TestStepFormat testStepFormat=TestStepFormat.Plain;
	public String TestStepName="";
	public String TestStepDescription="";
	public LocalDateTime StartTime=LocalDateTime.now();
	public LocalDateTime EndTime=LocalDateTime.now();
	public String TestStepStatus="";
	public String ScreenShotData="";
	public String Duration="";
	public String ErrorMessage="";
	public String ErrorDetails="";
	public String ActualResponse="";
	public String ExpectedResponse="";
	public String[][] StepTableData=new String[100][100];
	public String[][] ActualTableData=new String[100][100];
	public String[][] ExpectedTableData=new String[100][100];
	public String ModuleName="";
	public String ScreenName="";
	
	private static String formatDuration(LocalDateTime startTime,LocalDateTime endTime) {
		java.time.Duration duration= java.time.Duration.between(startTime, endTime);
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long seconds = duration.toSecondsPart();

        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
	public TestStepModel AddTestStepDetails(String teststepname, String testcasedescription,
		LocalDateTime starttime, LocalDateTime endtime, String testStepStatus )
	{

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.TestStepName = teststepname;
		testStepDetails.TestStepDescription = testcasedescription;
		testStepDetails.StartTime = starttime;
		testStepDetails.EndTime = endtime;
		testStepDetails.Duration = formatDuration(starttime, endtime);
		testStepDetails.TestStepStatus = testStepStatus;
		testStepDetails.testStepType=TestStepType.TestStep;
		testStepDetails.testStepFormat=TestStepFormat.Plain;
		return testStepDetails;
	}
	
	public TestStepModel AddTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.TestStepName = teststepname;
			testStepDetails.TestStepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime = endtime;
			testStepDetails.Duration = formatDuration(starttime, endtime);
			testStepDetails.TestStepStatus = testStepStatus;
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.testStepType=TestStepType.TestStep;
			testStepDetails.testStepFormat=TestStepFormat.Plain;

			return testStepDetails;
		}
	
	


	public TestStepModel AddTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String Format )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.TestStepName = teststepname;
			testStepDetails.TestStepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime = endtime;
			testStepDetails.Duration = formatDuration(starttime, endtime);
			testStepDetails.TestStepStatus = testStepStatus;
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.testStepType=TestStepType.TestStep;
			
			testStepDetails.testStepFormat=getTestStepFormat(Format);
			return testStepDetails;
		}

	
	public TestStepModel AddTestStepErrorDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String errormessage,String errordetails )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.TestStepName = teststepname;
			testStepDetails.TestStepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime = endtime;
			testStepDetails.Duration = formatDuration(starttime, endtime);
			testStepDetails.TestStepStatus = testStepStatus;
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.ErrorMessage = errormessage;
			testStepDetails.ErrorDetails = errordetails;
			testStepDetails.testStepType=TestStepType.Exception;
			testStepDetails.testStepFormat=TestStepFormat.Plain;

			return testStepDetails;
		}

	
	public TestStepModel AddVerificationStep(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String ExpectedResponse,String ActualResponse )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.TestStepName = teststepname;
			testStepDetails.TestStepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime = endtime;
			testStepDetails.Duration = formatDuration(starttime, endtime);
			testStepDetails.TestStepStatus = testStepStatus;
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.ExpectedResponse = ExpectedResponse;
			testStepDetails.ActualResponse = ActualResponse;
			
			testStepDetails.testStepType=TestStepType.Verification;
			testStepDetails.testStepFormat=TestStepFormat.Plain;

			return testStepDetails;
		}
	
	public TestStepModel addAPITestStep( String stepName, String description,
			LocalDateTime starttime, LocalDateTime endtime, String status,
            String actualResponse, String expectedResponse) {
		
		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.TestStepName = stepName;
		testStepDetails.TestStepDescription = description;
		testStepDetails.StartTime = starttime;
		testStepDetails.EndTime = endtime;
		testStepDetails.Duration = formatDuration(starttime, endtime);
		testStepDetails.TestStepStatus = status;

		testStepDetails.ExpectedResponse = actualResponse;
		testStepDetails.ActualResponse = expectedResponse;
		
		testStepDetails.testStepType=TestStepType.Verification;
		testStepDetails.testStepFormat=TestStepFormat.Plain;

		return testStepDetails;

	}

	

	
	public TestStepModel AddVerificationStep(String teststepname, String testcasedescription,
            LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String ExpectedResponse,String ActualResponse )
     {

            TestStepModel testStepDetails = new TestStepModel();
            testStepDetails.TestStepName = teststepname;
            testStepDetails.TestStepDescription = testcasedescription;
            testStepDetails.StartTime = starttime;
            testStepDetails.EndTime = endtime;
            testStepDetails.Duration = formatDuration(starttime, endtime);
            testStepDetails.TestStepStatus = testStepStatus;
            testStepDetails.ExpectedResponse = ExpectedResponse;
            testStepDetails.ActualResponse = ActualResponse;
            
            testStepDetails.testStepType=TestStepType.Verification;
            testStepDetails.testStepFormat=TestStepFormat.Plain;

            return testStepDetails;
     }

	
	
	
	public TestStepModel AddVerificationStep(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String ExpectedResponse,String ActualResponse,String Format )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.TestStepName = teststepname;
			testStepDetails.TestStepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime = endtime;
			testStepDetails.Duration = formatDuration(starttime, endtime);
			testStepDetails.TestStepStatus = testStepStatus;
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.ExpectedResponse = ExpectedResponse;
			testStepDetails.ActualResponse = ActualResponse;
			testStepDetails.testStepType=TestStepType.Verification;
			testStepDetails.testStepFormat=getTestStepFormat(Format);

			return testStepDetails;
		}
	
	


	public TestStepModel VerifyTableData(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus,  String screenshotdata,String[][] ExpectedTableData,String[][] ActualTableData )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.TestStepName = teststepname;
			testStepDetails.TestStepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime =endtime;
			testStepDetails.Duration = formatDuration(starttime, endtime);
			testStepDetails.TestStepStatus = testStepStatus;
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.ExpectedTableData = ExpectedTableData;
			testStepDetails.ActualTableData = ActualTableData;
			testStepDetails.testStepType=TestStepType.Verification;
			testStepDetails.testStepFormat=TestStepFormat.Table;

			return testStepDetails;
		}



	

	public TestStepModel AddTableData(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus,  String screenshotdata,String[][] StepTableData )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.TestStepName = teststepname;
			testStepDetails.TestStepDescription = testcasedescription;
			testStepDetails.StartTime = starttime;
			testStepDetails.EndTime = endtime;
			testStepDetails.Duration = formatDuration(starttime, endtime);
			testStepDetails.TestStepStatus = testStepStatus;
			testStepDetails.ScreenShotData = screenshotdata;
			testStepDetails.ExpectedTableData = StepTableData;
			testStepDetails.testStepType=TestStepType.TestStep;
			testStepDetails.testStepFormat=TestStepFormat.Table;

			return testStepDetails;
		}

	
	
	public TestStepModel AddModuleScreenData(String moduleName, String screenName)
		{

;			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.StartTime = LocalDateTime.now();
			testStepDetails.EndTime = LocalDateTime.now();
			testStepDetails.Duration = "";
			testStepDetails.ModuleName = moduleName;
			testStepDetails.ScreenName = screenName;
			testStepDetails.testStepType=TestStepType.Module_Screen;
			testStepDetails.testStepFormat=TestStepFormat.Plain;

			return testStepDetails;
		}

	
	public TestStepModel AddModuleData(String moduleName)
	{

		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.StartTime = LocalDateTime.now();
		testStepDetails.EndTime = LocalDateTime.now();
		testStepDetails.Duration = "";
		testStepDetails.ModuleName = moduleName;
		testStepDetails.testStepType=TestStepType.Module;
		testStepDetails.testStepFormat=TestStepFormat.Plain;

		return testStepDetails;
	}
	
	public TestStepModel AddScreenData( String screenName)
	{

		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.StartTime = LocalDateTime.now();
		testStepDetails.EndTime = LocalDateTime.now();
		testStepDetails.Duration = "";
		testStepDetails.ScreenName = screenName;
		testStepDetails.testStepType=TestStepType.Screen;
		testStepDetails.testStepFormat=TestStepFormat.Plain;

		return testStepDetails;
	}

	
	public TestStepModel AddMultiTCData(String TestCaseName)
	{

		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.StartTime = LocalDateTime.now();
		testStepDetails.EndTime = LocalDateTime.now();
		testStepDetails.Duration = "";
		testStepDetails.TestStepName = TestCaseName;
		testStepDetails.testStepType=TestStepType.MultiTC;
		testStepDetails.testStepFormat=TestStepFormat.Plain;

		return testStepDetails;
	}
	
	public TestStepModel AddVerificationStepPDF(String teststepname, String testcasedescription,
            LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String Result)
     {
            TestStepModel testStepDetails = new TestStepModel();
            testStepDetails.TestStepName = teststepname;
            testStepDetails.TestStepDescription = testcasedescription;
            testStepDetails.StartTime = starttime;
            testStepDetails.EndTime = endtime;
            testStepDetails.Duration = formatDuration(starttime, endtime);
            testStepDetails.TestStepStatus = testStepStatus;
            testStepDetails.ErrorMessage = Result;
            testStepDetails.testStepType=TestStepType.Verification;
            testStepDetails.testStepFormat=TestStepFormat.Plain;

            return testStepDetails;
     }
	
	public TestStepModel AddVerificationStepPDFPass(String teststepname, String testcasedescription,
            LocalDateTime starttime, LocalDateTime endtime, String testStepStatus)
     {

            TestStepModel testStepDetails = new TestStepModel();
            testStepDetails.TestStepName = teststepname;
            testStepDetails.TestStepDescription = testcasedescription;
            testStepDetails.StartTime = starttime;
            testStepDetails.EndTime = endtime;
            testStepDetails.Duration = formatDuration(starttime, endtime);
            testStepDetails.TestStepStatus = testStepStatus;
            testStepDetails.testStepType=TestStepType.Verification;
            testStepDetails.testStepFormat=TestStepFormat.Plain;

            return testStepDetails;
     }

	
	public TestStepFormat getTestStepFormat(String Format)
	{
		if(Format.equalsIgnoreCase("XML"))
		{
			return TestStepFormat.XML;
		}
		else if(Format.equalsIgnoreCase("JSON"))
		{
			return TestStepFormat.JSON;
		}
		else if(Format.equalsIgnoreCase("CODE"))
		{
			return TestStepFormat.Code;
		}
		else if(Format.equalsIgnoreCase("HTML"))
		{
			return TestStepFormat.HTML;
		}
		else if(Format.equalsIgnoreCase("TABLE"))
		{
			return TestStepFormat.Table;
		}
		else
		{
			return TestStepFormat.Plain;
		}

	}
	
	public String getStartTime()
	{
	    LocalDateTime today = StartTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    String date = today.format(format);
	    return date;
	}
	
	public String getEndTime()
	{
	    LocalDateTime today = EndTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    String date = today.format(format);
	    return date;
	}
}
