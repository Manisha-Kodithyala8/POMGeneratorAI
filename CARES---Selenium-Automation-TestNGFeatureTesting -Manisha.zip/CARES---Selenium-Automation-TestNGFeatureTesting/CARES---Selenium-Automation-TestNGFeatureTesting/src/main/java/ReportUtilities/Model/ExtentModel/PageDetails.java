package ReportUtilities.Model.ExtentModel;

public class PageDetails 
{
	
	public String PageActionName="";
	public String PageActionDescription="";

}
