package ReportUtilities.Model.HTML;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HTMLTCLiveModel {

	@JsonProperty("TestCase")
	public String TestCase="";
	@JsonProperty("Module")
	public String Module="";
	@JsonProperty("Browser")
	public String Browser="";
	@JsonProperty("Status")
	public String Status="";
	@JsonProperty("FilePath")
	public String FilePath="";
	
	
	public HTMLTCLiveModel()
	{
		
	}

	public HTMLTCLiveModel AddData_HTMLTCLiveModel(String testCase,String moduleName, String browser, String status,String tcFilePath)
	{
		HTMLTCLiveModel htmltcLiveModel =new HTMLTCLiveModel();
		htmltcLiveModel.TestCase=testCase;
		htmltcLiveModel.Module=moduleName;
		htmltcLiveModel.Browser=browser;
		htmltcLiveModel.Status=status;
		htmltcLiveModel.FilePath=tcFilePath;

		return htmltcLiveModel;
	}

	
	public String getTestCase() {
	
		return TestCase;
	}
	
	public String getModule() {
		
		return Module;
	}
	
	
	public String getBrowser() {
		
		return Browser;
	}
	
	public String getStatus() {
		
		return Status;
	}
	
	public String getFilePath() {
		
		return FilePath;
	}
	
	
	public void setStatus(String status)
	{
		this.Status=status;
	}
	
}
