package ReportUtilities.Model.HTML;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TestStep {
	
	@JsonProperty("stepNo")
    private int stepNo;
	@JsonProperty("description")
    private String description;
	@JsonProperty("status")
    private String status;
	@JsonProperty("startTime")
    private String startTime;
	@JsonProperty("endTime")
    private String endTime;
	@JsonProperty("duration")
    private String duration;
	
	
	
	public TestStep()
	{
		
	}

	public TestStep addTestStep(String description, String status, 
            String startTime, String endTime, String duration) {
TestStep testStep = new TestStep();
testStep.setDescription(description);
testStep.setStatus(status);
testStep.setStartTime(startTime);
testStep.setEndTime(endTime);
testStep.setDuration(duration);
return testStep;
}

	
    // Getters and setters
    public int getStepNo() {
        return stepNo;
    }

    public void setStepNo(int stepNo) {
        this.stepNo = stepNo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
