package ReportUtilities.Model.HTML;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Browser {
	
	@JsonProperty("name")
    private String name;
	
	@JsonProperty("passed")
    private int passed;
	
	@JsonProperty("failed")
    private int failed;
	
	@JsonProperty("pending")
    private int pending;
	
	@JsonProperty("skipped")
    private int skipped;

	@JsonProperty("inprogress")
	private int inprogress;

    public Browser()
    {
    	
    }
    
    public Browser(String name, int passed, int failed, int pending, int skipped) {
        this.name = name;
        this.passed = passed;
        this.failed = failed;
        this.pending = pending;
        this.skipped = skipped;
    }

    
    /**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the passed
	 */
	public int getPassed() {
		return passed;
	}
	/**
	 * @param passed the passed to set
	 */
	public void setPassed(int passed) {
		this.passed = passed;
	}
	/**
	 * @return the failed
	 */
	public int getFailed() {
		return failed;
	}
	/**
	 * @param failed the failed to set
	 */
	public void setFailed(int failed) {
		this.failed = failed;
	}
	/**
	 * @return the pending
	 */
	public int getPending() {
		return pending;
	}
	/**
	 * @param pending the pending to set
	 */
	public void setPending(int pending) {
		this.pending = pending;
	}
	/**
	 * @return the skipped
	 */
	public int getSkipped() {
		return skipped;
	}
	/**
	 * @param skipped the skipped to set
	 */
	public void setSkipped(int skipped) {
		this.skipped = skipped;
	}

	
	
	public int getInProgress() {
		// TODO Auto-generated method stub
		return inprogress;
	}
	
	public void setInProgress(int inprogress) {
		this.inprogress = inprogress;
	}
}
