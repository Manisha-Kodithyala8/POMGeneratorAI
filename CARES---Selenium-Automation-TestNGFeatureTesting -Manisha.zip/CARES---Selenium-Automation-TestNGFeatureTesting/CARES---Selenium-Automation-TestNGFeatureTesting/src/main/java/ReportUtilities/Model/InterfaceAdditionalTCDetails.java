package ReportUtilities.Model;

import ReportUtilities.ExtentReport.ExtentConstants.TestStepStatus;

public class InterfaceAdditionalTCDetails
{
    public long InterfaceAdditionalTCDetailsId;
    public long TestRunId;
    public String TestCaseId;
    public String InterfaceName;
    public String RequestData;
    public String ResponseData;
    public TestStepStatus TestCaseStatus;


    public void setInterfaceAdditionalTCDetails(long TestRunId, String TestCaseId, String InterfaceName, String RequestData, String ResponseData, TestStepStatus status)
    {
        this.TestRunId = TestRunId;
        this.TestCaseId = TestCaseId;
        this.InterfaceName = InterfaceName;
        this.RequestData = RequestData;
        this.ResponseData = ResponseData;
        this.TestCaseStatus = status;
    }

}
