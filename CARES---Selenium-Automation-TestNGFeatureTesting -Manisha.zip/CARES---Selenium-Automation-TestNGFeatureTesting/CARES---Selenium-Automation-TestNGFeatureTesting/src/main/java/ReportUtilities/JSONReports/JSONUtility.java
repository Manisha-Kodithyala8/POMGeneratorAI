package ReportUtilities.JSONReports;

import ReportUtilities.Model.ExtentModel.TestCaseDetails;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.*;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class JSONUtility {

	public void DeSerializeTCDataWriteToFile(TestCaseDetails TCD,String FilePath) throws Exception
	{
		File file = new File(FilePath);
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

		try {
			
			mapper.writeValue(file, TCD);
			//String JSONData=mapper.writeValueAsString(TCD);
			//System.out.println(JSONData);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
			
	}
	
	
	

	public String getTestCaseJSONData(TestCaseDetails TCD)
	{
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		String JSONData="";
		try {
			
//			JSONData=mapper.writeValueAsString(TCD);
			Gson gson = new GsonBuilder()
				    .registerTypeAdapter(LocalDateTime.class, (JsonSerializer<LocalDateTime>) (src, typeOfSrc, context) ->
				        new JsonPrimitive(src.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)))
				    .registerTypeAdapter(LocalDateTime.class, (JsonDeserializer<LocalDateTime>) (json, typeOfT, context) ->
				        LocalDateTime.parse(json.getAsJsonPrimitive().getAsString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME)).serializeNulls().create();
			JSONData = gson.toJson(TCD); 
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
//			throw e;
		}
		
		return JSONData;
	}
	
	
	public TestCaseDetails SerializeTCDatafromFile(String FilePath) throws Exception
	{

		TestCaseDetails TCD = new TestCaseDetails();
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		try {
			
			TCD= mapper.readValue(new File(FilePath), TestCaseDetails.class);
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
		
		return TCD;
		
	}
	
	public TestCaseDetails SerializeTCDatafromString(String TCData) throws Exception
	{

		TestCaseDetails TCD = new TestCaseDetails();
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

		try {
			
			TCD= mapper.readValue(TCData, TestCaseDetails.class);
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
		
		return TCD;
		
	}
	
}
