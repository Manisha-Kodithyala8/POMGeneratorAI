package ReportUtilities.Constants;

import ReportUtilities.Model.HTML.HTMLTCLiveModel;
import ReportUtilities.TestResultModel.BrowserResult;
import ReportUtilities.TestResultModel.ModuleResult;
import ReportUtilities.TestResultModel.TestCaseResult;

import java.util.ArrayList;
import java.util.List;


public class ReportContants
{
	public static boolean isScreenShotforAllPass = false; 
	public static boolean isFullPageScreenShot = false;
	public static String ResultsFolder = "";
	public static ArrayList<TestCaseResult> testcaseResults= new ArrayList<TestCaseResult>();
	public static ArrayList<ModuleResult> moduleResults= new ArrayList<ModuleResult>();
	public static ArrayList<BrowserResult> browserResults= new ArrayList<BrowserResult>();
	public static List<HTMLTCLiveModel> htmlTCLiveModels= new ArrayList<HTMLTCLiveModel>();
	public static boolean replaceExistingSnapshotForAllPass=false;
	public static String Status_InProgress="InProgress";
	public static String Status_Completed="Completed";
	public static String Status_NotStarted="Not Started";
	public static String Status_Done="Done";
	public static String Status_Pass="Pass";
	public static String Status_Fail="Failed";

	
	public ReportContants(String resultsFolder, boolean isScreenShotforPass, boolean isfullPageScreenShot)
	{
		isFullPageScreenShot = isfullPageScreenShot;
		ResultsFolder = resultsFolder;
		isScreenShotforAllPass=isScreenShotforPass;
	} 
 


}