package ReportUtilities.ExtentReport;


public class ExtentTestSteps
 {
     public String TestStepName;
     public String TestStepDesc;
     public ExtentConstants.TestStepStatus TestStepStatus;

     public ExtentConstants.TestStepStatus getTestStepStatus()
     {
         return TestStepStatus;
     }

     public void setTestStepStatus(ExtentConstants.TestStepStatus TestStepStatus)
     {
         this.TestStepStatus = TestStepStatus;
     }

     public String getTestStepName()
     {
         return TestStepName;
     }

     public void setTestStepName(String TestStepName)
     {
         this.TestStepName = TestStepName;
     }


     public String getTestStepDesc()
     {
         return TestStepDesc;
     }

     public void setTestStepDesc(String TestStepDesc)
     {
         this.TestStepDesc = TestStepDesc;
     }
 }
