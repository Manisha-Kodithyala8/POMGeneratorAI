package ReportUtilities.TestResultModel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestCaseResult {

	public String TestCaseName="";
	public String TestCaseDescription="";
	public String TestCaseCategory="";
	public String Module="";
	public String Browser="";
	public String TestCaseStatus="";
	public LocalDateTime StartTime=LocalDateTime.now();
	public LocalDateTime EndTime=LocalDateTime.now();
	public String Duration="";
	
	//**********Temp Chnages//
	public String CaseNumber="";
	public String ApplicationNumber="";
	
	//****************//
	public String getModule() {
        return Module;
    }
	
	public String getBrowser() {
        return Browser;
    }
	
	public String getTestCaseStatus() {
        return TestCaseStatus;
    }
	
	public String getStartTime()
	{
	    LocalDateTime today = StartTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    String date = today.format(format);
	    return date;
	}
	
	public String getEndTime()
	{
	    LocalDateTime today = EndTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    String date = today.format(format);
	    return date;
	}
}
