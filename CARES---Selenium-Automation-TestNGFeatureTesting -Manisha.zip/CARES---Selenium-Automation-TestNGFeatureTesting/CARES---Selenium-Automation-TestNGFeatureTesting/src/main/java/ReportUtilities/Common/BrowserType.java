	package ReportUtilities.Common;

public class BrowserType
{
    public enum Browser { IE, Chrome, Firefox, Edge, Safari }

    public Browser GetBrowser(String browser)
    {
        if (browser.toUpperCase().equals("IE"))
        {
            return Browser.IE;
        }
        else if (browser.toUpperCase().equals("CHROME"))
        {
            return Browser.Chrome;
        }
        else if (browser.toUpperCase().equals("FIREFOX"))
        {
            return Browser.Firefox;
        }
        else if (browser.toUpperCase().equals("EDGE"))
        {
            return Browser.Edge;
        }
        else if (browser.toUpperCase().equals("SAFARI"))
        {
            return Browser.Safari;
        }
        else
        {
            return Browser.Chrome;
        }
    }


    public String GetBrowserfromEnum(Browser browser)
    {
        if (browser==Browser.IE)
        {
            return "IE";
        }
        else if (browser == Browser.Chrome)
        {
            return "Chrome";
        }
        else if (browser == Browser.Firefox)
        {
            return "Firefox";
        }
        else if (browser == Browser.Edge)
        {
            return "Edge";
        }
        else if (browser == Browser.Safari)
        {
            return "Safari";
        }
        else
        {
            return "Chrome";
        }
    }


}

