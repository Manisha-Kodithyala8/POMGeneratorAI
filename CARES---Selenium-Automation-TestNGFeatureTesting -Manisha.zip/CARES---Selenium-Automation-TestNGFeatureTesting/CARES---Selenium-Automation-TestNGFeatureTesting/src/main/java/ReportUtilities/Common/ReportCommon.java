  package ReportUtilities.Common;

  import ReportUtilities.Constants.ReportContants;
  import ReportUtilities.Model.ExtentModel.ExtentUtilities;
  import ReportUtilities.Model.ExtentModel.PageDetails;
  import ReportUtilities.Model.ExtentModel.TestCaseDetails;
  import ReportUtilities.Model.ExtentModel.TestStepDetails;
  import ReportUtilities.Model.TestCaseParam;
  import ReportUtilities.Model.TestStepModel;
  import ReportUtilities.TestResultModel.BrowserResult;
  import ReportUtilities.TestResultModel.ModuleResult;
  import ReportUtilities.TestResultModel.TestCaseResult;
  import org.openqa.selenium.WebDriver;

  import java.time.Duration;
  import java.time.LocalDateTime;
  import java.time.LocalTime;
  import java.time.format.DateTimeFormatter;
  import java.time.temporal.ChronoUnit;
  import java.util.*;
  import java.util.stream.Collectors;

public class ReportCommon
{
	ScreenshotCommon screenshotCommon = new ScreenshotCommon();
	ExtentUtilities extentUtilities = new ExtentUtilities();
	
	public void logTestStepDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription,PageDetails pageDetails, LocalDateTime StartTime,String Status) throws Exception
	{
	LocalDateTime  EndTime = LocalDateTime.now();
		
		TestStepModel testStepModel = new TestStepModel();
		
        String ScreenShotData="";
		
		if(Status.equalsIgnoreCase("PASS"))
		{
			ScreenShotData=screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName);	
		}
		else if(Status.equalsIgnoreCase("DONE"))
		{
			if(ReportContants.isScreenShotforAllPass)
			{
			ScreenShotData=screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName);			
			}
		}
		
		else if(Status.equalsIgnoreCase("FAIL"))
		{
			ScreenShotData=screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName);			
		}
		TestStepName=getActionName( pageDetails.PageActionName,TestStepName);
		TestStepDescription=getActionDesc(pageDetails.PageActionDescription,TestStepDescription );
	
			
			testStepModel=testStepModel.AddTestStepDetails(TestStepName, TestStepDescription, StartTime, EndTime,
					Status,ScreenShotData);

			TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
			extentUtilities.Log(temptestCaseParam, testStepModel);

	}

	public void logExceptionDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();

		testStepModel=testStepModel.AddTestStepDetails(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
			"Fail", screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName));
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}
	
	public void logExceptionDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,Exception ex) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		
		StringBuilder stack= new StringBuilder();
		for(StackTraceElement s: ex.getStackTrace()) {
			stack = (stack.append(s)).append(";");
		}
		testStepModel=testStepModel.AddTestStepErrorDetails(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
			"Fail", screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName),ex.getMessage(),stack.toString());
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}
	
    public void logVerificationDetails_Label(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status, String ExpectedResponse , String ActualResponse) throws Exception
    {
          TestStepModel testStepModel = new TestStepModel();
    testStepModel=testStepModel.AddVerificationStep(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
                       Status, ExpectedResponse,ActualResponse);
          TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
          extentUtilities.Log(temptestCaseParam, testStepModel);
    }

	
	public void logExceptionDetails(TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,Exception ex) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddTestStepErrorDetails(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
			"Fail","",ex.getMessage(),ex.getStackTrace().toString());
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}
	
	public void logDBExceptionDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,Exception ex) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddTestStepErrorDetails(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
			"Fail", "",ex.getMessage(),ex.getStackTrace().toString());
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}
	

	public void logVerificationDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status, String ExpectedResponse , String ActualResponse) throws Exception
{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddVerificationStep(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
				Status, screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName),ExpectedResponse,ActualResponse);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);


	}
	
	public void logDBVerificationDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status, String ExpectedResponse , String ActualResponse) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddVerificationStep(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
				Status, "",ExpectedResponse,ActualResponse);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);


	}
	
	
	public void logAPIModule( TestCaseParam testCaseParam, String APIDetails) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddModuleData(APIDetails);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);


	}

	
    public void logAPITestStep(TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status, String ExpectedResponse , String ActualResponse) throws Exception
    {
    	

		TestStepModel testStepModel = new TestStepModel();
          
		testStepModel=testStepModel.addAPITestStep(TestStepName, TestStepDescription, StartTime,LocalDateTime.now(),Status,
                       ExpectedResponse,ActualResponse);
          

          TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
  		extentUtilities.Log(temptestCaseParam, testStepModel);
    }


	
	public void logDBVerificationDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status, String ExpectedResponse , String ActualResponse, String Query) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddVerificationStep(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
				Status, "",ExpectedResponse,ActualResponse,Query);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);


	}
	
	public void logVerificationDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status,String ExpectedResponse , String ActualResponse,String Format) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddVerificationStep(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
				Status, screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName),ExpectedResponse,ActualResponse,Format);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}
	
	public void VerifyTableData(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status,String[][]ExpectedTableData , String[][] ActualTableData) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.VerifyTableData(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
				Status, screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName),ExpectedTableData,ActualTableData);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}

	
	public void logTableData(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status,String[][]StepTableData) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddTableData(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
				Status, screenshotCommon.CaptureScreenShot(_driver, testCaseParam.TestCaseName),StepTableData);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}


	
	public void logScreenDetails(TestCaseParam testCaseParam, String ScreenName) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddScreenData(ScreenName);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);
	}

	public void logModuleDetails( TestCaseParam testCaseParam, String ModuleName) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddModuleData(ModuleName);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);


	}
	
	
	
	public void logPrereqDetails( TestCaseParam testCaseParam, String TC_Prereq) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddMultiTCData(TC_Prereq);
		extentUtilities.Log(testCaseParam, testStepModel);

	}

	
	public void logModuleAndScreenDetails( TestCaseParam testCaseParam, String ModuleName, String ScreenName) throws Exception
	{
		TestStepModel testStepModel = new TestStepModel();
		testStepModel=testStepModel.AddModuleScreenData(ModuleName,ScreenName);
		TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
		extentUtilities.Log(temptestCaseParam, testStepModel);

	}
	
	public void logPDFDetails(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status, String Results) throws Exception
	{
			TestStepModel testStepModel = new TestStepModel();
			testStepModel=testStepModel.AddVerificationStepPDF(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
					Status,Results);
			TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
			extentUtilities.Logpdf(temptestCaseParam, testStepModel);


		}
	public void logPDFDetailsPass(WebDriver _driver, TestCaseParam testCaseParam, String TestStepName, String TestStepDescription, LocalDateTime StartTime,String Status) throws Exception
	{
			TestStepModel testStepModel = new TestStepModel();
			testStepModel=testStepModel.AddVerificationStepPDFPass(TestStepName, TestStepDescription, StartTime, LocalDateTime.now(),
					Status);
			TestCaseParam temptestCaseParam=getTempTestCaseParam(testCaseParam);
			extentUtilities.Logpdf(temptestCaseParam, testStepModel);


		}

	
	
	
	public TestCaseParam getTempTestCaseParam(TestCaseParam testCaseParam)
	{
		TestCaseParam temptestCaseParam= new TestCaseParam();
		temptestCaseParam.TestCaseDescription=testCaseParam.TestCaseDescription;
		temptestCaseParam.TestCaseName=testCaseParam.TestCaseName;
		temptestCaseParam.Browser=testCaseParam.Browser;
		temptestCaseParam.Iteration=testCaseParam.Iteration;
		temptestCaseParam.ModuleName=testCaseParam.ModuleName;
		temptestCaseParam.testCaseType=testCaseParam.testCaseType;
		
		
			if(temptestCaseParam.testCaseType==TestCaseParam.TestCaseType.Prereq) 
			{
				temptestCaseParam.TestCaseName=testCaseParam.TestCaseName.replace("_Prereq", "");
			}
			
			return temptestCaseParam;
	}

	public void CalculateTestCaseResults(ArrayList<HashMap<UUID, TestCaseDetails>> TestCaseRepository) throws Exception
	{
		try
		{
		if (TestCaseRepository != null)
		{

			for (HashMap<UUID,TestCaseDetails> DictTC : TestCaseRepository)
			{
				TestCaseResult testCaseResult= new TestCaseResult();
				
				
				TestCaseDetails testCaseDetails = DictTC.values().stream().findFirst().get();
				testCaseResult.TestCaseName = testCaseDetails.TestCaseName;
				testCaseResult.TestCaseDescription = testCaseDetails.TestCaseDescription;
				testCaseResult.Module = testCaseDetails.Module;
				testCaseResult.Browser = testCaseDetails.Browser;
				testCaseResult.TestCaseCategory=testCaseDetails.TestCaseCategory;
				testCaseResult.CaseNumber=testCaseDetails.CaseNumber;
				testCaseResult.ApplicationNumber=testCaseDetails.ApplicationNumber;

				ArrayList<TestStepDetails> testStepDetails = testCaseDetails.stepDetails;
				


				boolean TCFailed=testStepDetails.stream().anyMatch(x->x.ExtentStatus.name().toUpperCase().contains("FAIL"));
				

				if(TCFailed)
				{
					testCaseResult.TestCaseStatus="Fail";
				}
				else
				{
					testCaseResult.TestCaseStatus="Pass";					
				}

				testCaseResult.StartTime =testStepDetails.get(0).StartTime;
				testCaseResult.EndTime  =testStepDetails.get(testStepDetails.size()-1).EndTime;
				
				LocalTime starttime=testCaseResult.StartTime.toLocalTime();
				LocalTime endtime=testCaseResult.EndTime.toLocalTime();
				
				
				long totalSeconds = ChronoUnit.SECONDS.between(testCaseResult.StartTime.toLocalTime(), testCaseResult.EndTime.toLocalTime());
				//int totalSecs = testCaseResult.EndTime.getSecond() -testCaseResult.StartTime.getSecond();
				int totalSecs=(int)totalSeconds; 
				
				
				int hours = totalSecs / 3600;
				int minutes = (totalSecs % 3600) / 60;
				int seconds = totalSecs % 60;
				
				String strhours = String.valueOf(hours);
				String strminutes = String.valueOf(minutes);
				String strseconds = String.valueOf(seconds);

				if(strhours.length()==1)
				{
					strhours="0"+strhours;
				}

				if(strminutes.length()==1)
				{
					strminutes="0"+strminutes;
				}

				if(strseconds.length()==1)
				{
					strseconds="0"+strseconds;
				}

				//testCaseResult.Duration=String.valueOf(hours)+ ":" + String.valueOf(minutes)+ ":"+String.valueOf(seconds);

				testCaseResult.Duration=strhours +":" + strminutes+ ":" + strseconds;
				ReportContants.testcaseResults.add(testCaseResult);
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;	
		}
	
	
	}
	
	
	public void CalculateModuleResults()
	{
		ModuleResult moduleResult= new ModuleResult();
		Map<String, List<TestCaseResult>> ModuleStatus = 
				ReportContants.testcaseResults.stream().
				collect(Collectors.groupingBy(TestCaseResult::getModule));

for (Map.Entry<String, List<TestCaseResult>> entry : ModuleStatus.entrySet()) {
int total = entry.getValue().size();
long PassCount = entry.getValue().stream().filter(e -> e.TestCaseStatus.equalsIgnoreCase("Pass")).count();
long FailCount = entry.getValue().stream().filter(e -> e.TestCaseStatus.equalsIgnoreCase("Fail")).count();
moduleResult.Module=entry.getKey();
moduleResult.TCTotalCount=(int) total;
moduleResult.TCPassCount=(int) PassCount;
moduleResult.TCFailCount=(int) FailCount;
moduleResult.TCSkippedCount=(int) (total-(PassCount+FailCount));
ReportContants.moduleResults.add(moduleResult);

}
}

	
	public void CalculateBrowserResults()
	{
		BrowserResult browserResult= new BrowserResult();
		Map<String, List<TestCaseResult>> browserStatus = 
				ReportContants.testcaseResults.stream().
				collect(Collectors.groupingBy(TestCaseResult::getBrowser));

for (Map.Entry<String, List<TestCaseResult>> entry : browserStatus.entrySet()) {
int total = entry.getValue().size();
long PassCount = entry.getValue().stream().filter(e -> e.TestCaseStatus.equalsIgnoreCase("Pass")).count();
long FailCount = entry.getValue().stream().filter(e -> e.TestCaseStatus.equalsIgnoreCase("Fail")).count();
browserResult.Browser=entry.getKey();
browserResult.TCTotalCount=(int) total;
browserResult.TCPassCount=(int) PassCount;
browserResult.TCFailCount=(int) FailCount;
browserResult.TCSkippedCount=(int) (total-(PassCount+FailCount));
ReportContants.browserResults.add(browserResult);

}
}

public String getActionName(String PageStepName, String ActionName)
{
	
	if(PageStepName.equals(""))
	{
		return ActionName;
	}
	else
	{
		return PageStepName + "  ====>  "+ ActionName;
	}
}


public String getActionDesc(String PageStepDesc, String ActionDesc)
{
	
	if(PageStepDesc.equals(""))
	{
		return ActionDesc;
	}
	else
	{
		return PageStepDesc + "  ====>  "+ ActionDesc;
	}
}

public String getDuration(LocalDateTime StartTime, LocalDateTime EndTime)
{
	int totalSecs = EndTime.getSecond() - StartTime.getSecond();
	
	
	int hours = totalSecs / 3600;
	int minutes = (totalSecs % 3600) / 60;
	int seconds = totalSecs % 60;
	
	String strhours = String.valueOf(hours);
	String strminutes = String.valueOf(minutes);
	String strseconds = String.valueOf(seconds);

	if(strhours.length()==1)
	{
		strhours="0"+strhours;
	}

	if(strminutes.length()==1)
	{
		strminutes="0"+strminutes;
	}

	if(strseconds.length()==1)
	{
		strseconds="0"+strseconds;
	}

	//testCaseResult.Duration=String.valueOf(hours)+ ":" + String.valueOf(minutes)+ ":"+String.valueOf(seconds);

	return strhours +":" + strminutes+ ":" + strseconds;

}

public  String ConvertLocalDateTimetoSQLDateTime(LocalDateTime localdateTime)
{
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	String date = localdateTime.format(formatter);
	
	return date;
}

public String getTimeDifference(LocalDateTime StartTime, LocalDateTime EndTime)



{

Duration duration = Duration.between(StartTime, EndTime);

long seconds = duration.getSeconds();

 

String formattedDuration = String.format("%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60);

return formattedDuration;

}

}

