package PDFValidation;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.fit.pdfdom.PDFDomTree;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import CommonUtilities.Utilities.Util;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.ExtentUtilities;
import UITests.TestNG.Common.ExcelUtility;

public class ReadPFDBox {
	private static final Logger logger =LoggerFactory.getLogger(ReadPFDBox.class.getName());
	ExtentUtilities extentUtilities = new ExtentUtilities();
	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	ReportCommon TestStepDetails = new ReportCommon();
	private static final String Status_Pass="PASS";
	private static final String Status_Fail="FAIL";
	private static final String Status_Done="DONE";
	Util util = new Util();
	
	ExcelUtility excelutil=new ExcelUtility();
	HashMap<String, ArrayList<String>> TestCaseData_DBQScreen = new HashMap<String, ArrayList<String>>();
	public ReadPFDBox(){ }
	public ReadPFDBox(WebDriver _driver,TestCaseParam testCaseParam) throws Exception { InitializePage(_driver,testCaseParam);
	}
	public void InitializePage(WebDriver _driver,TestCaseParam testCaseParam) throws Exception
	{
		driver = _driver;
		PageFactory.initElements(driver, this);
		ReportCommon TestStepLogDetails = new ReportCommon(); 
	//	TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
	}
	// public static void main(String[] args) throws Exception 
	// {
	// Util util = new Util();
	// Properties prop=new Properties();
	//
	// Path currentRelativePath = Paths.get(""); 
	// String PrjPath=currentRelativePath.toAbsolutePath().toString();
	// prop=util.loadProperties(PrjPath+PrjConstants.ConfigFile);
	//
	// TestRunSettings.ArtifactsPath = prop.getProperty("ArtifactsPath");
	// TestRunSettings.SourcePDFfile = prop.getProperty("SourcePDFfile");
	// TestRunSettings.TargetPDFfile = prop.getProperty("TargetPDFfile");
	// TestRunSettings.PdfExtension = prop.getProperty("PdfExtension");
	// TestRunSettings.Resultfile = prop.getProperty("Resultfile");
	// TestRunSettings.TextFile = prop.getProperty("TextFile");
	// TestRunSettings.SourceTextFile = prop.getProperty("SourceTextFile");
	// TestRunSettings.TargetTextFile = prop.getProperty("TargetTextFile");
	// TestRunSettings.ReplacedTextFile = prop.getProperty("ReplacedTextFile");
	//
	// String PdfSourceFile = TestRunSettings.ArtifactsPath+TestRunSettings.SourcePDFfile + TestRunSettings.PdfExtension;
	// String PdfTargetFile = TestRunSettings.ArtifactsPath+TestRunSettings.TargetPDFfile+TestRunSettings.PdfExtension;
	// String Resultfile = TestRunSettings.ArtifactsPath+TestRunSettings.Resultfile;
	// //String SourceTextFile = TestRunSettings.ArtifactsPath+TestRunSettings.SourceTextFile;
	// String TargetTextFile = TestRunSettings.ArtifactsPath+TestRunSettings.TargetTextFile;
	// String ReplacedTextFile = TestRunSettings.ArtifactsPath+TestRunSettings.ReplacedTextFile;
	// //validatepdfvspdfCompareLine(PdfSourceFile,PdfTargetFile,Resultfile,ReplacedTextFile,TargetTextFile);
	// }
	
//	public void validatepdfvspdfCompareLine(TestCaseParam testCaseParam, String PdfSourceFile, String PdfTargetFile, String ResultFile, String ReplacedTextFile, String TargetTextFile, int count1) throws Exception 
//	{
//		try {
//			LocalDateTime StartTime= LocalDateTime.now();
//			
//			File file1 = new File(PdfSourceFile);
//			PDDocument document = PDDocument.load(file1);
//			File file2 = new File(PdfTargetFile);
//			PDDocument document2 = PDDocument.load(file2);
//			int totalpageofDocument1 = getPageCount(document);
//			int totalpageofDocument2 = getPageCount(document2);
//			String Action;
//			String ActionDescription;
//			if(totalpageofDocument1==totalpageofDocument2) { 
//				for(int i=1;i<(totalpageofDocument1-count1)+1;i++) {
//					Action = "Verify PDF Page"+i;
//					ActionDescription = "Verify PDF Page"+i;
//					String Action1 = "Verified Page"+i+":: Pass";
//					String ActionDescription1 = "Verified Page"+i+":: Pass";
//					String testcontant2 = readPdfContent(document2,i,totalpageofDocument2-(totalpageofDocument2-i));
//					BufferedWriter out2 = new BufferedWriter(new FileWriter(TargetTextFile+i+".txt" , StandardCharsets.UTF_8));
//					out2.write("");
//					out2.write(testcontant2);
//					out2.close();
//					System.out.println("TargetfilePage Page"+i+" saved as TXT");
//					StringBuilder stringBuilder = new StringBuilder();
//			try (FileReader fileReader = new FileReader(ReplacedTextFile+"\\"+"ReplacedTextFile"+i+".txt",StandardCharsets.UTF_8);
//
//							BufferedReader bufferedReader = new BufferedReader(fileReader)) {
//						int character;
//						while ((character = bufferedReader.read()) != -1) {
//							stringBuilder.append((char) character);
//						}
//					} catch (IOException e) {
//						System.out.println("Error reading file: " + e.getMessage());
//					}
//					String testcontant1 = stringBuilder.toString().replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", "");
//					if(!testcontant1.equalsIgnoreCase(testcontant2.replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", ""))){
//						String TC1 = testcontant2.replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", "");
//						List<String> linenumber = textdiffutil(ReplacedTextFile+i+".txt",TargetTextFile+i+".txt");
//						//BufferedWriter out = new BufferedWriter(new FileWriter(ResultFile+i+".txt"));
//						//out.write("");
//						//out.write("Difference in lines of SourcefilePage"+i+"::\r\n"+linenumber);
//						TestStepDetails.logPDFDetails(driver, testCaseParam, Action+"\r\n"+linenumber, ActionDescription+"\r\n"+linenumber, StartTime, Status_Fail,"Difference in lines of SourcefilePage"+i+"::\r\n"+linenumber);
//						//out.close();
//						System.out.println("Source and Target Page"+i+":: Didn't match");
//					}else {
//						System.out.println("Page"+i+"are equal");
//						TestStepDetails.logPDFDetailsPass(driver, testCaseParam, Action1, ActionDescription1, StartTime, Status_Pass);
//					}
//				}
//			}else {
//				System.out.println("Page count for Source and Target PDF mismatched");
//			}
//		}
//		catch (Exception e){
//		}
//	}
	public void validatepdfvspdfCompareLine(TestCaseParam testCaseParam, String PdfSourceFile, String PdfTargetFile, String ResultFile, String ReplacedTextFile, String TargetTextFile, int count1) throws Exception 
	{
		try {
			LocalDateTime StartTime= LocalDateTime.now();
			
			File file1 = new File(PdfSourceFile);
			PDDocument document = PDDocument.load(file1);
			File file2 = new File(PdfTargetFile);
			PDDocument document2 = PDDocument.load(file2);
			int totalpageofDocument1 = getPageCount(document);
			int totalpageofDocument2 = getPageCount(document2);
			String Action;
			String ActionDescription;
			File directory;
			if(totalpageofDocument1==totalpageofDocument2) { 
				for(int i=1;i<(totalpageofDocument1-count1)+1;i++) {
					Action = "Verify PDF Page"+i;
					ActionDescription = "Verify PDF Page"+i;
					String Action1 = "Verified Page"+i+":: Pass";
					String ActionDescription1 = "Verified Page"+i+":: Pass";
					String testcontant2 = readPdfContent(document2,i,totalpageofDocument2-(totalpageofDocument2-i));
					
					directory = new File(TargetTextFile);
				    if (! directory.exists()){
				        directory.mkdirs();
				    }
					
					BufferedWriter out2 = new BufferedWriter(new FileWriter(TargetTextFile+"\\TargetTextFile"+i+".txt",StandardCharsets.UTF_8));
					
					out2.write("");
					out2.write(testcontant2);
					out2.close();
					System.out.println("TargetfilePage Page"+i+" saved as TXT");
					StringBuilder stringBuilder = new StringBuilder();
//					try (FileReader fileReader = new FileReader(ReplacedTextFile+"\\"+"ReplacedTextFile"+i+".txt",StandardCharsets.UTF_8);
//						BufferedReader bufferedReader = new BufferedReader(fileReader)) 
//						{
//						int character;
//						while ((character = bufferedReader.read()) != -1) {
//							stringBuilder.append(character);
//						}
//					} catch (IOException e) {
//						System.out.println("Error reading file: " + e.getMessage());
//					}
					
					BufferedReader br=new BufferedReader(new FileReader(ReplacedTextFile+"\\"+"ReplacedTextFile"+i+".txt",StandardCharsets.UTF_8));
					String replacedtxtlines=br.readLine();
					while(replacedtxtlines!=null) 
					{
						stringBuilder.append(replacedtxtlines);
						replacedtxtlines=br.readLine();
						
					}
					
					
					Thread.sleep(6000);
					String testcontant1 = stringBuilder.toString().trim().replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", "");

					
					testcontant2=testcontant2.trim().replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", "");
					if(!testcontant1.equalsIgnoreCase(testcontant2)){
						String TC1 = testcontant2.replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", "");
	
						String TargettxtFile=TargetTextFile+"\\TargetTextFile"+i+".txt";
						
						
						String replacedtxtFile=ReplacedTextFile+"\\ReplacedTextFile"+i+".txt";
						List<String> linenumber = textdiffutil(replacedtxtFile,TargettxtFile);
						directory = new File(ResultFile);
					    if (! directory.exists())
					    {
					        directory.mkdirs();
					    }
						BufferedWriter out = new BufferedWriter(new FileWriter(ResultFile+"\\ResultFile"+i+".txt",StandardCharsets.UTF_8));
						out.write("");
						out.write("Difference in lines of SourcefilePage"+i+"::\r\n"+linenumber);
						TestStepDetails.logPDFDetails(driver, testCaseParam, Action+"\r\n"+linenumber, ActionDescription+"\r\n"+linenumber, StartTime, Status_Fail,"Difference in lines of SourcefilePage"+i+"::\r\n"+linenumber);
						out.close();
						System.out.println("Source and Target Page"+i+":: Didn't match");
					}else {
						System.out.println("Page"+i+"are equal");
						TestStepDetails.logPDFDetailsPass(driver, testCaseParam, Action1, ActionDescription1, StartTime, Status_Pass);
					}
				}
			}else {
				System.out.println("Page count for Source and Target PDF mismatched");
			}
		}
		catch (Exception e)
		{Thread.sleep(0);
			throw e;
		}
	}
	
	public static List<String> textdiffutil(String path1, String path2) throws Exception {
		FileReader fileReader1 = new FileReader(path1);
		FileReader fileReader2 = new FileReader(path2);
		List<String> lines1 = readLines(fileReader1);
		List<String> lines2 = readLines(fileReader2);
		List<String> delta1 = new ArrayList();
//		Patch<String> patch = DiffUtils.diff(lines1, lines2);
//		for (AbstractDelta<String> delta : patch.getDeltas()) {
//			String del = delta.toString();
//			if(del.contains("lines: []]") || del.contains("lines: [, ")) {
//			}
//			else {
//				delta1.add(delta.toString().trim().replaceAll("\\s", "").replaceAll("\\r\\n", "").replaceAll("\\t", ""));
//				System.out.println(delta.toString());
//
//			} 
//		}
		return delta1;
	}

	public static List<String> readLines(final Reader reader) throws IOException {
		final BufferedReader bufReader = toBufferedReader(reader);
		final List<String> list = new ArrayList<>();
		String line;
		while ((line = bufReader.readLine()) != null) {
			
			list.add(line.trim().replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", ""));
		}
		return list;
	}
	public static BufferedReader toBufferedReader(final Reader reader) {
		return reader instanceof BufferedReader ? (BufferedReader) reader : new BufferedReader(reader);
	}
	public static String readPdfContent(PDDocument document,int firstpage, int lastpage) throws IOException {
		// URL pdfUrl = new URL(file:///C:/Users/sahlalwani/Documents/STOMACH-pdf-generated.pdf);
		// InputStream in = pdfUrl.openStream();
		// BufferedInputStream bf = new BufferedInputStream(in);
		PDFTextStripper pdfStripper = new PDFTextStripper();
		pdfStripper.setStartPage(firstpage);
		pdfStripper.setEndPage(lastpage);
		String text = pdfStripper.getText(document);
		return text.trim().replaceAll("\\s", "").replaceAll("\\n", "").replaceAll("\\t", "");
	}
	public static int getPageCount(PDDocument doc) {
		//get the total number of pages in the pdf document
		int pageCount = doc.getNumberOfPages();
		System.out.println(pageCount);
		return pageCount;
	}
	public static boolean compareImage() { 
		try {
			File fileA = new File("C:/Users/sahlalwani/Documents/GeeksforGeeks.png");
			File fileB = new File("C:/Users/sahlalwani/Documents/GeeksforGeeks1.png");
			// take buffer data from botm image files //
			BufferedImage biA = ImageIO.read(fileA);
			DataBuffer dbA = biA.getData().getDataBuffer();
			int sizeA = dbA.getSize(); 
			BufferedImage biB = ImageIO.read(fileB);
			DataBuffer dbB = biB.getData().getDataBuffer();
			int sizeB = dbB.getSize();
			// compare data-buffer objects //
			if(sizeA == sizeB) {
				for(int i=0; i<sizeA; i++) { 
					if(dbA.getElem(i) != dbB.getElem(i)) {
						return false;
					}
				}
				return true;
			}
			else {
				return false;
			}
		} 
		catch (Exception e) { 
			System.out.println("Failed to compare image files ...");
			return false;
		}
	}
	public static float compareImagePer() {
		File fileA = new File("C:/Users/sahlalwani/Documents/GeeksforGeeks.png");
		File fileB = new File("C:/Users/sahlalwani/Documents/GeeksforGeeks1.png");
		float percentage = 0;
		try {
			// take buffer data from both image files //
			BufferedImage biA = ImageIO.read(fileA);
			DataBuffer dbA = biA.getData().getDataBuffer();
			int sizeA = dbA.getSize();
			BufferedImage biB = ImageIO.read(fileB);
			DataBuffer dbB = biB.getData().getDataBuffer();
			int sizeB = dbB.getSize();
			int count = 0;
			// compare data-buffer objects //
			if (sizeA == sizeB) {
				for (int i = 0; i < sizeA; i++) {
					if (dbA.getElem(i) == dbB.getElem(i)) {
						count = count + 1;
					}
				}
				percentage = (count * 100) / sizeA;
			} else {
				System.out.println("Both the images are not of same size");
			}
		} catch (Exception e) {
			System.out.println("Failed to compare image files ...");
		}
		return percentage;
	}
	// Main driver method
	public static void PixltoPixlComapre()
	{
		// Initially assigning null
		BufferedImage imgA = null;
		BufferedImage imgB = null;
		// Try block to check for exception
		try {
			// Reading file from local directory by
			// creating object of File class
			File fileA = new File("C:/Users/sahlalwani/Documents/GeeksforGeeks.png");
			File fileB = new File("C:/Users/sahlalwani/Documents/GeeksforGeeks1.png");
			// Reading files
			imgA = ImageIO.read(fileA);
			imgB = ImageIO.read(fileB);
		}
		// Catch block to check for exceptions
		catch (IOException e) {
			// Display the exceptions on console
			System.out.println(e);
		}
		// Assigning dimensions to image
		int width1 = imgA.getWidth();
		int width2 = imgB.getWidth();
		int height1 = imgA.getHeight();
		int height2 = imgB.getHeight();
		// Checking whether the images are of same size or
		// not
		if ((width1 != width2) || (height1 != height2))
			// Display message straightaway
			System.out.println("Error: Images dimensions"
					+ " mismatch");
		else {
			// By now, images are of same size
			long difference = 0;
			// treating images likely 2D matrix
			// Outer loop for rows(height)
			for (int y = 0; y < height1; y++) {
				// Inner loop for columns(width)
				for (int x = 0; x < width1; x++) {
					int rgbA = imgA.getRGB(x, y);
					int rgbB = imgB.getRGB(x, y);
					int redA = (rgbA >> 16) & 0xff;
					int greenA = (rgbA >> 8) & 0xff;
					int blueA = (rgbA)&0xff;
					int redB = (rgbB >> 16) & 0xff;
					int greenB = (rgbB >> 8) & 0xff;
					int blueB = (rgbB)&0xff;
					difference += Math.abs(redA - redB);
					difference += Math.abs(greenA - greenB);
					difference += Math.abs(blueA - blueB);
				}
			}
			// Total number of red pixels = width * height
			// Total number of blue pixels = width * height
			// Total number of green pixels = width * height
			// So total number of pixels = width * height *
			// 3
			double total_pixels = width1 * height1 * 3;
			// Normalizing the value of different pixels
			// for accuracy
			// Note: Average pixels per color component
			double avg_different_pixels
			= difference / total_pixels;
			// There are 255 values of pixels in total
			double percentage
			= (avg_different_pixels / 255) * 100;
			// Lastly print the difference percentage
			System.out.println("Difference Percentage-->"
					+ percentage);
		}
	}
//	public static void compareimgapi() {
//		Comparer comparer = new Comparer("C://Users//sahlalwani//Documents//GeeksforGeeks.png");
//		comparer.add("C://Users//sahlalwani//Documents//GeeksforGeeks1.png");
//		comparer.compare("C://sahlalwani//Documents//results//ResultGeeksforGeeks1");
//		// try (Comparer comparer = new Comparer("C:/Users/sahlalwani/Documents/STOMACH-pdf-generated.pdf")) {
//		// comparer.add("C:/Users/sahlalwani/Documents/STOMACH-pdf-generated.pdf");
//		// comparer.compare("C:/Users/sahlalwani/Documents/ResultforSTOMACH-pdf-generated.pdf");
//		// }
//		// catch (Exception e) {
//		// // Display the exceptions on console
//		// System.out.println(e);
//		// }
//	}
//	public static void convertpdftoword() {
//		PdfDocument doc = new PdfDocument();
//		//Load a sample PDF document
//		doc.loadFromFile("C://Users//sahlalwani//Documents//STOMACH-pdf-generated.pdf");
//		//Convert PDF to Doc and save it to a specified path
//		//doc.saveToFile("output/ToDoc.doc", FileFormat.DOC);
//		//Convert PDF to Docx and save it to a specified path
//		doc.saveToFile("C://Users//sahlalwani//Documents//STOMACH-pdf-generated.docx", FileFormat.DOC);
//		doc.close();
//	}
	// public static String updatetext(String Placeholderfile) {
	//
	// Document pdfDocument = new Document(Placeholderfile);
	// // Create TextAbsorber object to find all instances of the input search phrase
	// TextFragmentAbsorber textFragmentAbsorber = new TextFragmentAbsorber("#PatientName#");
	// // Accept the absorber for all pages of document
	// pdfDocument.getPages().accept(textFragmentAbsorber);
	//
	// // Get the extracted text fragments into collection
	// TextFragmentCollection textFragmentCollection = textFragmentAbsorber.getTextFragments();
	//
	//
	// // Loop through the fragments
	// for (TextFragment textFragment : (Iterable<TextFragment>) textFragmentCollection) {
	// // Update text and other properties
	// textFragment.setText("TESTUSERNAME");
	// //textFragment.getTextState().setFont(FontRepository.findFont("Courier New"));
	// //textFragment.getTextState().setFontSize(7.5f);
	// //textFragment.getTextState().setForegroundColor(Color.getBlue());
	// //textFragment.getTextState().setBackgroundColor(Color.getGray());
	// }
	// // Save the updated PDF file
	// String outputfilename = "C://Users//sahlalwani//Documents//STOMACH-pdf-generatedpatientName2.pdf";
	// pdfDocument.save(outputfilename);
	// return outputfilename;
	// }
	public static void PDFtoHTML(String sourcepdf, String outputfile) throws Exception {
		// Load the PDF document
		PDDocument document = PDDocument.load(new File(sourcepdf));
		PDFDomTree parser = new PDFDomTree();
		Writer output = new PrintWriter(outputfile, "utf-8");
//		parser.writeText(document, output);
		output.close();
		// Convert the PDF to HTML
		// PDFText2HTML converter = new PDFText2HTML();
		// converter.setStartPage(1);
		// converter.setEndPage(document.getNumberOfPages());
		// converter.setSortByPosition(true);
		// converter.setShouldSeparateByBeads(true);
		// converter.setSortByPosition(true);
		// converter.setDestinationDir(new File("output"));
		// converter.setSource(document);
		// converter.convert();
		//
		// // Close the PDF document
		// document.close();
	}
	public static String Targetfiletxt(String Targetfile, String PlaceHolder, String TestData, int Noofplhld) {
//		Document pdfDocument = new Document(Targetfile);
//		// Create TextAbsorber object to find all instances of the input search phrase
//		TextFragmentAbsorber textFragmentAbsorber = new TextFragmentAbsorber("#Vet#");
//		// Accept the absorber for all pages of document
//		pdfDocument.getPages().accept(textFragmentAbsorber);
//		// Get the extracted text fragments into collection
//		TextFragmentCollection textFragmentCollection = textFragmentAbsorber.getTextFragments();
//		// Loop through the fragments
//		for (TextFragment textFragment : (Iterable<TextFragment>) textFragmentCollection) {
//			// Update text and other properties
//			textFragment.setText("123455");
//			//textFragment.getTextState().setFont(FontRepository.findFont("Times New Roman"));
//			//textFragment.getTextState().setFontSize(7.5f);
//			//textFragment.getTextState().setForegroundColor(Color.getBlue());
//			//textFragment.getTextState().setBackgroundColor(Color.getGray());
//			//textFragment.getTextState().setStrokingColor(Color.getWhite());
//		}
		// Save the updated PDF file
		String outputfilename = "C://Users//sahlalwani//Documents//STOMACH-pdf-replacedtest12341.pdf";
//		pdfDocument.save(outputfilename);
		return outputfilename;
	}
}
// String[] words1 = testcontant1.split(" "); 
// String[] words2 = testcontant2.split(" ");
//
// HashSet<String> set1 = new HashSet<>(Arrays.asList(words1));
// HashSet<String> set2 = new HashSet<>(Arrays.asList(words2));
// set1.removeAll(set2); 
// set2.removeAll(Arrays.asList(words1));
// System.out.println("Different words in Source String in Page"+i+": " + set1); 
// System.out.println("Different words in Target String in Page"+i+": "+ set2);
//
//List<String> listOne = Arrays.asList(testcontant1.split(" "));
//
//List<String> listTwo = Arrays.asList(testcontant2.split(" "));
//
//Collection<String> similar = new HashSet<String>( listOne );
//Collection<String> different = new HashSet<String>();
//for(int j =0;listOne.size()>j;j++ ) {
// try {
// if(listOne.get(j).toString().equals(listTwo.get(j))) {
// 
// }
//
// }
// catch(Exception e) {
//
// }
//}
// different.addAll( listOne );
// different.addAll( listTwo );
//
// similar.retainAll( listTwo );
// different.removeAll( similar);
//System.out.println(different);
