package PDFValidation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

import Constants.PrjConstants;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;
import org.apache.pdfbox.pdmodel.PDDocument;

public class WritePDFtoTxtUtility {


	public static void main(String[] args) throws Exception 
	{
		String FileName="EDB-090.PDF";
		String Folder="MA\\MAGI_NMAGI\\noe";
		Util util = new Util();
		Properties prop=new Properties();

		Path currentRelativePath = Paths.get(""); 
		String PrjPath=currentRelativePath.toAbsolutePath().toString();
		prop=util.loadProperties(PrjPath+PrjConstants.ConfigFile);
		TestRunSettings.ArtifactsPath = prop.getProperty("ArtifactsPath");
		TestRunSettings.SourcePDFfile = prop.getProperty("SourcePDFfile");
		TestRunSettings.TargetPDFfile = prop.getProperty("TargetPDFfile");
		TestRunSettings.PdfExtension = prop.getProperty("PdfExtension");
		TestRunSettings.Resultfile = prop.getProperty("Resultfile");
		TestRunSettings.TextFile = prop.getProperty("TextFile");
		TestRunSettings.SourceTextFile = prop.getProperty("SourceTextFile"); 
		TestRunSettings.TargetTextFile = prop.getProperty("TargetTextFile");
		
		
		ReplacePlaceholders placeholders=new ReplacePlaceholders();
//		String Files[]=placeholders.ListofFiles(TestRunSettings.ArtifactsPath+"\\"+TestRunSettings.SourcePDFfile+"\\DSNAP");
//		int filescount=Files.length;
		
		//for(int i=0; i<filescount; i++) 
		{
			String PdfSourceFile = TestRunSettings.ArtifactsPath+"\\PDF\\SourcePDFfile\\"+Folder+"\\"+FileName;
			String SourceTextFile = TestRunSettings.ArtifactsPath+"\\PDF\\SourceTextFile\\"+Folder+"\\SourceTextFile";
			String SourceTextFilelocation = TestRunSettings.ArtifactsPath+"\\PDF\\SourceTextFile\\"+Folder;

			WritePDFtoTextFile(PdfSourceFile, SourceTextFile,SourceTextFilelocation);
		}
		



	}

	public static void WritePDFtoTextFile(String PdfSourceFile,String SourceTextFile, String SourceTextFilelocation) throws Exception 
	{
		try {
			new StringBuilder();
			File directory;
			File file1 = new File(PdfSourceFile);
			PDDocument document = PDDocument.load(file1);
			int totalpageofDocument1 = getPageCount(document);	
			for(int i=1;i<totalpageofDocument1+1;i++) {
				String testcontant1 = readPdfContent(document,i,totalpageofDocument1-(totalpageofDocument1-i));
				directory = new File(SourceTextFilelocation);
			    if (! directory.exists()){
			        directory.mkdirs();
			    }
				BufferedWriter out1 = new BufferedWriter(new FileWriter(SourceTextFile+i+".txt", StandardCharsets.UTF_8));
				out1.write("");
				out1.write(testcontant1);
				out1.close();
				System.out.println("SourcefilePage Page"+i+" saved as TXT");
			}
		}
		catch (Exception e) {
			System.out.println("Unable to read source file");
		}
	}
	public static int getPageCount(PDDocument doc) {
		//get the total number of pages in the pdf document
		int pageCount = doc.getNumberOfPages();
		System.out.println(pageCount);
		return pageCount;

	}
	public static  String readPdfContent(PDDocument document,int firstpage, int lastpage) throws IOException {
		PDFTextStripper pdfStripper = new PDFTextStripper();
		pdfStripper.setStartPage(firstpage);
		pdfStripper.setEndPage(lastpage);
		String text = pdfStripper.getText(document);
		return text;
	}
}
