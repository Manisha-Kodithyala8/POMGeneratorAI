package PDFValidation;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Common.ScreenshotCommon;
import Constants.LoginConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.ExtentUtilities;
import ReportUtilities.Model.ExtentModel.PageDetails;
import TestSettings.SessionData;
import TestSettings.TestRunSettings;
import UITests.TestNG.Common.TestNGCommon;
import CommonUtilities.Utilities.Util;

public class PDFValidation extends TestNGCommon
{
	private WebDriver driver;
	String Browser = "";
	ExtentUtilities extentUtilities = new ExtentUtilities();
	ScreenshotCommon SCM = new ScreenshotCommon();
	Util util = new Util();
	HashMap<String, ArrayList<String>> TestCaseData_Execution = new HashMap<String, ArrayList<String>>();
	
	String ApplicationNumber = "0";
	String CaseNumber = "0";
	String TestCaseStatus = "0";
	TestCaseParam testCaseParam = new TestCaseParam();
	ReportCommon TestStepDetails = new ReportCommon();
	String ModuleName="PDF validation";
	String ScreenName="PDF validation";

	public PDFValidation()
	{

	}
	
	 public PDFValidation(WebDriver _driver,TestCaseParam testCaseParam) throws Exception
	    {
	        driver = _driver;
	        PageFactory.initElements(driver, this);
	        ReportCommon TestStepLogDetails = new ReportCommon(); 
	        TestStepLogDetails.logModuleAndScreenDetails(testCaseParam, ModuleName, ScreenName);
	        

	        
	    }

	@BeforeClass
	public void SetUp_TD_AR_DC()
	{
		
		driver = TestRunSettings.driver;
        Browser = TestRunSettings.Browser;
        testCaseParam.TestCaseName = "ValidatePDF";
        testCaseParam.ModuleName = ModuleName;
        testCaseParam.Browser = TestRunSettings.Browser;
        testCaseParam.CaseNumber=CaseNumber;
    	testCaseParam.ApplicationNumber=ApplicationNumber;
        testCaseParam.TestCaseDescription = testCaseParam.TestCaseName;
        InitializeTestCase(testCaseParam);
        driver = InitializeDriver();
	}
	@Test
	public void run() throws Exception 
	{
		String NoticeName="Requirement of Information KTAP";
		String Folder="KTAP\\RFI";
		String SourcePdfName="KTAP_RFI";
		String TargetPdfName="KTAP_RFI_T";
		CaseNumber="113216371";
		ValidatePDFData(testCaseParam,CaseNumber,NoticeName,Folder,SourcePdfName, TargetPdfName,"Pending");
	}
	
	
	
	public void ValidatePDFData(TestCaseParam testCaseParam,String CaseNumber,String NoticeName,String Folder,String SourcePDF, String TargetPDF,String NoticeStatus) throws Exception
	{    
		
		System.out.println("Execution Started:"+testCaseParam.TestCaseName);

		
		PageDetails pageDetails=new PageDetails();
		pageDetails.PageActionName = "PDF Validation";
		pageDetails.PageActionDescription = "PDF Validation";

		//***************************************************************************

		String PDFdirectory=TestRunSettings.ArtifactsPath+"\\PDF";
		
		
		  //**************Need to Change as per required User Role********************// PDF Validation
			
		 String SourceTextFile = TestRunSettings.ArtifactsPath+"\\PDF\\SourceTextFile\\"+Folder;
		 String ReplacedTextFile = TestRunSettings.ArtifactsPath+"\\PDF\\ReplacedTextFile\\"+Folder;
		 String PdfSourceFile = TestRunSettings.ArtifactsPath+ "\\PDF\\SourcePDFfile\\"+Folder+"\\"+SourcePDF+".PDF";
		 String PdfTargetFile = TestRunSettings.ArtifactsPath+"\\PDF\\TargetPDFfile\\"+Folder+"\\"+TargetPDF+".PDF";
		 String Resultfile = TestRunSettings.ArtifactsPath+"\\PDF\\Results"+"\\"+Folder;
		 String TargetTextFile = TestRunSettings.ArtifactsPath+"\\PDF\\TargetTextFile"+"\\"+Folder;


	    ReplacePlaceholders placeholder=new ReplacePlaceholders();
		placeholder.replaceData(testCaseParam, SourceTextFile, ReplacedTextFile);

		ReadPFDBox readPFDBox = new ReadPFDBox(driver, testCaseParam);
		readPFDBox.validatepdfvspdfCompareLine(testCaseParam,PdfSourceFile,PdfTargetFile,Resultfile,ReplacedTextFile,TargetTextFile,0);

	}
	

	@AfterClass
	public void TearDown_TD_AR_DC() throws Exception
	{
		publishTestCaseResults(testCaseParam);
		QuitDriver(driver);

	}
}  
