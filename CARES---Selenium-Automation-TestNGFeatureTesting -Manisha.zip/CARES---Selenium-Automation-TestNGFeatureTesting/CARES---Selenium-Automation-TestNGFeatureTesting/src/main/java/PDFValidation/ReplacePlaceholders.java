package PDFValidation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;

import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.PageDetails;
import TestSettings.TestRunSettings;

public class ReplacePlaceholders 
{
	public void replaceData(TestCaseParam testCaseParam, String SourceTextFilePath, String ReplacedTextFile)throws Exception{
		PageDetails pageDetails=new PageDetails();
		
		LocalDateTime StartTime= LocalDateTime.now();
		pageDetails.PageActionName = "Replace";
		pageDetails.PageActionDescription = "Replace";
		try {
			//String files[]=ListofFiles(SourceTextFilePath);
			
			ArrayList<String> files=ListofFile(SourceTextFilePath);
			int filescount=files.size();
			File directory;
			
			for(int i=0; i<filescount; i++) 
			{
				StringBuilder stringBuilder = new StringBuilder();
				try (FileReader fileReader = new FileReader(SourceTextFilePath+"\\"+files.get(i),StandardCharsets.UTF_8);
						BufferedReader bufferedReader = new BufferedReader(fileReader)) {
					int character;
					while ((character = bufferedReader.read()) != -1) {
						stringBuilder.append((char) character);
					}

				} catch (IOException e) {
					System.out.println("Error reading file: " + e.getMessage());
				}
				String fileContent = stringBuilder.toString();


//				fileContent=SD.getSessionData(testCaseParam, fileContent);
				
				directory = new File(ReplacedTextFile);
			    if (! directory.exists()){
			        directory.mkdirs();
			    }
				//deletedirectory(TestRunSettings.ArtifactsPath+"\\PDF\\ReplacedTextFile\\");
				int count=i+1;
				BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ReplacedTextFile+"\\"+"ReplacedTextFile"+count+".txt"), StandardCharsets.UTF_8));
				writer.write(fileContent);
				writer.close();
				System.out.println("Texts replaced successfully.");
			}

		}
		catch (Exception e)
		{
			
			throw e;
		}    
	}
	
	public static List<String> getFileNamesInAlphanumericOrder(String directoryPath) {
        File directory = new File(directoryPath);

        List<String> fileNames = new ArrayList<>();

        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles();

            if (files != null) {
                Arrays.sort(files, new AlphanumericFileComparator());
                for (File file : files) {
                    if (file.isFile()) {
                        fileNames.add(file.getName());
                        System.out.println(file);
                    }
                }
            }
        }

        return fileNames;
    }
	
	static class AlphanumericFileComparator implements Comparator<File> {
        public int compare(File a, File b) {
            return a.getName().compareTo(b.getName());
        }
    }

    public static void main(String[] args) {
        String directoryPath = "your_directory_path_here";
        List<String> fileNames = getFileNamesInAlphanumericOrder(directoryPath);

        if (fileNames.isEmpty()) {
            System.out.println("No files found in the directory.");
        } else {
            System.out.println("File names in alphanumeric order:");
            for (String fileName : fileNames) {
                System.out.println(fileName);
            }
        }
    }


	public String[] ListofFiles(String Path) throws IOException {
	      File directoryPath = new File(Path);
	      //List of all files and directories
	      String[] contents = directoryPath.list();
	      List<String> fileNames = new ArrayList<>();
	      System.out.println("List of files and directories in the specified directory:");
	      for(int i=0; i<contents.length; i++) 
	      {
	    	  fileNames.add(contents[i]);
	         //System.out.println(contents[i]);
	      }
	      
	      
	      Collections.sort(fileNames, new NaturalOrderComparator());
	      String[] names = {};
	      for(int i=0; i<fileNames.size(); i++) 
	      {
	    	  names[i]=fileNames.get(i);
	    	  System.out.println(names[i]);
	      }
	      
	      return names;
	   }
	
	public ArrayList<String> ListofFile(String Path) throws IOException {
	      File directoryPath = new File(Path);
	      //List of all files and directories
	      String[] contents = directoryPath.list();
	      ArrayList<String> fileNames = new ArrayList<>();
	      System.out.println("List of files and directories in the specified directory:");
	      for(int i=0; i<contents.length; i++) 
	      {
	    	  fileNames.add(contents[i]);
	         //System.out.println(contents[i]);
	      }
	      
	      
	      Collections.sort(fileNames, new NaturalOrderComparator());
	      
	      
	      return fileNames;
	   }
	
	static class NaturalOrderComparator implements Comparator<String> {
        private static final Pattern PATTERN = Pattern.compile("(\\D*)(\\d+)(.*)");

        public int compare(String a, String b) {
            Matcher matcherA = PATTERN.matcher(a);
            Matcher matcherB = PATTERN.matcher(b);

            if (matcherA.matches() && matcherB.matches()) {
                String prefixA = matcherA.group(1);
                String prefixB = matcherB.group(1);

                int result = prefixA.compareTo(prefixB);

                if (result == 0) {
                    int numA = Integer.parseInt(matcherA.group(2));
                    int numB = Integer.parseInt(matcherB.group(2));
                    result = Integer.compare(numA, numB);
                }

                return result;
            }

            // Fallback to default string comparison if parsing fails
            return a.compareTo(b);
        }
    }
	
	public static void deletedirectory(String path) {
        File file = new File(path);
        File[] files = file.listFiles(); 
        for (File f:files) 
        {if (f.isFile() && f.exists()) 
            { f.delete();
            System.out.println("successfully deleted");
            }else{
            	System.out.println("cant delete a file due to open or error");
} }  }

}
