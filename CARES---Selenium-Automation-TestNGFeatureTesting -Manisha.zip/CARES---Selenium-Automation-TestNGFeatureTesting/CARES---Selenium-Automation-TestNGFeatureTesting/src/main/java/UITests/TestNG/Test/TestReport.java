package UITests.TestNG.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import ReportUtilities.Common.ScreenshotCommon;
import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;

import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;

import TestSettings.TestRunSettings;
import UITests.TestNG.Common.TestNGCommon;


public class TestReport extends TestNGCommon {

	
	private WebDriver driver;
    String Browser = "";
    ScreenshotCommon SCM = new ScreenshotCommon();
    Util util = new Util();
    HashMap<String, ArrayList<String>> TestCaseData_Execution = new HashMap<String, ArrayList<String>>();
	ReportCommon TestStepDetails = new ReportCommon();
    
    public TestReport()
    {
    	

    }

    @BeforeMethod
    public void SetUp_Report()
    {
    	System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver.exe");
    	ChromeOptions options= new ChromeOptions();
    	options.setAcceptInsecureCerts(true);
    	driver= new ChromeDriver(options);

    	System.out.print("Browser ==>"+TestRunSettings.Browser);
    	
        Browser = "Chrome";
    }
    
    @Test
    public void TestReports() throws Exception
    {

    	
    	PageDetails action = new PageDetails();
    	  TestCaseParam testCaseParam = new TestCaseParam();
          testCaseParam.TestCaseName = "TestReport 1";
          testCaseParam.ModuleName = "Smoke";
          testCaseParam.Browser = Browser;
          testCaseParam.TestCaseDescription = testCaseParam.TestCaseName;

			 ReportCommon reportCommon = new ReportCommon();

//          if (reportCommon.checkTestCaseExists(testCaseParam.TestCaseName, testCaseParam.ModuleName, testCaseParam.Browser) == null)
//          {
//        	  reportCommon.InitializeNewTestCase(testCaseParam.TestCaseName,  testCaseParam.TestCaseDescription,testCaseParam.ModuleName, testCaseParam.Browser);
//          }
//          else
//          {
//          }

    	LocalDateTime startTime =  LocalDateTime.now();
    	TestStepDetails.logTestStepDetails(driver,testCaseParam, "Step1","Step 1 Desc",action,startTime,"Done");	
    	TestStepDetails.logTestStepDetails(driver,testCaseParam, "Step2","Step 2 Desc",action,startTime,"Done");	
    	TestStepDetails.logTestStepDetails(driver,testCaseParam, "Step3","Step 3 Desc",action,startTime,"Done");	
    	TestStepDetails.logTestStepDetails(driver,testCaseParam, "Step4","Step 4 Desc",action,startTime,"Done");	
    	TestStepDetails.logTestStepDetails(driver,testCaseParam, "Step5","Step 5 Desc",action,startTime,"Done");	
    	TestStepDetails.logTestStepDetails(driver,testCaseParam, "Step6","Step 6 Desc",action,startTime,"Done");	
    	
    	
    }

    
    @AfterMethod
    public void TearDownMethod()
    {
    	driver.quit();
    }
}
