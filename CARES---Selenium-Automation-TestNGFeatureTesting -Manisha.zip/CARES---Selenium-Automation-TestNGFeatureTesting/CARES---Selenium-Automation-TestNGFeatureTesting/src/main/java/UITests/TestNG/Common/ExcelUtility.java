package UITests.TestNG.Common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import CommonUtilities.Common.POI_ReadExcel;
import ReportUtilities.Model.TestCaseParam;

public class ExcelUtility 
{
    HashMap<String,HashMap<String,ArrayList<String>>> sessiondata=new  LinkedHashMap<String,HashMap<String,ArrayList<String>>>();

	 public HashMap<String, ArrayList<String>> GetScreenTCData(TestCaseParam testCaseParam,String ScreenName, String TestCaseName,String TestDataLocation, String TestDataMappingFileName ,String TestDataMappingSheetName)
	    {

	        POI_ReadExcel poiObject = new POI_ReadExcel();
	        ArrayList<String> whereClause_TestData = new ArrayList<String>();
	        whereClause_TestData.add("ScreenName::" + ScreenName);
	        HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestDataMappingFileName, TestDataMappingSheetName, whereClause_TestData);

			return result;

	    }

	public HashMap<String, ArrayList<String>>enrollmentAppName(TestCaseParam testCaseParam,String ScreenName,String TestCaseName,String TestDataLocation, String TestDataMappingFileName ,String TestDataMappingSheetName) {
		POI_ReadExcel poiObject = new POI_ReadExcel();
		ArrayList<String> whereClause_TestData = new ArrayList<String>();
		whereClause_TestData.add("ScreenName::" + ScreenName);
		HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestDataMappingFileName, TestDataMappingSheetName, whereClause_TestData);

		POI_ReadExcel poiObject2 = new POI_ReadExcel();
		ArrayList<String> whereClause_TestData2 = new ArrayList<String>();
		whereClause_TestData2.add("TestCase::" + TestCaseName);
	//	HashMap<String, ArrayList<String>> data = poiObject2.fetchWithCondition(TestDataLocation + "/" + result.get("TestDataFileName").get(0), result.get("TestDataSheetName").get(0), whereClause_TestData2);

		// Updated line with forward slashes
		HashMap<String, ArrayList<String>> data = poiObject2.fetchWithCondition(TestDataLocation + "/" + result.get("TestDataFileName").get(0), result.get("TestDataSheetName").get(0), whereClause_TestData2);
		return data;
	}
	}
