package UITests.TestNG.SD2;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import ReportUtilities.Common.ScreenshotCommon;
import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import CommonUtilities.Utilities.Util;
import Constants.PrjConstants;

import POM.SD.SauceCheckout;
import POM.SD.SauceConfirmation;
import POM.SD.SauceDetails;
import POM.SD.SauceLogin;
import POM.SD.SauceProduct;
import TestSettings.TestRunSettings;
import UITests.TestNG.Common.TestNGCommon;

public class SauceFailedScenario2 extends TestNGCommon {


	
	private WebDriver driver;
    String Browser = "";
    ScreenshotCommon SCM = new ScreenshotCommon();
    Util util = new Util();
    HashMap<String, ArrayList<String>> TestCaseData_Execution = new HashMap<String, ArrayList<String>>();
	ReportCommon TestStepDetails = new ReportCommon();
    TestCaseParam testCaseParam = new TestCaseParam();
    
    public SauceFailedScenario2()
    {
    	

    }

    @BeforeMethod
    public void SetUp_Report()
    {
    	driver = TestRunSettings.driver;
        Browser = TestRunSettings.Browser;
        testCaseParam.TestCaseName = "SauceFailedScenario2";
        testCaseParam.ModuleName = "SD";
        testCaseParam.Browser = TestRunSettings.Browser;
        testCaseParam.TestCaseDescription = testCaseParam.TestCaseName;
        InitializeTestCase(testCaseParam);
        driver = InitializeDriver();
        
    }
    
    @Test
    public void TestSauceFailedScenario2() throws Exception
    {

    	
    	SauceLogin login = new SauceLogin(driver, testCaseParam);
        login.ProcessSauceLogin(testCaseParam,"1");
    	Thread.sleep(PrjConstants.Delay);
    	
        SauceProduct sauceProduct = new SauceProduct(driver, testCaseParam);
        sauceProduct.ProcessSauceProduct(testCaseParam,"1");
    	Thread.sleep(PrjConstants.Delay);
    	
    	SauceCheckout sauceCheckout = new SauceCheckout(driver, testCaseParam);
    	sauceCheckout.ProcessSauceCheckout(testCaseParam,"1");
    	Thread.sleep(PrjConstants.Delay);
    	
    	SauceDetails sauceDetails = new SauceDetails(driver, testCaseParam);
    	sauceDetails.ProcessSauceDetails(testCaseParam,"1");
    	Thread.sleep(PrjConstants.Delay);    	

    	SauceConfirmation sauceConfirmation = new SauceConfirmation(driver, testCaseParam);
    	Assert.assertTrue(sauceConfirmation.ProcessSauceConfirmation(testCaseParam,"1"));
    	Thread.sleep(PrjConstants.Delay);

    }

    
    @AfterMethod
    public void TearDownMethod()
    {
    	EndTestCase(testCaseParam);
    	driver.quit();
    }

}
