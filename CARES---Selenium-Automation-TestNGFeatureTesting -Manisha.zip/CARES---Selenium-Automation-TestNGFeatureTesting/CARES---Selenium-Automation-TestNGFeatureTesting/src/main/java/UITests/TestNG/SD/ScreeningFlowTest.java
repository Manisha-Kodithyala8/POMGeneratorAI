package UITests.TestNG.SD;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import CommonUtilities.Utilities.Util;
import Constants.PrjConstants;
import POM.SD.Headers_Page;
import POM.SD.InitialScreening;
import POM.SD.Login;
import POM.SD.Screenings_Page;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Common.ScreenshotCommon;
import ReportUtilities.Model.TestCaseParam;
import TestSettings.TestRunSettings;
import UITests.TestNG.Common.TestNGCommon;

public class ScreeningFlowTest  extends TestNGCommon{
	
	private WebDriver driver;
    String Browser = "";
    ScreenshotCommon SCM = new ScreenshotCommon();
    Util util = new Util();
    HashMap<String, ArrayList<String>> TestCaseData_Execution = new HashMap<String, ArrayList<String>>();
	ReportCommon TestStepDetails = new ReportCommon();
    TestCaseParam testCaseParam = new TestCaseParam();
    
    public ScreeningFlowTest(){
    	
    }
    
    @BeforeMethod
    public void SetUp_Report()
    {
        Browser = TestRunSettings.Browser;
        testCaseParam.TestCaseName = "ScreeningHappyPath";
        testCaseParam.ModuleName = "SD";
        testCaseParam.Browser = Browser;
        testCaseParam.TestCaseDescription = testCaseParam.TestCaseName;
        InitializeTestCase(testCaseParam);
        driver = InitializeDriver();
    }
    
    @Test
    public void TestScreeningHappyPath() throws Exception
    {
    	Login objlogin = new Login(driver, testCaseParam);
    	objlogin.processLogin(testCaseParam,"1");
    	Thread.sleep(PrjConstants.Delay);
    	
//    	Headers_Page objHeaderPage = new Headers_Page(driver,testCaseParam);
//    	objHeaderPage.selectHeaderTab(testCaseParam,"Screenings");
//    	Thread.sleep(PrjConstants.Delay);
//    	
//    	Screenings_Page objSceenings = new Screenings_Page(driver,testCaseParam);
//    	objSceenings.clickNewBtn(testCaseParam);
//    	Thread.sleep(PrjConstants.Delay);
//    	
//    	InitialScreening objInitialScreening = new InitialScreening(driver,testCaseParam);
//    	objInitialScreening.addInitialScreeningInfo(testCaseParam,"1");
//    	Thread.sleep(PrjConstants.Delay);
    }

    @AfterMethod
    public void TearDownMethod()
    {
    	EndTestCase(testCaseParam);
    	driver.quit();
    }
}
