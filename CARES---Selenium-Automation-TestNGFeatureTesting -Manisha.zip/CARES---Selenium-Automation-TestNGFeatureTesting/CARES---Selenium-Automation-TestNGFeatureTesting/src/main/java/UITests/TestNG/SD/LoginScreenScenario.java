package UITests.TestNG.SD;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Constants.PrjConstants;
import Constants.ScreenConstants_SD;
import POM.SD.Initial_Screening;
import POM.SD.LoginScreen;
import POM.SD.SauceCheckout;
import POM.SD.SauceConfirmation;
import POM.SD.SauceDetails;
import POM.SD.SauceLogin;
import POM.SD.SauceProduct;
import TestSettings.SessionData;
import TestSettings.TestRunSettings;
import UITests.TestNG.Common.CommonOperations;
import UITests.TestNG.Common.TestNGCommon;
import ReportUtilities.Common.ScreenshotCommon;
import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import Constants.ModuleConstants_SD;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.*;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;


public class LoginScreenScenario extends TestNGCommon {


	
	private WebDriver driver;
    String Browser = "";
    ScreenshotCommon SCM = new ScreenshotCommon();
    Util util = new Util();
    HashMap<String, ArrayList<String>> TestCaseData_Execution = new HashMap<String, ArrayList<String>>();
	ReportCommon TestStepDetails = new ReportCommon();
    TestCaseParam testCaseParam = new TestCaseParam();
    CommonOperations objcommonOperations = null;
    String ModuleName = ModuleConstants_SD.SD;
    String ScreenName;
    
    public LoginScreenScenario()
    {
    	

    }

    @BeforeMethod
    public void SetUp_Report()
    {
        Browser = TestRunSettings.Browser;
        testCaseParam.TestCaseName = "ScreeningHappyPath";
        testCaseParam.ModuleName = "SD";
        testCaseParam.Browser = Browser;
        testCaseParam.TestCaseDescription = testCaseParam.TestCaseName;
        InitializeTestCase(testCaseParam);
        driver = InitializeDriver();
        
    }
    
    @Test
    public void TestSauceHappyPath() throws Exception
    {
    	ScreenName = ScreenConstants_SD.Login;
    	TestCaseData_Execution = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,"1");

		String URL = TestCaseData_Execution.get("URL").get(0);
		//String URL = "https://login.4.cares.cwds.ca.gov";
		String UserName = TestCaseData_Execution.get("UserName").get(0);

		String Password = TestCaseData_Execution.get("Password").get(0);

    	LoginScreen login = new LoginScreen(driver, testCaseParam);
    	login.Enter_URL(testCaseParam, URL);
    	login.Username(testCaseParam, UserName);
    	login.Password(testCaseParam, Password);
    	login.SignIn(testCaseParam, Browser);
    	login.SelectApp(testCaseParam, Browser);
    	objcommonOperations = new CommonOperations(driver);
    	objcommonOperations.switchToLastTab(driver);
		driver.switchTo().defaultContent();
		Thread.sleep(PrjConstants.Delay);
		ScreenName = ScreenConstants_SD.InitialScreenings_Page;
    	TestCaseData_Execution = util.GetScreenTCData(ScreenName, testCaseParam.TestCaseName,TestRunSettings.TestDataPath, TestRunSettings.TestDataMappingFileName ,TestRunSettings.TestDataMappingSheetName_SD,"1");
    	
    	String Date = TestCaseData_Execution.get("TodaysDate").get(0);
		String ScreeningName = TestCaseData_Execution.get("ScreeningName").get(0);
		String ScreeningNarrrative = TestCaseData_Execution.get("ScreeningNarrative").get(0);
		
		
		
    	Initial_Screening initialSCR = new Initial_Screening(driver, testCaseParam);
    	Thread.sleep(PrjConstants.Delay);
    	initialSCR.ScreeningsTab(testCaseParam, "");
    	Thread.sleep(PrjConstants.Delay);
    	initialSCR.NewBtn(testCaseParam, "");
    	Thread.sleep(PrjConstants.Delay);
    	initialSCR.Date(testCaseParam, CommonOperations.getDate("MM/dd/YYYY",Date));
    	//initialSCR.Time(testCaseParam, LocalDateTime.now().toLocalTime().toString());
    	initialSCR.ScreeningName(testCaseParam, ScreeningName);
    	initialSCR.ReasonForCallDrpDwn(testCaseParam, "");
    	initialSCR.ReasonForCallValue(testCaseParam, "");
    	initialSCR.ScreeningNarrative(testCaseParam, ScreeningNarrrative);
    	initialSCR.CallerType(testCaseParam, "");
    	initialSCR.CallBackRequiredDrpDwn(testCaseParam, "");
    	initialSCR.CallBackRequiredValue(testCaseParam, "");
    	initialSCR.SaveAndProceed(testCaseParam, "");
    }

    
    @AfterMethod
    public void TearDownMethod()
    {
    	EndTestCase(testCaseParam);
    	driver.quit();
    }

}
