package UITests.TestNG.Common;

import java.util.ArrayList;
import java.util.HashMap;

import CommonUtilities.Common.POI_ReadExcel;
import Constants.LoginConstants;
import TestSettings.TestRunSettings;

public class CommonImplementation {

	
	public void LoadLoginData()
    {
		
		POI_ReadExcel poiObject = new POI_ReadExcel();
		ArrayList<String> whereClause_TestData = new ArrayList<String>();
		whereClause_TestData.add("Environment::" + TestRunSettings.Environment);
		HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestRunSettings.ApplicationCredentialsFileName, TestRunSettings.ApplicationCredentialsSheetName, whereClause_TestData);
	
		
		System.out.println(result);
		LoginConstants loginconst = new LoginConstants();
		loginconst.loadLoginData(result);
	}
	
	public HashMap<String, ArrayList<String>> GetDefaultScreenTCData(String TestCaseName,String TestDataLocation)
    {

    
        POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData = new ArrayList<String>();
        whereClause_TestData.add("TestCase::" + TestCaseName);
        return poiObject.fetchWithCondition(TestDataLocation + "/" +"Master_Default.xlsx", "Default", whereClause_TestData);


    }
	
	/*public HashMap<String, ArrayList<String>> getUBTTData()
    {

    
        POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData = new ArrayList<String>();
        whereClause_TestData.add("Environment::" + TestRunSettings.Environment);
        //whereClause_TestData.add("Environment::" + "UAT3");
        return poiObject.fetchWithCondition(TestRunSettings.TestDataLocation_WP+ "\\" +"UBTT.xlsx", "UBTT", whereClause_TestData);
        //return poiObject.fetchWithCondition("C:\\Users\\abhishekkumar879\\Desktop\\TFS\\KY_POM\\POM_Test\\src\\main\\java\\Artifacts\\TestData\\WP"+ "\\" +"UBTT.xlsx", "UBTT", whereClause_TestData);


    }
	*/
/*	public HashMap<String, ArrayList<String>> getTC_UBTT_MappingData(String TestCaseName)
    {  
        POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData = new ArrayList<String>();
        whereClause_TestData.add("TestCase::" + TestCaseName);
        return poiObject.fetchWithCondition(TestRunSettings.TestDataLocation_WP+ "\\" +"UBTT.xlsx", "TestCaseMapping", whereClause_TestData);
    }*/
    
	
	
}


