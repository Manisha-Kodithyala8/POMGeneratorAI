package Reusable;

import java.io.File;
import java.time.LocalDateTime;

import ReportUtilities.Constants.ReportContants;
import TestSettings.TestRunSettings;

public class RenameDownloadedFile 
{
	
	public static void main(String[] args) throws Exception 
	{
		
		//renameAndPlaceFile("WPM-038_112986413_187313797_040822.PDF","Abhishek_renamed_test_COR_NEW");
	}
	

	public static String getCurrentDate() throws Exception
    {
        try
        {
        	LocalDateTime today = LocalDateTime.now();

            String date = today.toLocalDate().toString();
            date = date.replace(":", "_");
            date = date.replace(" ", "_");
            date = date.replace(".", "_");
            date = date.replace("-", "_");
            return date;
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	throw e;
        }
    }


    public static String getCurrentTime() throws Exception
    {
        try
        {
        	LocalDateTime today = LocalDateTime.now();

            String result = today.toLocalTime().toString();

            result = result.replace(":", "_");
            result = result.replace(" ", "_");
            result = result.replace(".", "_");
            return result;

        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	throw e;
        }

    }

    public static String CreateDirectory(String DirectoryPath, String DirectoryName) throws Exception
    {
        try
        {
        	String DirectoryFulPath = DirectoryPath + "/" + DirectoryName;
        	File dir = new File(DirectoryFulPath);
            if (!dir.exists()) dir.mkdirs();
            
            return DirectoryFulPath;

        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	throw e;

        }
    }

    
    public static boolean renameAndPlaceFile(String downloadedFile, String renameTo,String Folder) throws Exception
    {
    	try {
    		File directory;
    		String home = System.getProperty("user.home");
			//String FilePath = CreateDirectory("", "RenamedFiles");		
			//String RenamedFileName=renameTo + "_"+getCurrentDate()+"_"+ getCurrentTime() + ".PDF";
			String FilePath = TestRunSettings.ArtifactsPath+"//PDF//TargetPDFfile//"+Folder;
			
			directory = new File(FilePath);
			if(directory.exists()) 
			{
				for(File file :directory.listFiles()) 
				{
					file.delete();
				}
			}
		    if (! directory.exists()){
		        directory.mkdirs();
		    }
		   Thread.sleep(10);
			String RenamedFileName=renameTo+".PDF";
			
			FilePath = FilePath + "/" +RenamedFileName;
			
			File originalFile = new File(home + "/Downloads/" + downloadedFile);			
	    	File newFile = new File(FilePath);
	    	Thread.sleep(0);
	        boolean flag = originalFile.renameTo(newFile);	 
	        if (flag == true) {
	            System.out.println("File Successfully Renamed and saved to destination folder");
	        }

	        else {
	            System.out.println("Operation Failed");
	        }
	        
	    
		return originalFile.renameTo(newFile);
    	}
    	catch(Exception e) 
    	{
    		throw e;
    	}
    }
    
    public static boolean RenameAndPlaceFile(String downloadedFile, String renameTo) throws Exception
    {
    	try {
    		String home = System.getProperty("user.home");
			String FilePath = TestRunSettings.ArtifactsPath+"//PDF//TargetPDFfile";
			String RenamedFileName=renameTo+".PDF";
			FilePath = FilePath + "/" +RenamedFileName;
			File originalFile = new File(home + "/Downloads/" + downloadedFile);			
	    	File newFile = new File(FilePath);
	        boolean flag = originalFile.renameTo(newFile);	 
	        if (flag == true) {
	            System.out.println("File Successfully Renamed and saved to destination folder");
	        }

	        else {
	            System.out.println("Operation Failed");
	        }
	        
	    
		return originalFile.renameTo(newFile);
    	}
    	catch(Exception e) 
    	{
    		throw e;
    	}
    }
}
