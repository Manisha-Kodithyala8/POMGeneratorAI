package Reusable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReplicateExcelData 
{
	
	public ArrayList<String> SheetsName() throws IOException 
	{
		ArrayList<String> sheetnames=new ArrayList<String> ();
		 FileInputStream fileInputStream = null;
		fileInputStream = new FileInputStream("C:/Users/abhishekkumar879/Desktop/KY_POM_V7/KY_POM/POM_Test/src/main/java/Artifacts/TestData/WP/DataCollection.xls");

        HSSFWorkbook workbook = new HSSFWorkbook(fileInputStream);

        // for each sheet in the workbook
        for (int i = 0; i < workbook.getNumberOfSheets(); i++)
        {
        	sheetnames.add(workbook.getSheetName(i));
        }
        
        return sheetnames;
	}
	
	public static String[] readExcelRow(int iteration, int numOfIterations, String filePath, String excelFileName, String sheetName) throws IOException
	{  
		FileInputStream fileInputStream = new FileInputStream(new File(filePath + excelFileName + ".xlsx"));  
		 
		XSSFWorkbook workBook = new XSSFWorkbook(fileInputStream);   
		  
		int sheetIndex = workBook.getSheetIndex(sheetName);
		XSSFSheet sheet = workBook.getSheetAt(sheetIndex);  
		  
		FormulaEvaluator formulaEvaluator = workBook.getCreationHelper().createFormulaEvaluator();  
		String[] tempRow = new String[1000];
		
		Row row = sheet.getRow(iteration + numOfIterations);
		
		
		for (int cn=0; cn<row.getLastCellNum(); cn++) 
		{
			Cell cell = row.getCell(cn);
			try 
			{
				if (cell == null || cell.toString() == "") 
	        	{
				   tempRow[cn] = "";  	         
			    }
			
			    else 
			    {
				   switch(formulaEvaluator.evaluateInCell(cell).getCellType())  
		           {  			
		               case Cell.CELL_TYPE_NUMERIC:
		        	       tempRow[cn] = Integer.toString((int)Math.round((cell.getNumericCellValue())));
	  			     
	  			           break;  
			         
		               case Cell.CELL_TYPE_STRING: 	        	  
		  			       tempRow[cn] = cell.getStringCellValue();
		        	 		        	 
		                   break;	             
		           }
			     }
				
				System.out.print(tempRow[cn]+ "\t\t");
			}
			
			catch (Exception e) 
			{
				System.out.print("Failed to copy column "+ ('A' + cn) + "\t\t");
				tempRow[cn] = "";
			}
			
		}
		
		return tempRow;
	}

}
