package Reusable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.dockerjava.api.model.Container;

import ReportUtilities.Model.TestCaseParam;
import net.bytebuddy.implementation.bytecode.Throw;

public class ArrayListToProperties {
	
/*	public void ModeltoProperty(TestCaseParam testCaseParam,CaseModel model, String Path) throws Exception
	{
		HashMap<String, String> caseData=new LinkedHashMap<String,String>();
		try 
		{
			
			List<Object> keyValueList = new ArrayList<>();
			
	        Class<?> clazz = model.getClass();
	        Field[] fields = clazz.getDeclaredFields();
	        
	        for (Field field : fields) {
	            field.setAccessible(true); 
	            String key = field.getName();
	           
	            try {
	                Object value = field.get(model);
	                	                
	                
	                if(value.toString().contains("Model@")) 
	                {
	                	Class<?> valueType = value.getClass();
	                	
	                	if(valueType.toString().contains("ArrayList")) 
	                	{
	                		ArrayList<IndividualModel> indmodel=new ArrayList<IndividualModel>();
	                		 if (value instanceof ArrayList) 
	                		 {
	                	            ArrayList<?> arrayList = (ArrayList<?>) value;

	                	            for (Object item : arrayList) {
	                	                indmodel.add((IndividualModel) item);
	                	            }
	                	        }
	                		 try 
	                			{

	                				int size=indmodel.size();
	                				
	                				for(int i=0;i<size; i++) 
	                				{
	                					int index=i+1;
	                					Class<?> clazz1 = indmodel.get(i).getClass();
	                			        Field[] fields1 = clazz1.getDeclaredFields();
	                			        
	                			        for (Field field1 : fields1) {
	                			            field1.setAccessible(true); 
	                			            String key1 = field1.getName();
	                			           
	                			            try {
	                			                Object value1 = field1.get(indmodel.get(i));
	                			                
	                			                if(value1==null) 
	                			                {
	                			                	value1="";
	                			                }
	                			                
	                			                if(value1.toString().contains("Model@")) 
	                			                {
	                			                	Class<?> valueType1 = value1.getClass();	                	
	                			                	
	                			                	Field[] innerfields1 = valueType1.getDeclaredFields();
	                			                	int innersize=innerfields1.length;
	                			                	
	                			                	for(Field innerfiled1: innerfields1) 
	                			                	{
	                			                		String innerkey1 = innerfiled1.getName();
	                			                		
	                			                		try 
	                			                		{
	                			                			Thread.sleep(0);
	                			                			innerfiled1.setAccessible(true);
	                			                			try {
	                				        	                Object innervalue1 = innerfiled1.get(value);
	                				        	                //System.out.println(innerkey1+index+":"+innervalue1);
	                				        	                caseData.put(innerkey1+index, innervalue1.toString());
	                				                		}
	                				                		catch (IllegalAccessException e) {
	                				        	                e.printStackTrace();
	                				        	            }
	                			                		}
	                			                		catch(Exception e) 
	                			                		{
	                			                			
	                			                		}
	                			                		
	                			                	}
	                			                }
	                			                
	                			                else
	                			                {
	                			                	//System.out.println(key1+index+":"+value1);
	                			                	caseData.put(key1+index, value1.toString());
	                			                }
	                			                
	                			            } catch (IllegalAccessException e) {
	                			                e.printStackTrace();
	                			            }
	                				}
	                		        
	                		        }
	                			}
	                			
	                			catch(Exception e) 
	                			{
	                				throw e;
	                			}
	                			

	                	}
	                	
	                	
	                	
	                	Field[] innerfields = valueType.getDeclaredFields();
	                	int innersize=innerfields.length;
	                	
	                	for(Field innerfiled: innerfields) 
	                	{
	                		String innerkey = innerfiled.getName();
	                		
	                		try 
	                		{
	                			Thread.sleep(0);
	                			innerfiled.setAccessible(true);
	                			try {
		        	                Object innervalue = innerfiled.get(value);
		        	                //System.out.println(innerkey+":"+innervalue);
		                		}
		                		catch (IllegalAccessException e) {
		        	                e.printStackTrace();
		        	            }
	                		}
	                		catch(Exception e) 
	                		{
	                			
	                		}
	                		
	                	}
	                }
	                
	                else 
	                {
	                	//System.out.println(key+":"+value);
	                	caseData.put(key, value.toString());
	                }
	                
	            } catch (IllegalAccessException e) {
	                e.printStackTrace();
	            }
	        }
	    }
			

		catch(Exception e) 
		{
			throw e;
		}
		removeNullEmptyValues(caseData);
		System.out.println(caseData);
		try 
		{
		createPrpertyfile(Path, testCaseParam.TestCaseName+"_"+testCaseParam.ModuleName+"_"+testCaseParam.Browser,caseData);
		}
		catch(Exception e) 
		{
			throw e;
		}
	
	}*/
   
	
	public void createPrpertyfile(String Propertyfilepath, String PropertyFileName,HashMap<String,String> Casedata) throws IOException 
	{
		File directory = new File(Propertyfilepath);
		
		if (!directory.exists()) {
            if (directory.mkdirs()) {
            	
                System.out.println("Directory created successfully.");
            } else {
                System.err.println("Failed to create directory.");
            }
        }
		
		String path=Propertyfilepath+"//"+PropertyFileName+".properties";
		 if (fileExists(path)) 
		 	{
			 
			 clearAndWriteProperties(path,Casedata);
	        } else {
	            try {
	            	createandwritePropertyFile(path,Casedata);
	                System.out.println("Property file created successfully.");
	            } catch (IOException e) {
	                System.err.println("Error creating property file: " + e.getMessage());
	            }
	        }
	}
	
	public static boolean fileExists(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
        	file.setWritable(true);
        	}
        return file.exists();
    }
	
	public static void createandwritePropertyFile(String filePath,HashMap<String,String> Casedata) throws IOException 
	{
		
        Path path = Paths.get(filePath);
        Files.createFile(path);
        
        Properties properties=new Properties();
		int size=Casedata.size();
		
		for(String key:Casedata.keySet()) 
		{
			properties.setProperty(key, Casedata.get(key));
		}

        try (FileWriter writer = new FileWriter(filePath)) {
            properties.store(writer,"NewData");
        }
       
    }
	
	private static void clearAndWriteProperties(String filePath,HashMap<String,String> Casedata) throws IOException {
		Properties properties=new Properties();
		int size=Casedata.size();
		
		for(String key:Casedata.keySet()) 
		{
			properties.setProperty(key, Casedata.get(key));
		}

        try (FileWriter writer = new FileWriter(filePath, false)) {
            properties.store(writer,"UpdatedData");
        }
    }
	
	 private static void removeNullEmptyValues(Map<String, String> map) {
	        Iterator<Entry<String, String>> iterator = map.entrySet().iterator();

	        while (iterator.hasNext()) {
	            Entry<String, String> entry = iterator.next();
	            Object value = entry.getValue();

	            if (value == null || (value instanceof String && ((String) value).isEmpty()) || (value instanceof Integer && ((int) value)==0)|| (value instanceof String && ((String) value).equals("0"))) 
	            {
	                iterator.remove();
	            }
	        }
	    }
}
