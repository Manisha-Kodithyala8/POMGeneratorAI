package Reusable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class JavaClassPathFetcher {

    public static void main(String[] args) {
        String folderPath = Paths.get("").toAbsolutePath().toString()+"//src//main/java//UITests"; // Replace with the actual path to your folder
        List<String> classPaths = getClassPaths(folderPath);

        System.out.println("Class Paths:");
        for (String classPath : classPaths) {
            System.out.println(classPath);
        }

        writeClassPathsToProperties(classPaths, Paths.get("").toAbsolutePath().toString()+"//ClassPathLookup.properties");
    }

    private static List<String> getClassPaths(String folderPath) {
        List<String> classPaths = new ArrayList<>();
        File folder = new File(folderPath);

        if (folder.exists() && folder.isDirectory()) {
            fetchClassPathsRecursively(folder, "", classPaths);
        } else {
            System.err.println("Invalid folder path or the folder doesn't exist.");
        }

        return classPaths;
    }

    private static void fetchClassPathsRecursively(File folder, String parentPackage, List<String> classPaths) {
        File[] files = folder.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    String currentPackage = parentPackage + file.getName() + ".";
                    fetchClassPathsRecursively(file, currentPackage, classPaths);
                } else if (file.isFile() && file.getName().endsWith(".java")) {
                    String className = file.getName().replace(".java", "");
                    String classPath = parentPackage + className;
                    classPaths.add(classPath);
                }
            }
        }
    }

    private static void writeClassPathsToProperties(List<String> classPaths, String outputFilePath) {
        Properties properties = new Properties();

        for (String classPath : classPaths) {
        	String key = "TestCase"; // Set the key to a constant value

            // If the key is already present, append the classPath to the existing value
            if (properties.containsKey(key)) {
                String existingValue = properties.getProperty(key);
                properties.setProperty(key, existingValue + "," + "UITests." + classPath);
            } else {
                properties.setProperty(key, "UITests." + classPath);
            }
        }

        try (FileWriter fileWriter = new FileWriter(outputFilePath)) {
//        	properties.store(fileWriter, null);
            properties.store(fileWriter, "Java Class Paths");
            System.out.println("Class Paths written to " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Error writing to properties file: " + e.getMessage());
        }
    }
}
