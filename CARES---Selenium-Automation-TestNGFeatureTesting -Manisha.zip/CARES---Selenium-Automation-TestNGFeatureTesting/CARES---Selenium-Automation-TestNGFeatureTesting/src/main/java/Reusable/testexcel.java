package Reusable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import InitializeScripts.InitializeTestSettings;
import ReportUtilities.Model.TestCaseParam;

public class testexcel{

	public static void main(String[] args) throws Exception 
	{
		
		
        
		//TestCaseParam testCaseParam=new TestCaseParam();
		//demo d=new demo();
		//d.RowData_WP(testCaseParam,"ApplicationRegistration","TC_CR1471_07", "ApplicationRegistration",1000, "abc");				

	}

}
