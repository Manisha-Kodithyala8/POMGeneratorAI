package Reusable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import InitializeScripts.InitializeTestSettings;
import UITests.TestNG.Common.ExcelUtility;
import CommonUtilities.Utilities.Util;


public class demo extends InitializeTestSettings
{
	Util util = new Util();
	InitializeTestSettings ITS=new InitializeTestSettings();
	Path currentRelativePath = Paths.get(""); 
	  String PrjPath=currentRelativePath.toAbsolutePath().toString();
	  ExcelUtility excelutil=new ExcelUtility();
	public ArrayList<String> Sheets() throws InvalidFormatException, IOException
	{
		try {
		File myFile = new File("/path/to/excel.xls");
		Workbook wb = WorkbookFactory.create(myFile);

		ArrayList<String> sheetNames = new ArrayList<String>();
		for (int i=0; i<wb.getNumberOfSheets(); i++) 
		{
		    sheetNames.add( wb.getSheetName(i) );
		}
		return sheetNames;
		}
		catch(Exception e) 
		{
			throw e;
		}
	}
	
	/*public ArrayList<String> RowData_WP(TestCaseParam testCaseParam,String ScreenName, String TestCaseName, String excelFileName, int rownumber, String newTestCaseName) throws Exception
	{
		ITS.LoadConfigData(PrjPath);
		HashMap<String, ArrayList<String>> TestCaseData = new LinkedHashMap<String, ArrayList<String>>();
		ArrayList<String> excelrowdata = new ArrayList<String>();
		try 
		{
			TestCaseData=excelutil.GetScreenTCData(testCaseParam,ScreenName, TestCaseName, TestRunSettings.TestDataLocation_WP, TestRunSettings.TestDataMappingFileName, TestRunSettings.TestDataMappingSheetName_WP);
			
			 String testcase=TestCaseData.get("TestCase").get(0);
			
			 
			  
			Collection<ArrayList<String>> rowdatalist1=TestCaseData.values(); 
			String rowdata1=rowdatalist1.toString();
			String[] rowdata2=rowdata1.split(",");
			 for(int i=0; i<rowdatalist1.size(); i++) 
			 {				 
				 
				 excelrowdata.add(rowdata2[i]);
				
			 }
			 System.out.println("copied data:-"+excelrowdata);
		
			 
			 if(excelrowdata.get(0)!=null||excelrowdata.get(0)!="") 
			 {
				 FileInputStream fileInputStream = new FileInputStream(new File(TestRunSettings.TestDataLocation_WP+ "/" + excelFileName + ".xlsx"));
				 XSSFWorkbook workBook = new XSSFWorkbook(fileInputStream);   
				  
					int sheetIndex = workBook.getSheetIndex(ScreenName);
					XSSFSheet sheet = workBook.getSheetAt(sheetIndex);
					
					Row row = sheet.createRow(rownumber);
					
					int size=excelrowdata.size();
					
					for(int i=0; i<size; i++) 
					{						
						Cell cell = row.createCell(i);					
						String rowdata=excelrowdata.get(i).replace("[", "");
						String datatobepasted=rowdata.replace("]", "");
						cell.setCellValue(datatobepasted);
					}
					Cell cell = row.createCell(0);
					cell.setCellValue(newTestCaseName);
					
					
					FileOutputStream printOut = new FileOutputStream(new File(TestRunSettings.TestDataLocation_WP+ "/" + excelFileName + ".xlsx"));
					workBook.write(printOut);
			 
					printOut.close();
			 }
			
			 
			return excelrowdata;
		}
		catch(Exception e) 
		{
			throw e;
		}
	}
	*/
	public static XSSFRow test(XSSFSheet sheet, String colName, String textToFind){
	    int colIndex=0;
	    for (int colNum = 0; colNum<=sheet.getRow(0).getLastCellNum();colNum++)
	    {
	        if (sheet.getRow(0).getCell(colNum).toString().equalsIgnoreCase(colName)){
	            colIndex = colNum;
	            break;
	        }
	    }
	    for (int RowNum = 0; RowNum<sheet.getLastRowNum();RowNum++){
	        if(sheet.getRow(RowNum).getCell(colIndex).toString().equalsIgnoreCase(textToFind)){
	            return sheet.getRow(RowNum);
	        }
	    }
	    System.out.println("No any row found that contains "+textToFind);
	    return null;
	}
	
}
