package Reusable;

import CommonUtilities.Common.ActionKeywords.WebKeywords;
import CommonUtilities.Common.ActionKeywords.WebKeywords.SelectType;
import ReportUtilities.Common.ReportCommon;
import Constants.ElementConstants;
import ReportUtilities.Model.TestCaseParam;
import TestSettings.TestRunSettings;
import CommonUtilities.Utilities.Util;
import CommonUtilities.Common.POI_ReadExcel;



public class SessionDetails {


	public String getSessionData(TestCaseParam testCaseParam,String Data)
	{	  
	       
	    
return Data;		
	}
}
