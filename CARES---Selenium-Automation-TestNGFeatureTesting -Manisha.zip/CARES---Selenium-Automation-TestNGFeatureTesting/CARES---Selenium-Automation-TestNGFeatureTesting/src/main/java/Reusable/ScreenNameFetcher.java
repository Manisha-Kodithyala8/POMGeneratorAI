package Reusable;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.LinkedList;

public class ScreenNameFetcher {

    public static String getScreenName(String urlString) {
        try {
            URL url = new URL(urlString);

            // Get the path from the URL
            String path = url.getPath();
            
            
            String[] pathSegments = path.split("/");
            
        

            // Find the last non-empty segment as the screen name
            String screenName = null;
            for (int i = pathSegments.length - 1; i >= 0; i--) {
                if (!pathSegments[i].isEmpty()) {
                    screenName = pathSegments[i];
                    break;
                }
            }

            return screenName;
        } catch (Exception e) {
           // e.printStackTrace();
            return null;
        }
    }


    public static void main(String[] args) {
        String url = "https://uat3.kyserve.chfsinet.ky.gov/EligibilityDetermination/EligibilityDetermination/RFISummary?tabId=Ll9ujzbzBO";
        String screenName = getScreenName(url);

        if (screenName != null) {
            System.out.println("Screen Name: " + screenName);
        } else {
            System.out.println("Failed to retrieve screen name.");
        }
    }
}
