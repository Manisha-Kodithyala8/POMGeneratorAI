package Reusable;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

public class ReadPDFfile {

	public static void main(String[] args) throws IOException 
	{
		validatepdftext("Medicaid");

	}
	
	
	public static boolean validatepdftext(String text) throws IOException 
	{
		boolean textpresent=false;
		File file=new File("C://Users//abhishekkumar879//Downloads//KHBE_Merged_Output (5).PDF");
		FileInputStream fis=new FileInputStream(file);
		
		PDFParser parser=new PDFParser(fis);
		
		parser.parse();
		
		COSDocument cosDoc=parser.getDocument();
		
		PDDocument pdDoc=new PDDocument(cosDoc);
		
		PDFTextStripper strip=new PDFTextStripper();
		
		String data=strip.getText(pdDoc);
		
		//System.out.println(data);
		
		if(data.contains(text)) 
		{
			textpresent=true;
		}
		else 
		{
			textpresent=false;
		}
		
		System.out.println("pdf contains text:----"+text+"----"+textpresent);
		return textpresent;
		
	}

}
