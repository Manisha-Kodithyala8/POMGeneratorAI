package APIUtilities.Reports;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APITestSettings;

public class ExtentReport {


	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static HashMap<Integer, ExtentTest> DictExtentTestScenario = new HashMap<Integer, ExtentTest>();
	public static HashMap<Integer, String> DictExtentTestCase = new HashMap<Integer, String>();
	public static HashMap<String, ExtentTest> TCExtentMapping = new HashMap<String, ExtentTest>();	


	public void StartReport(String ReportPath, String HostName, String Environment, String Username)
	{
		try
		{
			ReportPath = ReportPath + "\\ExtentReport.html"; 
			htmlReporter = new ExtentHtmlReporter(ReportPath);
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Host Name", HostName);
			extent.setSystemInfo("Environment", Environment);
			extent.setSystemInfo("Username", Username);
		}
		catch(Exception e)
		{
			System.out.println("Unable to initialize the Extent Report");
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
		}
	}

	public void JenkinsReport(String ReportPath) {
		ReportPath = ReportPath + "\\ExtentReport.html"; 
		String destinationPath=APITestSettings.HomePath+"\\JenkinsResult";
		String Report = "\\ExtentReportAPI.html";

		try {
			Path source = Path.of(ReportPath);
			Path destination = Path.of(destinationPath+Report);

			Files.createDirectories(destination);

			File file = new File(destinationPath, Report);
			if (file.exists()) {
				if (file.delete()) {
					System.out.println("File deleted successfully.");
				} else {
					System.out.println("Failed to delete the file.");
				}
			} 

			Files.copy(source, destination);

			System.out.println("File copied successfully.");
		} catch (IOException e) {
			System.out.println("An error occurred while copying the file: " + e.getMessage());
		}
	}


	public ExtentTest StartTest(String TestCase,String UserStory, String Module, String TestCaseDescription)
	{
		try
		{
			ExtentTest TC = extent.createTest(TestCase, TestCaseDescription);
			ExtentTest test =TC.createNode("Iteration==>1");
			test.assignCategory(UserStory);
			test.assignCategory(Module);

			return test;

		}
		catch(Exception e)
		{
			System.out.println("Unable to initialize the Extent Test Case ==>"+TestCase );
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());

			throw e;

		}





	}




	public void EndReport()

	{

		extent.flush();

	}


	public void AddTestStep(ExtentTest extentTest, String Module, String APIName, String Iteration,ArrayList<APIReportModel> apiReportModels) throws InterruptedException
	{

		ExtentTest node=extentTest.createNode(Module + "===>" + APIName +"==>" + Iteration);
		ExtentTest RequestNode=node.createNode("Request");
		if(apiReportModels.get(0).Request.contains("<")) {
			apiReportModels.get(0).Request = "<textarea style='color:black'>"+apiReportModels.get(0).Request+"</textarea>";
		}
		RequestNode.log(Status.INFO , MarkupHelper.createLabel(apiReportModels.get(0).Request,ExtentColor.GREY));
		if(apiReportModels.get(0).Response.contains("<")) {
			apiReportModels.get(0).Response = "<textarea style='color:black'>"+apiReportModels.get(0).Response+"</textarea>";
		}
		ExtentTest ResponseNode=node.createNode("Response");
		ResponseNode.log(Status.INFO , MarkupHelper.createLabel( apiReportModels.get(0).Response,ExtentColor.GREY));

		ExtentTest ResultNode=node.createNode("Results");

		int ResultCounter=0;
		for(APIReportModel apiReportModel:apiReportModels)
		{
			ResultCounter++;
			Status ExtentStatus = Status.INFO;
			if(apiReportModels.get(0).TestStepResult.equalsIgnoreCase("PASS"))
			{
				ExtentStatus=Status.PASS;
			}
			else if(apiReportModels.get(0).TestStepResult.equalsIgnoreCase("FAIL"))
			{
				ExtentStatus=Status.FAIL;				
			}

			Thread.sleep(0);
			if(!(apiReportModels.get(0).ActualResponse.equals(""))) {
				ExtentTest StepResult=ResultNode.createNode("Result");
				StepResult.log(Status.INFO,"Status Info :  "+ apiReportModels.get(0).StatusCode);
				StepResult.log(Status.INFO,"Validation :  "+ apiReportModel.XPathJSONKey);
				StepResult.log(Status.INFO,"<br> Expected Results <br>"+ apiReportModel.ExpectedResponse);
				StepResult.log(ExtentStatus,"Actual Results <br>"+ apiReportModel.ActualResponse);
			}
		}

		if(APITestSettings.DBValidation.equalsIgnoreCase("Yes")) {
			Status ExtentStatus = Status.INFO;
			if(apiReportModels.get(apiReportModels.size()-1).TestStepResult.equalsIgnoreCase("PASS"))
			{
				ExtentStatus=Status.PASS;
			}
			else if(apiReportModels.get(apiReportModels.size()-1).TestStepResult.equalsIgnoreCase("FAIL"))
			{
				ExtentStatus=Status.FAIL;				
			}
			ExtentTest DBValidation=node.createNode("DB Validation Result");
			DBValidation.log(Status.INFO,"Query Validation :  "+ apiReportModels.get(apiReportModels.size()-1).DBValidation);
			DBValidation.log(Status.INFO,"<br> Expected DB Results <br>"+ apiReportModels.get(apiReportModels.size()-1).DBExpectedValue);
			DBValidation.log(ExtentStatus,"Actual DB Results <br>"+ apiReportModels.get(apiReportModels.size()-1).DBActualValue);
		}
	}


	public String WriteDataToTextFile(String FilePath, String FileName,String FileContent,String FileFormat)
	{
		FilePath = FilePath + "\\" + FileName + FileFormat;
		try
		{

			BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath));
			writer.write(FileContent);

			writer.close();

			FilePath= FilePath.replace("\\","/");

			FilePath = "<a href = 'file:///"+ FilePath + "'>"+ FileName + "</a>";
			return FilePath;
		}

		catch (Exception e)
		{
			return FilePath;
		}
	}

	public String WriteImageToReport(String FilePath, String FileName)
	{

		try
		{
			FilePath = FilePath.replace("\\", "/");
			FilePath = "<a href = 'file:///" + FilePath + "'>" + FileName + "</a>";
			return FilePath;
		}

		catch (Exception e)
		{
			return FilePath;
		}
	}


}
