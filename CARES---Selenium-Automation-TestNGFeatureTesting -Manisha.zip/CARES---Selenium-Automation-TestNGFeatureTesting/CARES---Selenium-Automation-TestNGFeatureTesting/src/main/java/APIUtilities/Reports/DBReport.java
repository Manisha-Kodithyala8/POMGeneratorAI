package APIUtilities.Reports;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

import APIUtilities.APIHelpers.MSSQLUtilities;
import APIUtilities.Models.APIReportModel;
import APIUtilities.Models.DBModel;
import APIUtilities.Models.EnvModel;
import APIUtilities.TestSettings.APISessionData;
import APIUtilities.TestSettings.APITestSettings;


public class DBReport {

public void generateDBReport(String TestCase,String Module, String APIName,ArrayList<APIReportModel> apiReportModels) throws Exception
{

	 ArrayList<String> headers = new ArrayList<>();
     // Add the column names to the headers list
     headers.add("Env");
     headers.add("TestCaseName");
     headers.add("Module");
     headers.add("InterfaceName");
     headers.add("Result");
     headers.add("RequestData");
     headers.add("ResponseData");

     ArrayList<ArrayList<String>> queries = new ArrayList<>();
     // Add the data for each row as an ArrayList of strings
     
     for(APIReportModel apiReportModel: apiReportModels)
     {
     ArrayList<String> rowData = new ArrayList<>();
     // Add the values for the columns in the first row
     rowData.add(APITestSettings.Environment);
     rowData.add(TestCase);
     rowData.add(Module);
     rowData.add(APIName);
     rowData.add(apiReportModel.TestStepResult);
     rowData.add(apiReportModel.Request);
     apiReportModel.Response = SanitizeResponse(apiReportModel.Response);
     rowData.add(apiReportModel.Response);
     queries.add(rowData);
     }
	
     
     ObjectMapper mapper = new ObjectMapper();

     DBModel DBDetails = mapper.readValue(new File(APISessionData.envModel.ConnectionString), DBModel.class);
     EnvModel env= DBDetails.Env.get(APITestSettings.Environment);
     MSSQLUtilities mssqlUtilities=new MSSQLUtilities();
     mssqlUtilities.InsertQueries(env.ConnectionString, APISessionData.DBLoggingTable, headers, queries);
	}

public String SanitizeResponse(String InputString)
{
    if (InputString.contains("'"))
    {
        InputString = InputString.replaceAll("'", "");
        return InputString;
    }
    else
    {
        return InputString;
    }
}
}
