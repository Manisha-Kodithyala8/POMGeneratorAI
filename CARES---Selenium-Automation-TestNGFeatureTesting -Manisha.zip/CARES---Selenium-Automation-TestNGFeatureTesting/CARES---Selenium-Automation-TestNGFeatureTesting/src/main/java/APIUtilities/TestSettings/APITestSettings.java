package APIUtilities.TestSettings;

import java.util.ArrayList;
import java.util.HashMap;

import APIUtilities.Models.APIConfig;
import APIUtilities.Models.APIReportModel;
import APIUtilities.Models.APITestStepModel;
import APIUtilities.Models.APITestCaseModel;

public class APITestSettings {


	public static final String DBValidation = "No";
	public static String ArtifactsPath = null;
	public static String Environment="";
	public static APIConfig apiTestSettings= null;
	public static String HomePath;
	public static String TrustStoreLocation;
	public static String TrustStorePassword;
	
	public static HashMap<String,ArrayList<APIReportModel>> reportModel= new HashMap<String,ArrayList<APIReportModel>>();
	public static  HashMap<String, ArrayList<APITestStepModel>> APITCExecData= new HashMap<String, ArrayList<APITestStepModel>>();
	public static  HashMap<String, APITestCaseModel> APITCInfo= new HashMap<String, APITestCaseModel>();

	public static HashMap<String,HashMap<String, String>> DictTestData= new HashMap<String, HashMap<String,String>>();
	public static String ResultsPath;
	public static String Results_RequestLocation;
	public static String Results_ResponseLocation;
	public static String AppUrl;
	public static String UserName;
	public static String Password;
	public static String Browser;
	public static String ExcelFilepath;
	public static boolean isKeyStoreConfigurationRequired=false;


	
}
