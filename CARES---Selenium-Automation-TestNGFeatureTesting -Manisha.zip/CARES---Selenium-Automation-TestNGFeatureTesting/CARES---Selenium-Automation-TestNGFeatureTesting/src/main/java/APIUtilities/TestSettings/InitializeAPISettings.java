package APIUtilities.TestSettings;

import java.io.IOException;
import java.util.Properties;

import APIUtilities.APICommon.APIUtil;
import APIUtilities.Models.APIConfig;


public class InitializeAPISettings {

	public APIConfig InitializeInterfaceSettings(String PrjPath,String ArtifactsPath,String ConfigLocation,String Env)
	{
	    Properties prop=new Properties();
	    APIUtil util = new APIUtil();

	    APIConfig APIConfigSettings = new APIConfig();
		
		 try {
			prop=util.loadProperties(ConfigLocation);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			APITestSettings.HomePath = PrjPath;
		

			
	    APIConfigSettings.Environment=Env;

	    APITestSettings.ArtifactsPath = ArtifactsPath;
		APIConfigSettings.TestDataPath = APITestSettings.ArtifactsPath + prop.getProperty("TestDataMappingLocation");
		APIConfigSettings.ExcelFileName = APITestSettings.ArtifactsPath + prop.getProperty("ExcelFileName");
		APIConfigSettings.InterfaceTestCaseSheet = prop.getProperty("InterfaceTestCaseSheet");
		APIConfigSettings.UrlRepositorySheet = APITestSettings.ArtifactsPath + prop.getProperty("URLRepositorySheet");
		APIConfigSettings.MockRepositorySheet = APITestSettings.ArtifactsPath + prop.getProperty("MockRepositorySheet");
		APIConfigSettings.HeaderRepository = APITestSettings.ArtifactsPath + prop.getProperty("HeaderRepository");
		APIConfigSettings.ResponseSheetPath = APITestSettings.ArtifactsPath + prop.getProperty("ResponseSheetPath");

		APIConfigSettings.CertificateLocation = APITestSettings.ArtifactsPath + prop.getProperty("CertificateLocation");
		APIConfigSettings.RequestLocation = APITestSettings.ArtifactsPath + prop.getProperty("RequestLocation");
		APIConfigSettings.ResponseLocation = APITestSettings.ArtifactsPath + prop.getProperty("ResponseLocation");
		APIConfigSettings.InterfaceSheetDetails = prop.getProperty("InterfaceSheetDetails");

		APIConfigSettings.ExcelSheetExtension = prop.getProperty("ExcelSheetExtension");
		APIConfigSettings.XMLExtension = prop.getProperty("XMLExtension");
		APIConfigSettings.JSONExtension = prop.getProperty("JSONExtension");
		APIConfigSettings.CommonMockSheetName = prop.getProperty("CommonMockSheetName");
		APIConfigSettings.UseCommonMockSheet = prop.getProperty("UseCommonMockSheet");
		APIConfigSettings.DomainName = prop.getProperty("DomainName");
		APIConfigSettings.MockTemplateLocation = APITestSettings.ArtifactsPath + prop.getProperty("MockTemplateLocation");

		
		APIConfigSettings.HeaderRepositorySheetName = prop.getProperty("HeaderRepositorySheetName");
		APIConfigSettings.MockSheetName = GetMockSheetName(APIConfigSettings.UseCommonMockSheet, APIConfigSettings.CommonMockSheetName, APIConfigSettings.Environment);
		APIConfigSettings.AddReportToDB = AddReportToDB(prop.getProperty("AddReportToDataBase"));
		APIConfigSettings.DefaultServiceTimeout = Integer.parseInt(prop.getProperty("DefaultServiceTimeout"));

		//Response Validation
		APIConfigSettings.ResponseValidationFilePath = APITestSettings.ArtifactsPath + prop.getProperty("ResponseValidationFileName");
		APIConfigSettings.ResponseValidationSheetName = prop.getProperty("ResponseValidationSheetName");
		
		//TrustStore Location and Password
		APITestSettings.TrustStoreLocation= prop.getProperty("TrustStoreLocation");
		APITestSettings.TrustStorePassword= prop.getProperty("TrustStorePassword");

		
		APITestSettings.apiTestSettings=APIConfigSettings;
		return APIConfigSettings;


	}

	boolean AddReportToDB(String AddReportToDB)
	{

		if (AddReportToDB.toUpperCase().trim().equals("YES"))
		{
			return true;
		}
		else
			return false;
	}

	String GetMockSheetName(String UseCommonMockSheet, String CommonMockSheetName, String Environment)
	{

		if (UseCommonMockSheet.toUpperCase().trim() == "YES")
		{
			return CommonMockSheetName;
		}
		else
		{
			return Environment;
		}
	}

}
