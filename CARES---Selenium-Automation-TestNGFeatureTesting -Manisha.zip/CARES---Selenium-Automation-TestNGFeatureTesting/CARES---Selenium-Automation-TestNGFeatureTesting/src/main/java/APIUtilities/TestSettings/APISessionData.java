package APIUtilities.TestSettings;

import java.util.HashMap;

import APIUtilities.Models.EnvModel;

public class APISessionData {

	public static HashMap<String,String> SessionKeys= new HashMap<String,String>();
	public static HashMap<String,String> APISessionKeys= new HashMap<String,String>();
	public static EnvModel envModel= new EnvModel();
	public static String DBLoggingTable;
	
	public static void setSessionData(String TestCase, String Module, String Browser,String Iteration,String Key, String Value)
	{
		SessionKeys.put(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_"+ Key,Value);
	}
	

	public static void syncSessionData(HashMap<String,String> SessionData)
	{

		if(SessionData.isEmpty()==false)
		{
			for(String key:SessionData.keySet())
			{

				SessionKeys.put( key,SessionData.get(key));
			}
		}
	}
	
	public static void setSessionDataCollection(String TestCase, String Module, String Browser,String Iteration,HashMap<String,String> SessionData)
	{
		if(SessionData.isEmpty()==false)
		{
			for(String key:SessionData.keySet())
			{

				SessionKeys.put(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_"+ key,SessionData.get(key));
				APISessionKeys.put(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_"+ key,SessionData.get(key));
			}
		}

	}
	
	
	public static String getSessionData(String TestCase, String Module, String Browser,String Iteration,String Key)
	{
		return SessionKeys.get(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_"+ Key);		
	}

	
	
	public static String getAPISessionData(String TestCase, String Module, String Browser,String Iteration,String Key)
	{
		return APISessionKeys.get(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_"+ Key);		
	}


	public static HashMap<String, String> getAPISessionDataCollection()
	{
		return APISessionKeys;		
	}

	public static String replaceSessionData(String TestCase, String Module, String Browser,String Iteration,String Value)
	{
		
		for(String s : SessionKeys.keySet())
		{
			s= s.replace(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_", "");
			if(Value.contains(s))
			{
				Value=Value.replace("##"+s + "##", SessionKeys.get(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_"+s));
			}
		}
		return Value;		
	}
	
	public static HashMap<String,String> replaceSessionDataCollection(String TestCase, String Module, String Browser,String Iteration,HashMap<String,String> CollectionData)
	{
		
		for(String colKey : CollectionData.keySet())
		{
			String colvalue=CollectionData.get(colKey);
			
			for(String sessionKey : SessionKeys.keySet())
			{
				String s=sessionKey.replace(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_", "");
				s="##"+s +"##";
				if(colvalue.contains(s))
				{
					colvalue=colvalue.replaceAll(s, SessionKeys.get(sessionKey));
					CollectionData.put(colKey, colvalue);
				}
				
			}
			
		}
		return CollectionData;		
	}
	
	
	public static boolean SessionDataContainsKey(String TestCase, String Module, String Browser,String Iteration,String Key)
	{
		if( SessionKeys.containsKey(TestCase+ "_"+ Module + "_" +Browser+ "_"+Iteration+ "_"+ Key))
		{
			return true;
		}
		else
		{
			return false;			
		}
	}


	public static char[] getSessionStartTime() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
