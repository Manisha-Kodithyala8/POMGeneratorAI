package APIUtilities.APIHelpers;

import java.util.ArrayList;
import java.util.HashMap;

import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APISessionData;
import io.restassured.path.json.JsonPath;

public class DBValidation {

	public String validateDBStatus(APIModel IModel) throws Exception 
	{
		String Actualcount="";
		try 
		{
			
			MSSQLUtilities sql = new MSSQLUtilities();
			Actualcount = sql.ReadData_DBValidation(APISessionData.envModel.ConnectionString, IModel.getDBQuery());
			
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			System.out.println("Exception is " + e);
			e.printStackTrace();
		}
		return Actualcount;				  
	}
}
