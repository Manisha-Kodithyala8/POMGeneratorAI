package APIUtilities.APIHelpers;

import java.util.ArrayList;
import java.util.HashMap;

import com.aventstack.extentreports.ExtentTest;

import APIUtilities.APICommon.APIMaster;
import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APISessionData;
import APIUtilities.TestSettings.APITestSettings;
import APIUtilities.APICommon.ExcelUtil;

import APIUtilities.Reports.ExcelReportGenerator;
import APIUtilities.Reports.ExtentReport;
import APIUtilities.Models.APITestCaseModel;
import APIUtilities.Models.APITestStepModel;

public class TestCaseHelper {

	public void getTestCaseDetails(String FileName,String SheetName) throws Exception
	{
		ExcelUtil poiObj = new ExcelUtil();
		ArrayList<String> whereClause = new ArrayList<String>();
		whereClause.add("Execute::Yes");
		HashMap<String, ArrayList<String>> TCDetails = poiObj.fetchWithCondition(FileName,SheetName, whereClause);
		ArrayList<APITestCaseModel> apiTestCaseModels = new ArrayList<APITestCaseModel>();

		if(TCDetails.isEmpty()==false)
		{

			if(TCDetails.get("TestCase").size()>0)
			{
				int TCsize=TCDetails.get("TestCase").size();
				for(int i=0;i<TCsize;i++)
				{
					APITestCaseModel apiTestCaseModel = new APITestCaseModel();
					apiTestCaseModel.TestCase=TCDetails.get("TestCase").get(i);
					apiTestCaseModel.TestCaseDescription=TCDetails.get("TestCaseDescription").get(i);
					apiTestCaseModel.UserStory=TCDetails.get("UserStory").get(i);
					apiTestCaseModel.Directory=TCDetails.get("Directory").get(i);
					apiTestCaseModel.TestCaseFilePath=APITestSettings.apiTestSettings.APITestCaseDirectory + "\\" + apiTestCaseModel.Directory + "\\" + apiTestCaseModel.TestCase + APITestSettings.apiTestSettings.ExcelSheetExtension;
					apiTestCaseModels.add(apiTestCaseModel);
					APITestSettings.APITCInfo.put( apiTestCaseModel.TestCase, apiTestCaseModel);
				}
			}
			else
			{
				throw new Exception("Record Count is 0 for  ==>" + FileName);
			}

		}
		else
		{
			throw new Exception("Incorrect Data Sheet ==> " + FileName);
		}
		HashMap<String, ArrayList<APITestStepModel>> APITCData= new HashMap<String, ArrayList<APITestStepModel>>();

		for(APITestCaseModel  apiTestCaseModel :apiTestCaseModels)
		{
			ArrayList<String> whereClauseTC = new ArrayList<String>();
			whereClauseTC.add("Execute::Yes");

			HashMap<String, ArrayList<String>> TSDetails = poiObj.fetchWithCondition(apiTestCaseModel.TestCaseFilePath,APITestSettings.apiTestSettings.APITestCaseSheetName, whereClauseTC);

			ArrayList<APITestStepModel> testStepModels= new ArrayList<APITestStepModel>();

			if(TSDetails.isEmpty()==false)
			{

				if(TSDetails.get("APIName").size()>0)
				{
					for(int i=0;i<TSDetails.get("APIName").size();i++)
					{
						APITestStepModel apiTestStepModel = new APITestStepModel();
						apiTestStepModel.Module=TSDetails.get("Module").get(i);
						apiTestStepModel.APIName=TSDetails.get("APIName").get(i);
						apiTestStepModel.FilePath=APITestSettings.apiTestSettings.APIDirectory + "\\" + TSDetails.get("FileName").get(i);
						apiTestStepModel.StartIndexforIteration=Integer.parseInt(TSDetails.get("StartIndexForIteration").get(i));
						int IterationCount= Integer.parseInt(TSDetails.get("IterationCount").get(i));
						apiTestStepModel.EndIndexforIteration=apiTestStepModel.StartIndexforIteration + IterationCount -1;
						testStepModels.add(apiTestStepModel);
					}
				}
				else
				{
					throw new Exception("Record Count is 0 for  ==>" + apiTestCaseModel.TestCaseFilePath);
				}
			}
			else
			{
				throw new Exception("Incorrect Data Sheet ==> " + apiTestCaseModel.TestCaseFilePath);
			}
			APITCData.put(apiTestCaseModel.TestCase, testStepModels);
		}
		APITestSettings.APITCExecData=APITCData;
	}
	public void ExecuteTestCases() throws Exception
	{
		ExtentReport extentReport = new ExtentReport();
		ExcelReportGenerator report = new ExcelReportGenerator();
		for(String  TestCase :APITestSettings.APITCExecData.keySet())
		{

			APITestCaseModel apiTestCaseModel = APITestSettings.APITCInfo.get(TestCase);
			ExtentTest extentTest=extentReport.StartTest(TestCase, apiTestCaseModel.Directory, apiTestCaseModel.UserStory, TestCase);
			ArrayList<APITestStepModel> aPITestStepModels=APITestSettings.APITCExecData.get(TestCase);			
			for(APITestStepModel apiTestStepModel :aPITestStepModels)
			{
				if(apiTestStepModel.StartIndexforIteration==apiTestStepModel.EndIndexforIteration)
				{
					APIController apiController = new APIController();
					report.StartExcelReport();
					ArrayList<APIReportModel> reportData=apiController.ExecuteAPI(TestCase,apiTestStepModel.Module,apiTestStepModel.APIName,APITestSettings.Browser, String.valueOf(apiTestStepModel.StartIndexforIteration),apiTestStepModel.FilePath);
					extentReport.AddTestStep(extentTest, apiTestStepModel.Module, apiTestStepModel.APIName,String.valueOf(apiTestStepModel.StartIndexforIteration), reportData);
					report.AddTestStep(reportData,apiTestStepModel.APIName);
				}
				else
				{
					for(int i=apiTestStepModel.StartIndexforIteration;i<=apiTestStepModel.EndIndexforIteration;i++)
					{
						APIController apiController = new APIController();
						ArrayList<APIReportModel> reportData=apiController.ExecuteAPI(TestCase,apiTestStepModel.Module,apiTestStepModel.APIName,APITestSettings.Browser, String.valueOf(i),apiTestStepModel.FilePath);
						extentReport.AddTestStep(extentTest, apiTestStepModel.Module, apiTestStepModel.APIName,String.valueOf(i), reportData);		
						report.AddTestStep(reportData,apiTestStepModel.APIName);
					}
				}
			}		
		}
	}
}
