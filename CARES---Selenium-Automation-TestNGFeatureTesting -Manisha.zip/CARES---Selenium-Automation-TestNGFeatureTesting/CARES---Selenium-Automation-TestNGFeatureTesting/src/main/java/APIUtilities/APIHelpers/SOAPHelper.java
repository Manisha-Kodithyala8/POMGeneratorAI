package APIUtilities.APIHelpers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.testng.Assert;
import org.testng.annotations.Test;

import APIUtilities.APICommon.APIMaster;
import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APISessionData;
import APIUtilities.TestSettings.APITestSettings;
//import DriverScript.Driver;
//import SupportLibraries.Util;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class SOAPHelper 
{
	
	final Logger logger = LoggerFactory.getLogger(SOAPHelper.class.getName());

	public Response ExecuteSOAPAPI(APIModel IModel , String Iteration)throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException
	{
		Response responsePost ;

		Map<String, String>  defaultHeaders = IModel.GetHeaderData();
		String jsonDataInFile="";
		 jsonDataInFile=IModel.gettRequestData();
		String CertificatePath=IModel.getCertificatePath();
		String CertificatePassword=IModel.getCertificatePassword();		
		KeyStore keyStore = null;
		SSLConfig config = null;

		try {
		        keyStore = KeyStore.getInstance("PKCS12");
		        keyStore.load(
		                new FileInputStream(CertificatePath),
		                CertificatePassword.toCharArray());

		    } catch (Exception ex) {
		        System.out.println("Error while loading keystore >>>>>>>>>");
		        ex.printStackTrace();
		    }																					  
		if (IModel.isMockRequired())
		{
			try
			{

				  FileWriter file;
				    
					    file = new FileWriter(IModel.GetMockData().MockLocation);
					 
					    file.write(IModel.GetMockData().MockFileContent);
					    file.flush();
					    file.close();
			}
			catch (Exception e)
			{
				logger.error("Unable to create the mock File===>" + IModel.GetMockData().MockFileName);
				logger.error(e.getMessage());
				logger.error(e.getStackTrace().toString());
				
				System.out.println("Unable to create the mock File===>" + IModel.GetMockData().MockFileName);
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());
			}
		}

		if(defaultHeaders.isEmpty())
		{
			if(IModel.isCertificateRequired())
			{
				if (keyStore != null) {

			        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, CertificatePassword);

			        // set the config in rest assured
			        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
			        RestAssured.config = RestAssured.config().sslConfig(config);
				}	
			responsePost =		
			RestAssured.given()
            .urlEncodingEnabled(false)
            .relaxedHTTPSValidation()
            .body(jsonDataInFile)
            .config(RestAssured.config())
            .contentType(ContentType.XML)
            .expect()
            .when()
			.post(IModel.getServiceUrl());
			}
			else
			{
				responsePost =		
						RestAssured.given()
			            .urlEncodingEnabled(false)
			            .relaxedHTTPSValidation()
			            .body(jsonDataInFile)
			            .contentType(ContentType.XML)
			            .expect()
			            .when()
						.post(IModel.getServiceUrl());	
			}
		}
			
		else
		{
			if(IModel.isCertificateRequired())
			{
				RestAssured.config = RestAssured.config().sslConfig(
			            new SSLConfig().trustStore(APITestSettings.TrustStoreLocation,APITestSettings.TrustStorePassword)
			                    .keyStore(CertificatePath, CertificatePassword));

				if (keyStore != null) {

			        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, CertificatePassword);

			        // set the config in rest assured
			        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
			        RestAssured.config = RestAssured.config().sslConfig(config);
				}	

			responsePost =
					RestAssured.given()
		            .urlEncodingEnabled(false)
		            .relaxedHTTPSValidation()
		            .body(jsonDataInFile)
		            .config(RestAssured.config())
		            .contentType(ContentType.XML)
							.headers(defaultHeaders)
				            .expect()
				            .when()
							.post(IModel.getServiceUrl());
			}
			else
			{
				responsePost =
						RestAssured.given()
			            .urlEncodingEnabled(false)
			            .relaxedHTTPSValidation()
			            .body(jsonDataInFile)
			            .config(RestAssured.config())
			            .contentType(ContentType.XML)
								.headers(defaultHeaders)
					            .expect()
					            .when()
								.post(IModel.getServiceUrl());
				
			}
		}
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("-------" + IModel.getModule() + "==>" + IModel.getInterfaceName() + "--------------");
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------");
		System.out.println("--------------------------Request--------------------------");
		System.out.println("-----------------------------------------------------------");
		System.out.println(jsonDataInFile);
		System.out.println("-----------------------------------------------------------");
		System.out.println("--------------------------Response--------------------------");
		System.out.println("-----------------------------------------------------------");
		System.out.println(responsePost.asString());

		
		logger.info("-----------------------------------------------------------------------------------");
		logger.info("-------" + IModel.getModule() + "==>" + IModel.getInterfaceName() + "--------------");
		logger.info("-----------------------------------------------------------------------------------");
		logger.info("-----------------------------------------------------------");
		logger.info("--------------------------Request--------------------------");
		logger.info("-----------------------------------------------------------");
		logger.info(jsonDataInFile);
		logger.info("-----------------------------------------------------------");
		logger.info("--------------------------Response--------------------------");
		logger.info("-----------------------------------------------------------");
		logger.info(responsePost.asString());

		return responsePost;
		
	}	 
}