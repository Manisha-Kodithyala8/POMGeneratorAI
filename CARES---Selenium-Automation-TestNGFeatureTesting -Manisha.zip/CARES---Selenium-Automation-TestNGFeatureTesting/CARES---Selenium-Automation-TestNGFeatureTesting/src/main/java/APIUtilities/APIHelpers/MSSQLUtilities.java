package APIUtilities.APIHelpers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.*;

import APIUtilities.TestSettings.APISessionData;



public class MSSQLUtilities {
	private static final Logger logger =LoggerFactory.getLogger(MSSQLUtilities.class.getName()); 	
	public static String  ReadDB_FrameworkDate() throws Exception
	{

		String Data="";
		String Query = "SELECT GetDate();";
		try
		{

			Connection con = null;
			boolean connectivityEstablished = false;
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				con = java.sql.DriverManager.getConnection(APISessionData.envModel.ConnectionString);
				if(con!=null) 
					logger.info("Connection Successful!");

				Statement stmt = con.createStatement();

				ResultSet rs = stmt.executeQuery(Query);

				ResultSetMetaData metaData = rs.getMetaData();
				int count = metaData.getColumnCount();

				ArrayList<String> QueryData=new ArrayList<String> ();
				while (rs.next())
				{ 
					QueryData.add(rs.getString(1));   	            		
				}
				if(QueryData.get(0).equalsIgnoreCase(null)) 
				{
					QueryData.get(0).replace(null, "");
				}
				Data=QueryData.get(0);
			}
			catch (Exception e)
			{
				System.out.println("Connection  Failed");
				e.printStackTrace();
				throw e;

			} 
			// Iterate through the data in the result set and display it.
		}
		catch(Exception e)
		{
			System.out.print(e.getMessage());
			System.out.print(e.getStackTrace());
			throw e;
		}
		return Data;	   
	}
	
	public  String  ReadData_DBValidation(String connectionString,String Query) throws Exception
	{
		String Data="";

		try
		{
			Connection con = null;
			boolean connectivityEstablished = false;
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				con = java.sql.DriverManager.getConnection(connectionString);
				if(con!=null) 
					logger.info("Connection Successful!");

				Statement stmt = con.createStatement();

				ResultSet rs = stmt.executeQuery(Query);

				ResultSetMetaData metaData = rs.getMetaData();
				int count = metaData.getColumnCount();

				ArrayList<String> QueryData=new ArrayList<String> ();
				while (rs.next())
				{ 
					QueryData.add(rs.getString(1));   	            		
				}
				if(QueryData.equals(null)) 
				{
					QueryData.get(0).replace(null, "");
				}

				Data=QueryData.get(0);
			}
			catch (Exception e)
			{
				System.out.println("Connection  Failed");
				e.printStackTrace();
				throw e;

			} 
			// Iterate through the data in the result set and display it.
		}
		catch(Exception e)
		{
			System.out.print(e.getMessage());
			System.out.print(e.getStackTrace());
			throw e;
		}
		return Data;	   
	}
	
	public void InsertQueries(String connectionString,String TableName,ArrayList<String> Headers,ArrayList<ArrayList<String>> Queries)throws Exception
	{

		ArrayList<HashMap<String,String>> TableData= new ArrayList<HashMap<String,String>>();
		ArrayList<String> ColumnNames= new ArrayList<String>();
		String columnNames="(";

		try
		{

			Connection con = null;
			boolean connectivityEstablished = false;
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				con = java.sql.DriverManager.getConnection(connectionString);
				if(con!=null) 
					logger.info("Connection Successful!");
				int j=1;
				for(String columnName : Headers) 
				{
					if(j==1) 
					{
						columnNames=columnNames+columnName;
					}
					else 
					{
						columnNames=columnNames+","+columnName;
					}
					j++;
				}
				columnNames=columnNames+")";

				for(ArrayList<String> rowData : Queries)
				{
					String Query="";
					for(int i=0;i<rowData.size();i++)
					{
						if(i==(rowData.size()-1))
						{
							Query= Query+ "'" + rowData.get(i).toString() + "');";

						}
						else
						{
							Query= Query+ "'" + rowData.get(i).toString() + "',";
						}


					}
					Thread.sleep(10);
					Query ="Insert into " +TableName + columnNames+ "values("+ Query;
					Statement stmt = con.createStatement();   			
					Query=Query.replace("'getDate()'", "getDate()");
					System.out.println(Query);
					stmt.execute(Query); 
					System.out.println("Report Inserted into DB");

				}
			} 
			catch (Exception e) 
			{
				System.out.println("Connection  Failed");
				e.printStackTrace();
				throw e;
			} 


			// Iterate through the data in the result set and display it.
		}
		catch(Exception e)
		{
			System.out.print(e.getMessage());
			System.out.print(e.getStackTrace());
			throw e;
		}

	}
}

