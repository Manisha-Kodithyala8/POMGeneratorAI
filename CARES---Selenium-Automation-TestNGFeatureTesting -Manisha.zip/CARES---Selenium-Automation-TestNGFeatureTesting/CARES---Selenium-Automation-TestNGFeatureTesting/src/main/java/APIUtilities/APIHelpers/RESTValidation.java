package APIUtilities.APIHelpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;

import APIUtilities.APICommon.APIMaster;
import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APISessionData;
import APIUtilities.TestSettings.APITestSettings;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class RESTValidation {
	 public ArrayList<APIReportModel> validateAPIPostResponse(APIReportModel apiReportModel, String ExpectedResponse) throws Exception 
	 {
		ArrayList<APIReportModel> aPIReportModels= new ArrayList<APIReportModel>();
		APIReportModel aPIReportModel= new APIReportModel();
		aPIReportModel.boolResponseStringValidation=true;
		String expectedJson = "";
		String actualJson ="";
		//expectedResponseFile=new File(".").getCanonicalPath()+"src\\test\\resources\\APIExpectedResponse\\"+driver.datavalue;
		
		try 
		{
	//		expectedJson = FileUtils.readFileToString(new File(postJson),StandardCharsets.UTF_8);
//			actualJson = FileUtils.readFileToString(new File(expectedResponseFile),StandardCharsets.UTF_8);			
		//JSONAssert.assertEquals(expectedJson, actualJson, JSONCompareMode.STRICT);
		JSONCompareResult CompareJSON=JSONCompare.compareJSON(ExpectedResponse, apiReportModel.Response, JSONCompareMode.STRICT);
		if(CompareJSON.passed())
		{
			aPIReportModel.TestStepResult="PASS";
		}
		else
		{
			aPIReportModel.TestStepResult="FAIL";
		}
		
		aPIReportModel.ExpectedResponse=expectedJson;
		aPIReportModel.ActualResponse=actualJson;
		aPIReportModel.URL=apiReportModel.URL;
		aPIReportModel.Request=apiReportModel.Request;
		aPIReportModel.Response=apiReportModel.Response;

		} 
		catch (JSONException e) 
		{
			// TODO Auto-generated catch block
			System.out.println("Exception is " + e);
			e.printStackTrace();
			aPIReportModel.boolResponseStringValidation=true;

			aPIReportModel.TestStepResult="FAIL";
			aPIReportModel.AdditionalDetails=e.getStackTrace().toString();

		}
		aPIReportModels.add(aPIReportModel);
		return aPIReportModels;
		
		
	}
	
	 public ArrayList<APIReportModel> validateJSONPath(APIReportModel apiReportModel, HashMap<String,String> JSONPath) throws Exception 
	 {
		ArrayList<APIReportModel> aPIReportModels= new ArrayList<APIReportModel>();

		String expectedJson = "";
		String actualJson ="";
		//expectedResponseFile=new File(".").getCanonicalPath()+"src\\test\\resources\\APIExpectedResponse\\"+driver.datavalue;
		
		try 
		{
			if(JSONPath.isEmpty()==false)
			{
				for(String key :JSONPath.keySet())
				{
					APIReportModel aPIReportModel= new APIReportModel();
					aPIReportModel.boolXMLJSONValidation=true;
					JsonPath jsonPath = new JsonPath(apiReportModel.Response);
					String ActualResponse="";
					String ExpectedResponse=JSONPath.get(key);
					
					HashMap<String,String> JSONValues= new HashMap<String,String>();
					try
					{
						aPIReportModel.URL=apiReportModel.URL;
						aPIReportModel.Request=apiReportModel.Request;
						aPIReportModel.Response=apiReportModel.Response;
						
						if(key.startsWith("TEXTCHECK::"))
						{
							TextValidation textValidation= new TextValidation();
							ActualResponse=textValidation.getTextCheckResponse(apiReportModel.Response,ExpectedResponse);
							aPIReportModel.XPathJSONKey=key + ExpectedResponse;
							aPIReportModel.ExpectedResponse=ExpectedResponse;
							aPIReportModel.ActualResponse=ActualResponse;
						}
						
						else
						{
						ActualResponse= jsonPath.getString(key);
						
						aPIReportModel.XPathJSONKey=key;
						aPIReportModel.ExpectedResponse=ExpectedResponse;
						aPIReportModel.ActualResponse=ActualResponse;
						if(aPIReportModel.ActualResponse == null)
							aPIReportModel.ActualResponse = "null";
						}
					}
					catch(Exception ex)
					{
						ActualResponse="";	
					}

					

					if(aPIReportModel.ActualResponse.equals(aPIReportModel.ExpectedResponse)==false)
					{
						aPIReportModel.TestStepResult="FAIL";
					
					}
					else
					{
						aPIReportModel.TestStepResult="PASS";

					}
					aPIReportModels.add(aPIReportModel);
				}
			}
			
		

		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			System.out.println("Exception is " + e);
			e.printStackTrace();
			APIReportModel aPIReportModel= new APIReportModel();
			aPIReportModel.boolXMLJSONValidation=true;

			aPIReportModel.TestStepResult="FAIL";
			aPIReportModel.AdditionalDetails=e.getStackTrace().toString();
			aPIReportModels.add(aPIReportModel);

			
		}
		return aPIReportModels;				  
	}

	 
	 public HashMap<String,String>  storeJSONPath(String JSONResponse, HashMap<String,String> JSONPath) throws Exception 
	 {
		
		 HashMap<String,String> SessionData= new HashMap<String,String>();
		try 
		{
			if(JSONPath.isEmpty()==false)
			{
				for(String key :JSONPath.keySet())
				{
				
					JsonPath jsonPath = new JsonPath(JSONResponse);
					String VariableName=JSONPath.get(key);
					
					
					String ActualValue= jsonPath.getString(key);
						
					SessionData.put(VariableName, ActualValue);

					


				}
			}
			
		

		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			System.out.println("Exception is " + e);
			e.printStackTrace();

			
		}
	
	 return SessionData;
	 }


	 
	 public String[] fetchData(String getData)                                             // Function to get data from excel and store each node separately                            
	{
		
		//String getData = Driver.dataValue;                              // Fetching API response from excel to getData variable
		String[] tempArr = new String[1000];
		String[] childElements = new String[1000];
		int k =0, j=0;
		
		if(getData.contains(";"))                                       // if condition to check if the getData string has a semi-colon or not.  
		{
		    String[] childData = getData.split(";");                    // to split based getData string on semi-colon
				
		    for (int i =0; i <childData.length;i++)                     // business logic to further split all the strings based on "|" symbol  
		    {
			    if(childData[i].contains("|"))                          
			    {
			        tempArr = childData[i].split("\\|");
			
			        for ( j=0 ; j<tempArr.length;j++ )                  // additional for loop to ensure childElements string is appended, not over-written 
			        {
				       childElements[k+j] = tempArr[j];				
			        }
			        k= k+j;
						
		        }
			
			    else                                                     
			    {
			        childElements[k] = childData[i];	
			        k++;
			    }			
		     }
		}
		
		else                                                            // when there is only 1 child string in getData ==> no semi-colon 
		{
			childElements = getData.split("\\|");
		}
		
		return childElements;
	}
	
	public void validateDataElements(Response responsePost, String[] childElements) throws JSONException                                                        // function to validate the individual nodes    
	{                                                                                                       // derived from fetchData() method
		   // baseAddress = Util.getValueFromConfigProperties("WP_INS1_URL");        
		   // extendedAddress = Driver.dataValue;
		   // String get_URI = baseAddress + extendedAddress;			
		   // responsePost = RestAssured.get(get_URI);		
		    System.out.println(responsePost.getBody());
		    System.out.println(responsePost.getBody().asString());

    		int index = -1;                                                                                 // index to fetch the position of node in .json file 
		    
			for (int i =0; i<childElements.length && childElements[i] != null; i++)                         // Business logic to validate every node
			{
			    String[] seperateFromHash = childElements[i].split("#");
			    
			    if(seperateFromHash.length == 3)
			    {
			    	//response = RestAssured.get(get_URI);
			    	if(index == -1)                                                                             // condition to ensure child number is given correctly
	                {
	                	System.out.println("Invalid input! Must mention the child string number correctly!");   
	                	continue;                                                                               // loop skips directly to next iteration
	                }
			    	
                   String nestedTemp = seperateFromHash[0] + "[" + index + "]";			    	
			    	Map<String, String> nestedData = responsePost.jsonPath().getMap(nestedTemp);
			    	
			    	if((nestedData.get(seperateFromHash[1])).equalsIgnoreCase(seperateFromHash[2]))
			    	{
			    		System.out.println("Child Element " + seperateFromHash[1] + " Validation is PASSED!");
	                }
	                else
	                {
	                	System.out.println("Child Element " + seperateFromHash[1] + " Validation is FAILED!");
	                }
			    	
			    	continue;
			    }
			    
			    JsonPath jsonPathEvaluator = responsePost.jsonPath(); 
			    String elementField = seperateFromHash[0];    
               
               if(elementField.equalsIgnoreCase("Child"))                                                  // condition to set value of index variable
               {
               	index = Integer.parseInt(seperateFromHash[1]) - 1 ;
               	continue;                                                                               // loop skips directly to next iteration 
               }
               
               if(index == -1)                                                                             // condition to ensure child number is given correctly
               {
               	System.out.println("Invalid input! Must mention the child string number correctly!");   
               	continue;                                                                               // loop skips directly to next iteration
               }
               
               String temp =  seperateFromHash[0] + "[" + index + "]";                                     // temporary variable to achieve format "node[index]"
               
               String dataPointValue = responsePost.jsonPath().getString(temp);                                // fetching the node value
                               			    
               if(dataPointValue.equalsIgnoreCase(seperateFromHash[1]))                                    // validating the fetched node value
               {
               	System.out.println("Child number "+ (index + 1) +" for Child Element " + seperateFromHash[0] + " Validation is PASSED!");
               }
               else
               {
               	System.out.println("Child number "+ (index + 1) +" for Child Element " + seperateFromHash[0] + " Validation is FAILED!");
               }
               
            } 

	 }

}
