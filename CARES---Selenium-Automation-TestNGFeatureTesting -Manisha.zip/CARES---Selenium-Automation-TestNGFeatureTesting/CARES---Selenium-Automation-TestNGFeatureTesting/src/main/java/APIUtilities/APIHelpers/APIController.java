package APIUtilities.APIHelpers;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import APIUtilities.APICommon.APIMaster;
import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APISessionData;
import APIUtilities.TestSettings.APITestSettings;
import io.restassured.response.Response;

public class APIController {

	public ArrayList<APIReportModel> ExecuteAPI(String TestCase,String ModuleName, String InterfaceName,String Browser, String Iteration,String APIFilePath)
	{
		APIMaster interfaceMaster = new APIMaster();
		ArrayList<APIReportModel> apiReportModels = new ArrayList<APIReportModel>();
		Response response = null;
		try {
			APIModel IModel=	interfaceMaster.fetchInterfaceRepository(APITestSettings.apiTestSettings,TestCase,ModuleName,InterfaceName,Iteration,APIFilePath);

			RESTHelper apiREST = new RESTHelper();
			SOAPHelper apiSOAP = new SOAPHelper();

			String APIType=IModel.getInterfaceType();
			String MethodType=IModel.getMethodType();
			RESTValidation validateREST= new RESTValidation();
			SOAPValidations validateSOAP= new SOAPValidations();
			DBValidation validateDB = new DBValidation();
			String Request=IModel.gettRequestData();
			String ExpectedResponse=IModel.getResponseData();
			String URL= IModel.getServiceUrl();
			String DBQuery = IModel.getDBQuery();
			String DBExpectedValue =IModel.getDBExpectedValue();
			
			if(APIType.equalsIgnoreCase("REST"))
			{
				response=apiREST.ExecuteRESTAPI(IModel,Iteration,MethodType);	
				APIReportModel apiReportModel = new APIReportModel();
				apiReportModel.URL=URL;
				apiReportModel.Request=Request;
				apiReportModel.Response=response.getBody().asString();
				apiReportModel.StatusCode = "Status Code: =>"+response.getStatusCode()+"; Status Line: =>"+response.getStatusLine();


				if(response.statusCode()==200)
				{
					if(IModel.getResponsePath().equals((""))==false)
					{
						apiReportModels=validateREST.validateAPIPostResponse(apiReportModel, ExpectedResponse);

					}
					else if(IModel.getResponseValidationModel().XPathJSONPath.isEmpty()==false)
					{
						apiReportModels=validateREST.validateJSONPath(apiReportModel,IModel.getResponseValidationModel().XPathJSONPath);


					}

					else {
					HashMap<String,String> sessionData = validateREST.storeJSONPath(response.getBody().asString(), IModel.getStoreResponseModel().XPathJSONPath);


					APISessionData.setSessionDataCollection(TestCase, ModuleName, Browser, Iteration, sessionData);

					apiReportModel.TestStepResult="PASS";
					apiReportModel.AdditionalDetails=IModel.getInterfaceName() + " executed successfully.";
					apiReportModels.add(apiReportModel);
					}
				}
				else
				{
					apiReportModels.add(apiReportModel);
					apiReportModels.get(0).TestStepResult="FAIL";
					apiReportModels.get(0).AdditionalDetails=IModel.getInterfaceName() + " Failed. Response Code : +" +response.statusCode() + "Error Details : " + response.asString();
					
				}
				//DB VALIDATION
				if(APITestSettings.DBValidation.equalsIgnoreCase("Yes")) {
					if(!(DBQuery.equalsIgnoreCase("N//A"))) {

						apiReportModel.DBActualValue = validateDB.validateDBStatus(IModel);
						apiReportModel.DBExpectedValue = IModel.getDBExpectedValue();
						apiReportModel.DBValidation = IModel.getDBQuery();
						if(IModel.getDBExpectedValue().equals(apiReportModel.DBActualValue)) {
							apiReportModels.get(0).TestStepResult="PASS";
							apiReportModels.get(0).AdditionalDetails=apiReportModel.AdditionalDetails+":DB Validation was successful.";
							//apiReportModels.add(apiReportModel);
						}
						else
						{
							apiReportModels.get(0).TestStepResult="FAIL";
							apiReportModels.get(0).AdditionalDetails=apiReportModel.AdditionalDetails+":Expected value mismatch in DB validation";
							//apiReportModels.add(apiReportModel);
						}

					}
				}

			}
			else if(APIType.equalsIgnoreCase("SOAP"))
			{

				response=apiSOAP.ExecuteSOAPAPI(IModel,Iteration);	
				APIReportModel apiReportModel = new APIReportModel();
				apiReportModel.URL=URL;
				apiReportModel.Request=Request;
				apiReportModel.Response=response.getBody().asString();	
				if(response.statusCode()==200)
				{
					if(IModel.getResponsePath().equals((""))==false)
					{
						apiReportModels=validateSOAP.validateAPIPostResponse(apiReportModel, ExpectedResponse);
					}
					else if(IModel.getResponseValidationModel().XPathJSONPath.isEmpty()==false)
					{

						apiReportModels=validateSOAP.validateXPath(apiReportModel,IModel.getResponseValidationModel().XPathJSONPath);
					}

					else {
					HashMap<String,String> sessionData = validateSOAP.storeXPath(response.getBody().asString(), IModel.getStoreResponseModel().XPathJSONPath);


					APISessionData.setSessionDataCollection(TestCase, ModuleName, Browser, Iteration, sessionData);
					apiReportModel.TestStepResult="PASS";
					apiReportModel.AdditionalDetails=IModel.getInterfaceName() + " executed successfully.";
					apiReportModels.add(apiReportModel);
					}

				}
				else
				{
					apiReportModels.add(apiReportModel);
					apiReportModels.get(0).TestStepResult="FAIL";
					apiReportModels.get(0).AdditionalDetails=IModel.getInterfaceName() + " Failed. Response Code : +" +response.statusCode() + "Error Details : " + response.asString();
					
				}
				
				//DB VALIDATION
				if(APITestSettings.DBValidation.equalsIgnoreCase("Yes")) {
					if(!((DBQuery.equalsIgnoreCase("N//A")) || (DBQuery.equalsIgnoreCase("")))) {

						apiReportModel.DBActualValue = validateDB.validateDBStatus(IModel);
						apiReportModel.DBExpectedValue = IModel.getDBExpectedValue();
						apiReportModel.DBValidation = IModel.getDBQuery();
						if(IModel.getDBExpectedValue().equals(apiReportModel.DBActualValue)) {
							apiReportModels.get(0).TestStepResult="PASS";
							apiReportModels.get(0).AdditionalDetails=apiReportModel.AdditionalDetails+":DB Validation was successful.";
							//apiReportModels.add(apiReportModel);
						}
						else
						{
							apiReportModels.get(0).TestStepResult="FAIL";
							apiReportModels.get(0).AdditionalDetails=apiReportModel.AdditionalDetails+":Expected value mismatch in DB validation";
							//apiReportModels.add(apiReportModel);
						}

					}
				}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return apiReportModels;

	}

	public void ExecuteAPI(String ModuleName, String InterfaceName)
	{

	}


	public void StoreRESTResponse(String ResponseLocation, 	Response responsePost) 
	{
		FileWriter file;

		try 
		{
			file = new FileWriter(ResponseLocation);

			file.write(responsePost.prettyPrint());
			file.flush();
			file.close();
		}

		catch (IOException e) 
		{
			System.out.println("Exception is " + e);
			e.printStackTrace();  
		}		
	}
}
