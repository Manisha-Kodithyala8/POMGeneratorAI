package APIUtilities.APIHelpers;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.SSLProtocolException;

import org.testng.annotations.Test;

import APIUtilities.APICommon.APIMaster;
import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APISessionData;
import APIUtilities.TestSettings.APITestSettings;


import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.restassured.RestAssured;
import io.restassured.common.mapper.TypeRef;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.http.Headers;
import io.restassured.mapper.ObjectMapper;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.json.config.JsonPathConfig;
import io.restassured.path.xml.XmlPath;
import io.restassured.path.xml.XmlPath.CompatibilityMode;
import io.restassured.path.xml.config.XmlPathConfig;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;

import org.hamcrest.Matchers;
import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.slf4j.LoggerFactory;

public class RESTHelper 
{

	final Logger logger = LoggerFactory.getLogger(RESTHelper.class.getName());

	public Response ExecuteRESTAPI(APIModel IModel , String Iteration,String APIType)throws Exception
	{
		Response responsePost = null ;


		Map<String, String>  defaultHeaders = IModel.GetHeaderData();
		String jsonDataInFile="";
		jsonDataInFile=IModel.gettRequestData();
		String CertificatePath=IModel.getCertificatePath();
		String CertificatePassword=IModel.getCertificatePassword();		

		String ServiceURL=IModel.getServiceUrl();
		KeyStore keyStore = null;
		SSLConfig config = null;
		if(APITestSettings.isKeyStoreConfigurationRequired)
		{
		

		try {
			keyStore = KeyStore.getInstance("PKCS12");
			keyStore.load(
					new FileInputStream(CertificatePath),
					CertificatePassword.toCharArray());

		} catch (Exception ex) {
			System.out.println("Error while loading keystore >>>>>>>>>");
			ex.printStackTrace();
		}
		}
		if (IModel.isMockRequired())
		{
			try
			{

				FileWriter file;

				file = new FileWriter(IModel.GetMockData().MockLocation);

				file.write(IModel.GetMockData().MockFileContent);
				file.flush();
				file.close();
			}
			catch (Exception e)
			{
				logger.error("Unable to create the mock File===>" + IModel.GetMockData().MockFileName);
				logger.error(e.getMessage());
				logger.error(e.getStackTrace().toString());

				System.out.println("Unable to create the mock File===>" + IModel.GetMockData().MockFileName);
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());
			}
		}




		if(defaultHeaders.isEmpty())
		{
			if(IModel.isCertificateRequired())
			{
				if(APITestSettings.isKeyStoreConfigurationRequired)
				{
				if (keyStore != null) {

					org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, CertificatePassword);

					// set the config in rest assured
					config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
					RestAssured.config = RestAssured.config().sslConfig(config);
				}
				}

				if(APIType.equalsIgnoreCase("GET"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.get(ServiceURL);
				}


				if(APIType.equalsIgnoreCase("POST"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.post(ServiceURL);
				}
				else  if(APIType.equalsIgnoreCase("PUT"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.put(ServiceURL);
				}
				else if(APIType.equalsIgnoreCase("PATCH"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.patch(ServiceURL);
				}
				else if(APIType.equalsIgnoreCase("DELETE"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.delete(ServiceURL);
				}
			}
			else
			{
				if(APIType.equalsIgnoreCase("GET"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.get(ServiceURL);	
				}
				if(APIType.equalsIgnoreCase("POST"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.post(ServiceURL);	
				}
				if(APIType.equalsIgnoreCase("PUT"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.put(ServiceURL);	
				}
				if(APIType.equalsIgnoreCase("PATCH"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.patch(ServiceURL);	
				}
				if(APIType.equalsIgnoreCase("DELETE"))
				{
					responsePost =		
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.contentType(ContentType.JSON)
							.expect()
							.when()
							.delete(ServiceURL);	
				}
			}
		}

		else
		{
			if(IModel.isCertificateRequired())
			{
				RestAssured.config = RestAssured.config().sslConfig(
						new SSLConfig().trustStore(APITestSettings.TrustStoreLocation,APITestSettings.TrustStorePassword)
						.keyStore(CertificatePath, CertificatePassword));

				if(APIType.equalsIgnoreCase("GET"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.get(ServiceURL);
				}

				if(APIType.equalsIgnoreCase("POST"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.post(ServiceURL);
				}
				if(APIType.equalsIgnoreCase("PUT"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.put(ServiceURL);
				}
				if(APIType.equalsIgnoreCase("PATCH"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.patch(ServiceURL);
				}
				if(APIType.equalsIgnoreCase("DELETE"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.delete(ServiceURL);
				}
			}
			else
			{
				if(APIType.equalsIgnoreCase("GET"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.get(ServiceURL);
				}
				if(APIType.equalsIgnoreCase("POST"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.post(ServiceURL);
				}
				if(APIType.equalsIgnoreCase("PUT"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.put(ServiceURL);
				}
				if(APIType.equalsIgnoreCase("PATCH"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.body(jsonDataInFile)
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.patch(ServiceURL);
				}
				if(APIType.equalsIgnoreCase("DELETE"))
				{

					responsePost =
							RestAssured.given()
							.urlEncodingEnabled(false)
							.relaxedHTTPSValidation()
							.config(RestAssured.config())
							.contentType(ContentType.JSON)
							.headers(defaultHeaders)
							.expect()
							.when()
							.delete(ServiceURL);
				}
			}
		}
		MSSQLUtilities dbvalidation = new MSSQLUtilities();
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("-------" + IModel.getModule() + "==>" + IModel.getInterfaceName() + "--------------");
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("------------------------" + ServiceURL + "-----------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("------------------------" + APITestSettings.TrustStoreLocation + "-----------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------");

		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("------------------------" + APITestSettings.TrustStorePassword + "-----------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------");

		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("------------------------" + CertificatePath + "-----------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------");

		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("------------------------" + CertificatePassword + "-----------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------");

		System.out.println("-----------------------------------------------------------");
		System.out.println("--------------------------Request--------------------------");
		System.out.println("-----------------------------------------------------------");
		System.out.println(jsonDataInFile);
		System.out.println("-----------------------------------------------------------");
		System.out.println("--------------------------Response--------------------------");
		System.out.println("-----------------------------------------------------------");
		System.out.println(responsePost.asString());


		logger.info("-----------------------------------------------------------------------------------");
		logger.info("-------" + IModel.getModule() + "==>" + IModel.getInterfaceName() + "--------------");
		logger.info("-----------------------------------------------------------------------------------");
		logger.info("-----------------------------------------------------------------------------------");
		logger.info("------------------------" + ServiceURL + "-----------------------------------------");
		logger.info("-----------------------------------------------------------------------------------");
		logger.info("-----------------------------------------------------------");
		logger.info("--------------------------Request--------------------------");
		logger.info("-----------------------------------------------------------");
		logger.info(jsonDataInFile);
		logger.info("-----------------------------------------------------------");
		logger.info("--------------------------Response--------------------------");
		logger.info("-----------------------------------------------------------");
		logger.info(responsePost.asString());
		return responsePost;
	}
}