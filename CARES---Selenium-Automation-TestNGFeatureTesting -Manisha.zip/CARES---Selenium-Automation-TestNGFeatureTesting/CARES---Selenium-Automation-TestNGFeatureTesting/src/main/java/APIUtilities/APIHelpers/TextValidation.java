package APIUtilities.APIHelpers;

public class TextValidation {

	public String getTextCheckResponse(String JSONResponse,String ExpectedResponse)
	{
		
		if(JSONResponse.contains(ExpectedResponse))
		{
			return ExpectedResponse;
		}
		else
		{
			return JSONResponse;
		}
		
	}
	
}
