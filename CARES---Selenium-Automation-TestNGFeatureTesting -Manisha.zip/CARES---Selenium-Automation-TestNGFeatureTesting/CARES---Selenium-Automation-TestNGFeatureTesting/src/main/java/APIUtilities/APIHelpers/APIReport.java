package APIUtilities.APIHelpers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.util.ArrayList;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import APIUtilities.Models.APIReportModel;
import APIUtilities.TestSettings.APITestSettings;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Constants.ReportContants;;

public class APIReport {

	
	public void AddTestStep(TestCaseParam testCaseParam,ArrayList<APIReportModel> apiReportModels) throws Exception
	{
		
		ReportCommon reportCommon = new ReportCommon();
		reportCommon.logAPIModule(testCaseParam, testCaseParam.ModuleName + "===>" + testCaseParam.APIName +"==>" + testCaseParam.Iteration);
		

		reportCommon.logAPIModule(testCaseParam, "Request");
		if(apiReportModels.get(0).Request.contains("<")) {
			apiReportModels.get(0).Request = "<textarea style='color:black'>"+apiReportModels.get(0).Request+"</textarea>";
		}
		
		reportCommon.logAPITestStep(testCaseParam,"Request" +apiReportModels.get(0).Request,"Request" +apiReportModels.get(0).Request,LocalDateTime.now(),ReportContants.Status_Done,"","");
		if(apiReportModels.get(0).Response.contains("<")) {
			apiReportModels.get(0).Response = "<textarea style='color:black'>"+apiReportModels.get(0).Response+"</textarea>";
		}
		reportCommon.logAPITestStep(testCaseParam,"Response" +apiReportModels.get(0).Request,"Response" +apiReportModels.get(0).Response,LocalDateTime.now(),ReportContants.Status_Done,"","");

		
		
		reportCommon.logAPIModule(testCaseParam,"Results");

		int ResultCounter=0;
		for(APIReportModel apiReportModel:apiReportModels)
		{
			ResultCounter++;
			String APIStatus = ReportContants.Status_Done;
			if(apiReportModels.get(0).TestStepResult.equalsIgnoreCase("PASS"))
			{
				APIStatus=ReportContants.Status_Pass;
			}
			else if(apiReportModels.get(0).TestStepResult.equalsIgnoreCase("FAIL"))
			{
				APIStatus=ReportContants.Status_Fail;				
			}

			Thread.sleep(0);
			if(!(apiReportModels.get(0).ActualResponse.equals(""))) {

				reportCommon.logAPITestStep(testCaseParam,"Status Info :  "+ apiReportModels.get(0).StatusCode,"Status Info :  "+ apiReportModels.get(0).StatusCode,LocalDateTime.now(),ReportContants.Status_Done,"","");
				reportCommon.logAPITestStep(testCaseParam,"Validation :  "+ apiReportModel.XPathJSONKey,"Validation :  "+ apiReportModel.XPathJSONKey,LocalDateTime.now(),ReportContants.Status_Done,"","");
				reportCommon.logAPITestStep(testCaseParam,"<br> Expected Results <br>"+ apiReportModel.ExpectedResponse,"<br> Expected Results <br>"+ apiReportModel.ExpectedResponse,LocalDateTime.now(),ReportContants.Status_Done,"","");
				reportCommon.logAPITestStep(testCaseParam,"Actual Results <br>"+ apiReportModel.ActualResponse,"Actual Results <br>"+ apiReportModel.ActualResponse,LocalDateTime.now(),APIStatus,"","");

			}
		}

		if(APITestSettings.DBValidation.equalsIgnoreCase("Yes")) {
			String APIStatus = ReportContants.Status_Done;
			if(apiReportModels.get(apiReportModels.size()-1).TestStepResult.equalsIgnoreCase("PASS"))
			{
				APIStatus=ReportContants.Status_Pass;
			}
			else if(apiReportModels.get(apiReportModels.size()-1).TestStepResult.equalsIgnoreCase("FAIL"))
			{
				APIStatus=ReportContants.Status_Fail;				
			}
			
			reportCommon.logAPIModule(testCaseParam,"DB Validation Result");

			reportCommon.logAPITestStep(testCaseParam,"Query Validation :  "+ apiReportModels.get(apiReportModels.size()-1).DBValidation,"Query Validation :  "+ apiReportModels.get(apiReportModels.size()-1).DBValidation,LocalDateTime.now(),ReportContants.Status_Done,"","");
			reportCommon.logAPITestStep(testCaseParam,"<br> Expected DB Results <br>"+ apiReportModels.get(apiReportModels.size()-1).DBExpectedValue,"<br> Expected DB Results <br>"+ apiReportModels.get(apiReportModels.size()-1).DBExpectedValue,LocalDateTime.now(),ReportContants.Status_Done,"","");
			reportCommon.logAPITestStep(testCaseParam,"Actual DB Results <br>"+ apiReportModels.get(apiReportModels.size()-1).DBActualValue,"Actual DB Results <br>"+ apiReportModels.get(apiReportModels.size()-1).DBActualValue,LocalDateTime.now(),APIStatus,"","");
			
		}
	}


	public String WriteDataToTextFile(String FilePath, String FileName,String FileContent,String FileFormat)
	{
		FilePath = FilePath + "\\" + FileName + FileFormat;
		try
		{

			BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath));
			writer.write(FileContent);

			writer.close();

			FilePath= FilePath.replace("\\","/");

			FilePath = "<a href = 'file:///"+ FilePath + "'>"+ FileName + "</a>";
			return FilePath;
		}

		catch (Exception e)
		{
			return FilePath;
		}
	}

	public String WriteImageToReport(String FilePath, String FileName)
	{

		try
		{
			FilePath = FilePath.replace("\\", "/");
			FilePath = "<a href = 'file:///" + FilePath + "'>" + FileName + "</a>";
			return FilePath;
		}

		catch (Exception e)
		{
			return FilePath;
		}
	}



}
