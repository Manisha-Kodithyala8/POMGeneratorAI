package APIUtilities.APICommon;

import java.io.IOException;
import java.util.ArrayList;

import APIUtilities.APIHelpers.SOAPHelper;
import APIUtilities.APIHelpers.APIController;
import APIUtilities.APIHelpers.RESTHelper;
import APIUtilities.APIHelpers.RESTValidation;
import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIReportModel;
import APIUtilities.Models.APIConfig;
import APIUtilities.TestSettings.InitializeAPISettings;
import APIUtilities.TestSettings.APITestSettings;
import io.restassured.response.Response;

public class InterfaceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String ConfigLocation=APITestSettings.HomePath+"\\config.properties";
		String ArtifactsPath=APITestSettings.ArtifactsPath;

//		String PrjPath="C:\\Users\\ybaberwal\\Documents\\JJIS_Automation\\GPSAutomation\\ApiUtilities";
		String Env="PERF";
		InitializeAPISettings initializeTestSettings= new InitializeAPISettings();
		
		APITestSettings.apiTestSettings = initializeTestSettings.InitializeInterfaceSettings(APITestSettings.HomePath,ArtifactsPath,ConfigLocation,Env);
		
		try {
		
		APIController apiController = new APIController();
		
//		ArrayList<APIReportModel> apiModels=apiController.ExecuteAPI("SearchMembers","MCI","SearchMembers", "1", TestRunSettings.ArtifactsPath+"\\MCI\\SearchMembers.json");
//		ArrayList<APIReportModel> apiModels1=apiController.ExecuteAPI("MCI","CreateAndUpdateMember","1");
//		ArrayList<APIReportModel> apiModels2=apiController.ExecuteAPI("Test","Weather","1");
//		
//		System.out.println(apiModels.get(0).boolResponseStringValidation);
//		System.out.println(apiModels.get(0).XPathJSONKey);
//		System.out.println(apiModels.get(0).ActualResponse);
//		System.out.println(apiModels.get(0).ExpectedResponse);
//		System.out.println(apiModels.get(1).boolResponseStringValidation);
//		System.out.println(apiModels.get(1).XPathJSONKey);
//		System.out.println(apiModels.get(1).ActualResponse);
//		System.out.println(apiModels.get(1).ExpectedResponse);
//		System.out.println(apiModels.get(2).boolResponseStringValidation);
//		System.out.println(apiModels.get(2).XPathJSONKey);
//		System.out.println(apiModels.get(2).ActualResponse);
//		System.out.println(apiModels.get(2).ExpectedResponse);
//		System.out.println(apiModels.get(3).boolResponseStringValidation);
//		System.out.println(apiModels.get(3).XPathJSONKey);
//		System.out.println(apiModels.get(3).ActualResponse);
//		System.out.println(apiModels.get(3).ExpectedResponse);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
