package APIUtilities.APICommon;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import APIUtilities.APIHelpers.MSSQLUtilities;
import APIUtilities.Models.APIModel;
import APIUtilities.Models.APIConfig;
import APIUtilities.Models.MockData;
import APIUtilities.Models.ResponseValidationModel;
import APIUtilities.Models.StoreResponseModel;
import APIUtilities.TestSettings.APISessionData;
import APIUtilities.TestSettings.APITestSettings;

public class APIMaster {

	public APIModel fetchInterfaceRepository(APIConfig InterfaceTestSettings,String TestCase,String ModuleName, String InterfaceName,String Iteration,String APIFilePath) throws Exception
	{
		ExcelUtil poiObj = new ExcelUtil();
		APIUtil utilObj = new APIUtil();
		final Logger logger =LoggerFactory.getLogger(APIMaster.class.getName()); 

		try
		{

			ArrayList<String> whereClause = new ArrayList<String>();

			whereClause.add("Module::"+ModuleName);
			whereClause.add("InterfaceName::"+InterfaceName);

			HashMap<String, ArrayList<String>> InterfacesArrayList = poiObj.fetchWithCondition(APIFilePath,InterfaceTestSettings.InterfaceTestCaseSheet, whereClause);

			try
			{

				String RequestPath = "";
				String ResponsePath = "";
				String TestDataPath = "";

				String RequestData = "";
				String ResponseData = "";
				String MockData="";
				String Module = "";

				String FileFormat = "";
				String InterfaceType = "";
				String ServiceURL = "";
				String SOAPAction = "";
				String MethodType = "";
				String CertificateRequired;
				String CertificateFileName = "";
				String CertificatePassword = "";
				String DBQuery="";
				String DBExpectedValue="";
				String NeedMock;
				String MockedInterfaceName;
				int Timeout;
				String TemplateData = "";

				ResponseValidationModel responsevalidationModel= new ResponseValidationModel();
				RequestPath = InterfaceTestSettings.RequestLocation  + InterfacesArrayList.get("RequestFileName").get(0);
				ResponsePath = InterfacesArrayList.get("ResponseFileName").get(0).trim().equals("") ? "" : InterfaceTestSettings.ResponseLocation  + InterfacesArrayList.get("ResponseFileName").get(0);
				TestDataPath = InterfaceTestSettings.TestDataPath + InterfacesArrayList.get("TestDataFileName").get(0);
				String TestDataFileName = InterfacesArrayList.get("TestDataFileName").get(0).trim().equals("") ? "" : InterfacesArrayList.get("TestDataFileName").get(0);

				Module = InterfacesArrayList.get("Module").get(0);
				InterfaceName = InterfacesArrayList.get("InterfaceName").get(0);
				FileFormat = InterfacesArrayList.get("FileFormat").get(0);
				InterfaceType = InterfacesArrayList.get("InterfaceType").get(0);
				
				NeedMock = InterfacesArrayList.get("NeedMock").get(0);
				MockedInterfaceName = InterfacesArrayList.get("MockedInterfaceName").get(0);
				if (InterfacesArrayList.get("Timeout").get(0).equals(""))
				{
					Timeout = InterfaceTestSettings.DefaultServiceTimeout;
				}
				else

				{
					try
					{
						Timeout = Integer.parseInt(InterfacesArrayList.get("Timeout").get(0));
					}

					catch (Exception e)
					{
						logger.error("Error while retrieving the timeout  value from the TestCasesheet. Hence setting the default timeout");
						Timeout = InterfaceTestSettings.DefaultServiceTimeout;
					}
				}


				//Initializing InterFace_Object
				APIModel interFaceObj = new APIModel();


				//Retrieving Url from URL_Repository
				ArrayList<String> whereClause_Url = new ArrayList<String>();
				whereClause_Url.add("Module::" + Module);
				whereClause_Url.add("InterfaceName::" + InterfaceName);
				//interFaceObj.setServiceUrl(poiObj.fetchWithCondition(TestRunSettings.UrlRepositorySheet, TestRunSettings.Environment, whereClause_Url)["URL"][0]);

				HashMap<String, ArrayList<String>> ServiceArrayList = poiObj.fetchWithCondition(InterfaceTestSettings.UrlRepositorySheet, InterfaceTestSettings.Environment, whereClause_Url);

				ServiceURL = ServiceArrayList.get("URL").get(0);
				SOAPAction = ServiceArrayList.get("SOAPAction").get(0);
				MethodType = ServiceArrayList.get("MethodType").get(0);
				CertificateRequired = ServiceArrayList.get("CertificateRequired").get(0);
				CertificateFileName = InterfaceTestSettings.CertificateLocation + ServiceArrayList.get("CertificateFileName").get(0);
				CertificatePassword = ServiceArrayList.get("CertificatePassword").get(0);
				DBQuery = ServiceArrayList.get("DBQuery").get(0);
				DBExpectedValue = ServiceArrayList.get("DBExpectedValue").get(0);
				if(DBQuery.contains("#StartDate#")) 
				{
					DBQuery = DBQuery.replace("#StartDate#", String.valueOf(APISessionData.getSessionStartTime()));
				
				}

				//Adding Mock Data
				MockData mockData = new MockData();
				interFaceObj.setMockDetails(NeedMock, MockedInterfaceName);

				if (interFaceObj.isMockRequired())
				{
					ArrayList<String> whereClause_Mock = new ArrayList<String>();
					whereClause_Mock.add("TemplateName::" + MockedInterfaceName);
					HashMap<String, ArrayList<String>> DictMockData = poiObj.fetchWithCondition(InterfaceTestSettings.MockRepositorySheet, InterfaceTestSettings.MockSheetName, whereClause_Mock);

					for (String MockKey : DictMockData.keySet())
					{


						if (MockKey.toUpperCase().equals("ID"))
						{
							mockData.ID = (DictMockData.get(MockKey).get(0));
						}
						if (MockKey.toUpperCase().equals("MOCKLOCATION"))
						{
							mockData.MockLocation = DictMockData.get(MockKey).get(0);

						}
						if (MockKey.toUpperCase().equals("TEMPLATENAME"))
						{
							mockData.TemplateName = DictMockData.get(MockKey).get(0);

						}
						if (MockKey.toUpperCase().equals("INTERFACETYPE"))
						{
							mockData.InterfaceType = DictMockData.get(MockKey).get(0);

						}
						if (MockKey.toUpperCase().equals("RECORDCOUNT"))
						{
							mockData.RecordCount = DictMockData.get(MockKey).get(0);

						}
						if (MockKey.toUpperCase().equals("MOCKFILENAME"))
						{
							mockData.MockFileName = DictMockData.get(MockKey).get(0);

						}
						if (MockKey.toUpperCase().equals("MOCKFILEFORMAT"))
						{
							mockData.MockFileFormat = DictMockData.get(MockKey).get(0);

						}

					}

				}


				//Retrieving Request and Response Template
				try
				{

					RequestData = FileUtils.readFileToString(new File(RequestPath),StandardCharsets.UTF_8);
					logger.info("Read the Request File :  "+ RequestPath);
					logger.info("RequestData Template for " + InterfaceName + ": \n" + RequestData);

				}
				catch (Exception e)
				{
					System.out.println(e.getMessage());
					System.out.println(e.getStackTrace());

					logger.info(e.getMessage());
					logger.info(e.getStackTrace().toString());

					throw new Exception("Error while reading the Request File"+ RequestPath);
				}

				try
				{



					ResponseData = ResponsePath.trim() == "" ? "" : FileUtils.readFileToString(new File(ResponsePath),StandardCharsets.UTF_8).trim();
					logger.info("Read the Respomse File :  " + ResponsePath);
					responsevalidationModel.ExpectedResponseFilePath=ResponsePath;
					responsevalidationModel.ExpectedResponse=ResponseData;

				}
				catch (Exception e)
				{
					System.out.println(e.getMessage());
					System.out.println(e.getStackTrace());

					logger.info(e.getMessage());
					logger.info(e.getStackTrace().toString());

					throw new Exception("Error while reading the Response File :  " + ResponsePath);
				}




				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                        
				/////////////////////////////////////////// Start of Test Data/////////////////////////////////////////////////////////////////////////                                             
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



				String TestDataSheetName=InterfaceTestSettings.Environment;

				if(InterfaceTestSettings.UseCommonTestDataSheet)
				{
					TestDataSheetName=InterfaceTestSettings.CommonTestDataSheetName;
				}






				HashMap<String, String> tempDictData = new HashMap<String, String>();
				try
				{
					MSSQLUtilities sql = new MSSQLUtilities();
					tempDictData = utilObj.getTestData(InterfaceTestSettings.TestDataPath, TestDataFileName,TestCase,  Module,APITestSettings.Browser, TestDataSheetName,String.valueOf(Iteration), InterfaceTestSettings.ExcelSheetExtension);
					for (Map.Entry<String, String> entry : tempDictData.entrySet()) {
			            String key = entry.getKey();
			            String value = entry.getValue();
			            value = value.toUpperCase();

			            if (value.contains("QUERY:")) {
			                value = value.replace("QUERY:", "");
			                value = sql.ReadData_DBValidation(APISessionData.envModel.ConnectionString, value);
			                if(value==null) {
			                	value="";
			                }
			                tempDictData.put(key, value);
			                System.out.println("Query has been fetched from TestData: "+value);
			            }
			        }
					RequestData = tempDictData.entrySet().stream().reduce(RequestData,(s, e) -> s.replace("#*" + e.getKey()+ "*#", e.getValue()),(s1, s2) -> null);
					ResponseData = tempDictData.entrySet().stream().reduce(ResponseData,(s, e) -> s.replace("#*" + e.getKey()+ "*#", e.getValue()),(s1, s2) -> null);
					ServiceURL=tempDictData.entrySet().stream().reduce(ServiceURL,(s, e) -> s.replace("#*" + e.getKey()+ "*#", e.getValue()),(s1, s2) -> null);
					ServiceURL=APISessionData.replaceSessionData(TestCase, Module, "", Iteration, ServiceURL);                                

					System.out.println("////////////////////////////////////////////////////////////////////////////");
					System.out.println("Request Data");
					System.out.println("////////////////////////////////////////////////////////////////////////////");
					System.out.println(RequestData);
					System.out.println("////////////////////////////////////////////////////////////////////////////");
					System.out.println("////////////////////////////////////////////////////////////////////////////");




					logger.info("Test Data read for the sheet : " + TestDataFileName);
					logger.info("Request Data for the Interface '"+ InterfaceName + "': " + RequestData);
					logger.info("Response Data for the Interface '" + InterfaceName + "': " + ResponseData);


					if (interFaceObj.isMockRequired())
					{
						try
						{

							TemplateData =FileUtils.readFileToString(new File(InterfaceTestSettings.MockTemplateLocation + "\\" + mockData.TemplateName + mockData.MockFileFormat),StandardCharsets.UTF_8).trim();
							// String TempMockData = tempDictData.Aggregate(TemplateData, (current, value) => current.Replace("#*" + value.Key + "*#", value.Value));
							mockData.MockFileContent  = tempDictData.entrySet().stream().reduce(TemplateData,(s, e) -> s.replace(e.getKey(), e.getValue()),(s1, s2) -> null);


							logger.info("Mock Data for the Interface '" + InterfaceName + "': " + MockData);
						}
						catch (Exception e)
						{

							System.out.println(e.getMessage());
							System.out.println(e.getStackTrace());

							logger.info(e.getMessage());
							logger.info(e.getStackTrace().toString());

							throw new Exception("Error while reading the Mock File . Please check if the Test Data Sheet/Mock File is correctly configured for : " + mockData.MockFileName);
						}

					}



				}
				catch (Exception e)
				{

					System.out.println(e.getMessage());
					System.out.println(e.getStackTrace());

					logger.info(e.getMessage());
					logger.info(e.getStackTrace().toString());

					throw new Exception("Error while reading the TestData. Please check if the Test Data Sheet is correctly configured for : " + TestDataFileName);
				}


				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                        
				/////////////////////////////////////////// End of Test Data/////////////////////////////////////////////////////////////////////////                                             
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////








				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                        
				/////////////////////////////////////////// Response Validation////////////////////////////////////////////////////////////////////////                                             
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

				try
				{
					ArrayList<String> whereClause_Validate = new ArrayList<String>();
					whereClause_Validate.add("Validate::Yes");
					whereClause_Validate.add("Module::" + Module);
					whereClause_Validate.add("InterfaceName::" + InterfaceName);

					HashMap<String, ArrayList<String>> DictResponseValidationData = poiObj.fetchWithCondition(InterfaceTestSettings.ResponseValidationFilePath, InterfaceTestSettings.ResponseValidationSheetName, whereClause_Validate);




					if ((DictResponseValidationData.isEmpty()==false)&& (DictResponseValidationData.get("ResponseType").size()>0))
					{


						responsevalidationModel.ResponseType=DictResponseValidationData.get("ResponseType").get(0);
						for(int i=0;i<DictResponseValidationData.get("InterfaceName").size();i++ )
						{

							String xpath_jsonpath="";	
							String ExpectedValue="";
							String DataElements="";


							if(DictResponseValidationData.get("xpath_jsonpath").get(i).equals("")==false)
							{
								xpath_jsonpath=DictResponseValidationData.get("xpath_jsonpath").get(i);
							}

							if(DictResponseValidationData.get("ExpectedValue").get(i).equals("")==false)
							{
								ExpectedValue=DictResponseValidationData.get("ExpectedValue").get(i);
								ExpectedValue=replaceTestData(tempDictData, ExpectedValue);
								ExpectedValue=APISessionData.replaceSessionData(TestCase, Module, "", Iteration, ExpectedValue);

							}

							if(DictResponseValidationData.get("ExpectedDataValue").get(i).equals("")==false)
							{
								DataElements=DictResponseValidationData.get("ExpectedDataValue").get(i);
								DataElements=replaceTestData(tempDictData, DataElements);
								DataElements=APISessionData.replaceSessionData(TestCase, Module, "", Iteration, DataElements);

							}



							if(xpath_jsonpath.equals("")==false)
							{
								responsevalidationModel.XPathJSONPath.put(xpath_jsonpath, ExpectedValue);
							}

							if(DataElements.equals("")==false)
							{
								responsevalidationModel.DataElements.add(DataElements);                                		
							}

						}
					}

				}
				catch (Exception e)
				{

					System.out.println(e.getMessage());
					System.out.println(e.getStackTrace());

					logger.info(e.getMessage());
					logger.info(e.getStackTrace().toString());

					throw new Exception("Error while reading the Response Validation Sheet");
				}

				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				//////////////////////////////////////End of Response Validation////////////////////////////////////////////////////////////////////////                      
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                        
				/////////////////////////////////////////// Store Response Data////////////////////////////////////////////////////////////////////////                                             
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

				StoreResponseModel storeResponseModel=  new StoreResponseModel();                        
				try
				{
					ArrayList<String> whereClause_Store = new ArrayList<String>();
					whereClause_Store.add("Capture::Yes");
					whereClause_Store.add("Module::" + Module);
					whereClause_Store.add("InterfaceName::" + InterfaceName);

					HashMap<String, ArrayList<String>> DictStoreResponseData = poiObj.fetchWithCondition(InterfaceTestSettings.StoreResponseDataFilePath, InterfaceTestSettings.StoreResponseDataSheetName, whereClause_Store);




					if ((DictStoreResponseData.isEmpty()==false)&& (DictStoreResponseData.get("ResponseType").size()>0))
					{


						storeResponseModel.ResponseType=DictStoreResponseData.get("ResponseType").get(0);
						for(int i=0;i<DictStoreResponseData.get("InterfaceName").size();i++ )
						{

							String xpath_jsonpath="";	
							String VariableName="";


							if(DictStoreResponseData.get("xpath_jsonpath").get(i).equals("")==false)
							{
								xpath_jsonpath=DictStoreResponseData.get("xpath_jsonpath").get(i);
							}

							if(DictStoreResponseData.get("VariableName").get(i).equals("")==false)
							{
								VariableName=DictStoreResponseData.get("VariableName").get(i);
							}


							storeResponseModel.XPathJSONPath.put(xpath_jsonpath, VariableName);

						}
					}

				}
				catch (Exception e)
				{

					System.out.println(e.getMessage());
					System.out.println(e.getStackTrace());

					logger.info(e.getMessage());
					logger.info(e.getStackTrace().toString());

					throw new Exception("Error while reading the Response Validation Sheet");
				}


				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				/////////////////////////////////////End of Store Response Data////////////////////////////////////////////////////////////////////////                      
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                      



				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				/////////////////////////////////////Start of Header Data/////////////////////////////////////////////////////////////////////////////                      
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                      



				//Adding Header Data
				HashMap<String, String> HeaderData = new HashMap<String, String>();
				try
				{
					ArrayList<String> whereClause_Header = new ArrayList<String>();
					whereClause_Header.add("Module::" + Module);
					whereClause_Header.add("InterfaceName::" + InterfaceName);
					HashMap<String, ArrayList<String>> DictHeaderData = poiObj.fetchWithCondition(InterfaceTestSettings.HeaderRepository, InterfaceTestSettings.HeaderRepositorySheetName, whereClause_Header);


					if (DictHeaderData.get("InterfaceName").size() > 0)
					{
						for(String HeaderKey : DictHeaderData.keySet())
						{
							if (DictHeaderData.get(HeaderKey).get(0).equals("") == false)
							{

								String HeaderValue=DictHeaderData.get(HeaderKey).get(0);
								HeaderValue=replaceTestData(tempDictData, HeaderValue);
								HeaderData.put(HeaderKey,HeaderValue);
							}
						}
					}



					HeaderData=APISessionData.replaceSessionDataCollection(TestCase, Module, "", Iteration, HeaderData);
				}
				catch (Exception e)
				{

					System.out.println(e.getMessage());
					System.out.println(e.getStackTrace());

					logger.info(e.getMessage());
					logger.info(e.getStackTrace().toString());

					throw new Exception("Error while reading the data from the Header Repository");
				}

				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				///////////////////////////////////////End of Header Data/////////////////////////////////////////////////////////////////////////////                      
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                      




				interFaceObj.setInterfaceDetails( Module, InterfaceName, FileFormat, InterfaceType,
						ServiceURL, SOAPAction, MethodType, CertificateRequired, CertificateFileName, CertificatePassword,
						RequestData, ResponseData,  NeedMock, MockedInterfaceName, mockData,
						HeaderData,  Timeout,responsevalidationModel,storeResponseModel,DBQuery,DBExpectedValue);



				//Adding the interfaceObj in Global InterFace Repository
				return interFaceObj;
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());

				logger.info(e.getMessage());
				logger.info(e.getStackTrace().toString());

				throw new Exception("Error while reading the data for the Interfaces");

			}

		}
		catch (Exception e)
		{

			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());

			logger.info(e.getMessage());
			logger.info(e.getStackTrace().toString());

			throw new Exception("Error while reading the Excel Data. Please check the excel master sheet");
		}

	}


	public String replaceTestData(HashMap<String, String> testDictData,String Value)
	{
		return testDictData.entrySet().stream().reduce(Value,(s, e) -> s.replace(e.getKey(), e.getValue()),(s1, s2) -> null);

	}


}
