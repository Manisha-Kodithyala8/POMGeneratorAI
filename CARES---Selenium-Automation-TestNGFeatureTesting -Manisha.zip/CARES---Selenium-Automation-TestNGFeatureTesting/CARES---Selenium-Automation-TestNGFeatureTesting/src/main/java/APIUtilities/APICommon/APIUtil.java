package APIUtilities.APICommon;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.javafaker.Faker;

import APIUtilities.TestSettings.APISessionData;


public class APIUtil {


    public enum Mode
    {
        ALPHA, ALPHANUMERIC, NUMERIC
    }

	
    public HashMap<String, String> getTestData(String TDPath, String TestDataSheet, String TestCase,  String Module, String Browser, String Environment, String currentIteration, String DefaultTestDataFormat) throws Exception
    {

    	final Logger logger = LoggerFactory.getLogger(APIUtil.class.getName());
    	
    	DefaultTestDataFormat=".xlsx";
    
        try
        {

            ArrayList<String> TestDataSheets= new ArrayList<String>();
            TestDataSheets.add(TestDataSheet);  
            HashMap<String, String> TestData = new HashMap<String, String>();
            Random r = new Random();


            for (String TD : TestDataSheets)
            {
                String TestDataPath = TDPath + "\\" + TD + ".xlsx";

                ExcelUtil poiObject = new ExcelUtil();
                // TODO Auto-generated method stub




                ArrayList<String> whereClause_TestData = new ArrayList<String>();
                whereClause_TestData.add("Iteration::" + currentIteration.toString());
                HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestDataPath, Environment, whereClause_TestData);


                if (result.get("Iteration").size() == 0)
                {

                    logger.error("Blank column in Test Data - There is no data in the column  for the Iteration " + currentIteration.toString() + " of Environment " + Environment);
                }


                for (String key : result.keySet())
                {
                    if (result.get(key).get(0).toLowerCase().trim().startsWith("random_"))
                    {
                       result.get(key).set(0,getRandom(result.get(key).get(0)));
                        Thread.sleep(500);
                        logger.info("Random Value Added in " + key + " = " +result.get(key).get(0));
                    }
                    
                    if ((result.get(key).get(0).toLowerCase().trim().startsWith("##")) || (result.get(key).get(0).toLowerCase().trim().startsWith("session="))  )
                    {
                    	String SessionKey=result.get(key).get(0);
                    	SessionKey=SessionKey.split("=")[1];
                       result.get(key).set(0,getSessionData(TestCase,Module,Browser,currentIteration,SessionKey));
                       
                        Thread.sleep(500);
                        logger.info("Session Value Added in " + key + " = " +getSessionData(TestCase,Module,Browser,currentIteration,key));
                    }
                    Thread.sleep(10);
                    if (TestData.containsKey(key) == false)
                    {
                        TestData.put(key,result.get(key).get(0));
                    }
                    else
                    {
                        TestData.replace(key,result.get(key).get(0));
                    }
                }


            }
            return TestData;
        }
        catch (Exception e)
        {


            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( e.getStackTrace().toString());
            
            throw e;
        }

    }

    
    public  String generateRandomString(int length, Mode mode)
    {

        StringBuilder buffer = new StringBuilder();
        String characters = "";

        switch (mode)
        {

            case ALPHA:
                characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                break;

            case ALPHANUMERIC:
                characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
                break;

            case NUMERIC:
                characters = "1234567890";
                break;
        }
        int charactersLength = characters.length();
        Random random = new Random();

        for (int i = 0; i < length; i++)
        {

            int index = random.nextInt(charactersLength);

            buffer.append(characters.charAt(index));
        }
        return buffer.toString();
    }

    public String getSessionData(String TestCase,String Module,String Browser,String currentIteration,String key)
    {
    	return APISessionData.getSessionData(TestCase,Module,Browser,currentIteration,key);
    }
    
    public String getRandom(String value)
    {
        Random r = new Random();
        if (value.toLowerCase().contains("name"))
        {
        	
            value =generateFirstName();//generateRandomString(r.nextInt(20-5)+5, Mode.ALPHA);
        }
        else if (value.toLowerCase().contains("dobsoap"))
        {
            value = getDateOfBirthSOAP(value);
        }

        else if (value.toLowerCase().contains("dob"))
        {
            value = getDateOfBirth(value);
        }

        else if (value.toLowerCase().contains("ssn"))
        {
            value = GetRandomSSN();
        }
        else if (value.toLowerCase().contains("ssn_dash"))
        {
            value = GetRandomSSN("-");
        }
        else if (value.toLowerCase().contains("psuedossn"))
        {
            value = GetRandomSSN();
        }
        else if (value.toLowerCase().contains("psuedossn_dash"))
        {
            value = GetRandomSSN("-");
        }
        else if (value.toLowerCase().contains("individualid"))
        {
            value = generateRandomString(9, Mode.NUMERIC);
        }
        else if(value.toLowerCase().contains("number"))
        {
            /*ArrayList<String> values = value.Split(';').Where(x => !String.IsNullOrWhiteSpace(x)).ToList();
           */ 
            List<String> values = List.of(value.split(";")); 
            int length = values.size() > 1 && values != null ? Integer.parseInt(values.get(1)) : 10;
            value = generateRandomString(length, Mode.NUMERIC);
        }
        else if (value.toLowerCase().contains("alphanum"))
        {
            value = generateRandomString(30, Mode.ALPHANUMERIC);
        }
        else if(value.toLowerCase().contains("uuid") || value.toLowerCase().contains("guid"))
        {
            UUID guid = UUID.randomUUID();
            value = guid.toString();
        }

        return value;
    }

    public String getDateOfBirth(String dataValue, String datTimeFormat)
    {
       String dfformat="MM/dd/yyyy";
      
        Random r = new Random();
        String Date = "";
        int Daterange;
        try
        {
            
            int NoOfdays = (Integer.parseInt(dataValue.split(";")[1])) * 365 + (int)((Integer.parseInt(dataValue.split(";")[1])) / 4);
            int min =NoOfdays + 1;
            int max =NoOfdays + 364;
            Daterange = r.nextInt(max - min) + min;
            
            LocalDate Ldate = LocalDate.now();
            Ldate=Ldate.minusDays(Daterange);
            DateTimeFormatter format = DateTimeFormatter.ofPattern(dfformat);
             Date = Ldate.format(format);
            
        }
        catch (Exception e)
        {
            System.out.println(e.toString());
            System.out.println(e.getMessage());

            throw e;
        }
        return Date;
    }


    public String getDateOfBirth(String dataValue)
    {
       String dfformat="MM/dd/yyyy";
       
        Random r = new Random();
        String Date = "";
        int Daterange;
        try
        {
            
            int NoOfdays = (Integer.parseInt(dataValue.split(";")[1])) * 365 + (int)((Integer.parseInt(dataValue.split(";")[1])) / 4);
            int min =NoOfdays + 1;
            int max =NoOfdays + 364;
            Daterange = r.nextInt(max - min) + min;
            
            LocalDate Ldate = LocalDate.now();
            Ldate=Ldate.minusDays(Daterange);
            DateTimeFormatter format = DateTimeFormatter.ofPattern(dfformat);
             Date = Ldate.format(format);
            
        }
        catch (Exception e)
        {
            System.out.println(e.toString());
            System.out.println(e.getMessage());

            throw e;
        }
        return Date;
    }


    
    public String getDateOfBirthSOAP(String dataValue)
    {
       String dfformat="yyyy-MM-dd";
       
        Random r = new Random();
        String Date = "";
        int Daterange;
        try
        {
            
            int NoOfdays = (Integer.parseInt(dataValue.split(";")[1])) * 365 + (int)((Integer.parseInt(dataValue.split(";")[1])) / 4);
            int min =NoOfdays + 1;
            int max =NoOfdays + 364;
            Daterange = r.nextInt(max - min) + min;
            
            LocalDate Ldate = LocalDate.now();
            Ldate=Ldate.minusDays(Daterange);
            DateTimeFormatter format = DateTimeFormatter.ofPattern(dfformat);
             Date = Ldate.format(format);
             Date=Date+"T00:00:00.000";
        }
        catch (Exception e)
        {
            System.out.println(e.toString());
            System.out.println(e.getMessage());

            throw e;
        }
        return Date;
    }


    public String generateFirstName() 
    {
    	Faker faker = new Faker();
    	String firstName = faker.name().firstName();
    	
    	return firstName;
    }
    public String generateLastName() 
    {
    	Faker faker = new Faker();
    	String firstName = faker.name().lastName();
    	
    	return firstName;
    }



    public String GetRandomSSN(String delimiter)
    {
    	
    	
        Integer iThree = GetRandomNumber(132, 921);
        Integer iTwo = GetRandomNumber(12, 83);
        Integer iFour = GetRandomNumber(1423, 9211);
        return iThree.toString() + delimiter + iTwo.toString() + delimiter + iFour.toString();
    }
    
    public String GetRandomSSN()
    {
    	String delimiter="";
    	
        Integer iThree = GetRandomNumber(132, 921);
        Integer iTwo = GetRandomNumber(12, 83);
        Integer iFour = GetRandomNumber(1423, 9211);
        return iThree.toString() + delimiter + iTwo.toString() + delimiter + iFour.toString();
    }

    public String GetRandomPsuedoSSN(String delimiter)
    {
    	
    	Integer iThree = GetRandomNumber(911, 988);
    	Integer iTwo = GetRandomNumber(12, 83);
    	Integer iFour = GetRandomNumber(1423, 9211);
        return iThree.toString() + delimiter + iTwo.toString() + delimiter + iFour.toString();
    }

    public int GetRandomNumber(int min, int max)
    {
        Random getrandom = new Random();
        
        return getrandom.nextInt(max - min) + min;
        
    }
    
    public Properties loadProperties(String Filepath) throws IOException,Exception
    {
    	

        FileInputStream propsInput = new FileInputStream(Filepath);

        Properties prop = new Properties();

        prop.load(propsInput);

       
    	return prop;
    }

    public static String getCurrentDate(){

        try { 
    LocalDateTime today = LocalDateTime.now();
    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy");
    String date = today.format(format);
    date = date.replace(":", "_");
    date = date.replace(" ", "_");
    date = date.replace(".", "_");
    date = date.replace("-", "_");
    return date;
    }
        catch(Exception e)
        {
            System.out.println(e.getMessage()); 
            
            throw e;
        }
}

    /// <summary>
    /// This method is get the Current Time in the format 'hh-mm-ss'
    /// </summary>
    /// Author: Jigesh Shah
    /// <returns>Current Time in String Format</returns>
    public static String getCurrentTime(){
        try { 
        	 Date date = Calendar.getInstance().getTime();
			   DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss.sss");
			   String result = dateFormat.format(date);
			   result = result.replace(":", "_");
            result = result.replace(" ", "_");
            result = result.replace(".", "_");
    return result;

    }
        catch(Exception e)
        {
            System.out.println(e.getMessage());   
            
            throw e;
        }

}



}
