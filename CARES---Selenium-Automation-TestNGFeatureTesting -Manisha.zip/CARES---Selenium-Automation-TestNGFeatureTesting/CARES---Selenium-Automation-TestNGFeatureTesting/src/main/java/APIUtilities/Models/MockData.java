package APIUtilities.Models;

public class MockData {
	public String ID;
	public String MockLocation;
	public String TemplateName;
	public String InterfaceType;
	public String RecordCount;
	public String MockFileName;
	public String MockFileFormat;
	public String MockFileContent;
}
