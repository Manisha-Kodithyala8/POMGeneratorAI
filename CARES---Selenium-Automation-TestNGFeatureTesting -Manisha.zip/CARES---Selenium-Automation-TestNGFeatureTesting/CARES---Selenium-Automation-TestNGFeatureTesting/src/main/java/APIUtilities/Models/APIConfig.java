package APIUtilities.Models;

public class APIConfig {

	//InterfaceTestRunSettings

	public  String Environment="";
    public  String DefaultTestDataFormat = ".xlsx";
    public  String InterfaceTestCaseSheet = "";
    public  String UrlRepositorySheet = "";
    public  String RequestLocation = "";
    public  String ResponseLocation = "";
    public  String CertificateLocation = "";
    public  String CertificatePassword="";
    public  String TestDataPath = "";
    
    public  boolean AddReportToDB = false;

    public  long TestRunId = 1;
    public  String MockRepositorySheet;
    public  String InterfaceSheetDetails;
    public  String ExcelSheetExtension;
    public  String XMLExtension;
    public  String JSONExtension;
    public  String CommonMockSheetName;
    public  String UseCommonMockSheet="";
    public  String MockSheetName;
    public  String HeaderRepositorySheetName;
    public  String HeaderRepository;
    public  String ResponseSheetPath;
    public  Integer DefaultServiceTimeout;
    public  String MockTemplateLocation;
    public  String DomainName;
	public String ExcelFileName;
	public String ResponseValidationFilePath;
	public String ResponseValidationSheetName;
	public String TestDataLocation_SD;
	public String TestDataLocation_XMLValidation;
	public String ConfigLocation_XMLValidation;
	public boolean UseCommonTestDataSheet;
	public String CommonTestDataSheetName;
	public String APITestSuiteDirectory;
	public String APITestCaseDirectory;
	public String APIDirectory;
	public String APITestSuiteFileName;
	public String APITestSuiteSheetName;
	public String APITestCaseSheetName;

	public String StoreResponseDataFilePath;
	public String StoreResponseDataSheetName;

	
}
