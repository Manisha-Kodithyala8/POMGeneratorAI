package APIUtilities.Models;

import java.util.HashMap;

public class APIReportModel {

	public String TestStepResult="";
	public boolean boolResponseStringValidation=false;
	public boolean boolXMLJSONValidation=false;
	public boolean DataElementsValidation=false;
	public String ExpectedResponse="";
	public String ActualResponse="";
	public String  XPathJSONKey="";
	public String  DataElementKey="";
	public String  AdditionalDetails="";
	public String Request;
	public String Response;
	public String URL;
	public String DBValidation;
	public String DBExpectedValue;
	public String DBActualValue;
	public String StatusCode;
}
