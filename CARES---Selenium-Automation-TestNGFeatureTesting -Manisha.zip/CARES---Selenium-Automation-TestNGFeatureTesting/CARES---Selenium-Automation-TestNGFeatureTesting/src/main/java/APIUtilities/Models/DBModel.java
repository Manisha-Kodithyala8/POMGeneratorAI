package APIUtilities.Models;

import java.util.HashMap;

public class DBModel {
	public String LoggingConnectionString = "";
	public String LoggingTableName = "";


	public HashMap<String,EnvModel> Env = new HashMap<String,EnvModel>();
}
