package APIUtilities.Models;

public class EnvModel {

	public String Env = "";
	public String ConnectionString = "";
	public String MCIURL = "";
	public String EDBCURL = "";
	public String DispositionURL = "";
}
