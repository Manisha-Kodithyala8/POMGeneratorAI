package APIUtilities.Models;

import java.util.ArrayList;
import java.util.HashMap;

public class StoreResponseModel {

	public String ResponseType="";
	public HashMap<String,String> XPathJSONPath= new HashMap<String,String>();
	
}
