package APIUtilities.Models;

import java.util.ArrayList;
import java.util.HashMap;

public class ResponseValidationModel {

	public String ResponseType="";
	public String ExpectedResponseFilePath="";
	public String ExpectedResponse="";
	public String ActualResponseFilePath="";
	public String ActualResponse="";
	public HashMap<String,String> XPathJSONPath= new HashMap<String,String>();
	public ArrayList<String> DataElements= new ArrayList<String>();
	
}
