package APIUtilities.Models;

import java.util.ArrayList;
import java.util.HashMap;

public class APIModel {

    int TestCaseId = 1;
    String TestCaseName = "";
    String Module = "";
    String InterfaceName = "";
    String FileFormat = "";
    String APIType = "";
    String ServiceURL = "";
    String SOAPAction = "";
    String MethodType = "";
    String DBQuery="";
    String DBExpectedValue="";
	boolean CertificateRequired;
    String CertificateFileName = "";
    String CertificatePassword = "";
    String RequestFilePath = "";
    String ResponseFilePath = "";
    String TestDataFilePath = "";
    String RequestData="";
    String ResponseData = "";
    boolean NeedMock;
    String MockedInterfaceName;
    int StartIndexforIteration;
    int EndIndexforIteration;
    ArrayList<Integer> Iterations_Collection = new ArrayList<Integer>();
    int IterationCount;
    int Timeout;
    ResponseValidationModel responseValidationModel= new ResponseValidationModel();
    StoreResponseModel storeResponseModel= new StoreResponseModel();
    MockData mockData = new MockData();

    HashMap<String, String> HeaderData = new HashMap<String, String>();

    public void setTestCaseId(String testCaseId)
    {
        TestCaseId = Integer.parseInt(testCaseId);
    }


    public void setTestCaseName(String testCaseName)
    {
        TestCaseName = testCaseName;
    }

    public void setModule(String module)
    {
        Module = module;
    }

    public void setInterfaceName(String interfaceName)
    {
        InterfaceName = interfaceName;
    }

    public void setFileFormat(String fileFormat)
    {
        FileFormat = fileFormat;
    }

    public void setInterfaceType(String interfaceType)
    {
        APIType = interfaceType;
    }

    public void setServiceUrl(String url)
    {
        ServiceURL = url;
    }

    public void setSOAPAction(String sOAPAction)
    {
        SOAPAction = sOAPAction;
    }


    public void setMethodType(String methodType)
    {
        MethodType = methodType;
    }

    public String getDBQuery() {
		return DBQuery;
	}


	public void setDBQuery(String dBQuery) {
		DBQuery = dBQuery;
	}
	
	public String getDBExpectedValue() {
		return DBExpectedValue;
	}


	public void setDBExpectedValue(String dBExpectedValue) {
		DBExpectedValue = dBExpectedValue;
	}
	
    public void setCertificatePath(String certificationRequired,String  certificatePath, String certificatePassword)
    {
        if (certificationRequired.equalsIgnoreCase("YES"))
        {
            CertificateRequired = true;
            CertificateFileName = certificatePath;
            CertificatePassword = certificatePassword;
        }
        else
        {
            CertificateRequired = false;
            CertificateFileName = "";
            CertificatePassword = "";
        }
    }


    public void setRequestData(String requestData)
    {
        RequestData = requestData;
    }

    public void setResponseData(String responseData)
    {
        ResponseData = responseData;
    }

    public void setRequestPath(String requestPath)
    {
        RequestFilePath = requestPath;
    }

    public void setResponsePath(String responsePath)
    {
        ResponseFilePath = responsePath;
    }

    public void setTestDataFileName(String testDataFileName)
    {
        TestDataFilePath = testDataFileName;
    }

    public void setMockDetails(String needMock, String mockedInterfaceName)
    {
        if (needMock.toUpperCase().trim() == "YES")
        {
            NeedMock = true;
            MockedInterfaceName = mockedInterfaceName;

        }
        else
        {
            NeedMock = false;
            MockedInterfaceName = "";
        }
    }

    public void setStartIndexAndEndforIteration(String startIndexforIteration, String iterationCount)
    {
       IterationCount = 1;
        StartIndexforIteration = 1;
        try
        {
            IterationCount = Integer.parseInt(iterationCount);

        }

        catch (Exception e)
        {

        }
        try
        {
            StartIndexforIteration = Integer.parseInt(startIndexforIteration);

        }

        catch (Exception e)
        {

        }

        if (IterationCount == 1)
        {
            EndIndexforIteration = StartIndexforIteration;

            Iterations_Collection.add(EndIndexforIteration);
        }
        else
        {
            EndIndexforIteration = StartIndexforIteration + (IterationCount - 1);

            for (int ii = 0; ii < IterationCount; ii++)
            {
                Iterations_Collection.add(StartIndexforIteration + ii);
            }
        }

    }


    public void setTestDataPath(String testDataPath)
    {
        TestDataFilePath = testDataPath;
    }


    public void setHeaderData(HashMap<String, String> headerData)
    {
        HeaderData = headerData;
    }




    public void setMockData(MockData lclmockData)
    {
        mockData = lclmockData;
    }

    public void setTimeout(int timeout)
    {
        Timeout = timeout;
    }


    public int getTestCaseId()
    {
        return TestCaseId;
    }


    public String getTestCaseName()
    {
        return TestCaseName;
    }

    public String getModule()
    {
        return Module;
    }

    public String getInterfaceName()
    {
        return InterfaceName;
    }

    public String getFileFormat()
    {
        return FileFormat;
    }

    public String getInterfaceType()
    {
        return APIType;
    }

    public String getServiceUrl()
    {
        return ServiceURL;
    }

    public String getSOAPAction()
    {
        return SOAPAction;
    }

    public String getMethodType()
    {
        return MethodType;
    }

    public boolean isCertificateRequired()
    {
        return CertificateRequired;
    }


    public String getCertificatePath()
    {
        return CertificateFileName;
    }


    public String getCertificatePassword()
    {
        return CertificatePassword;
    }

    public String gettRequestPath()
    {
        return RequestFilePath;
    }
    public String gettRequestData()
    {
        return RequestData;
    }

    public String getResponsePath()
    {
        return ResponseFilePath;
    }
    public String getResponseData()
    {
        return ResponseData;
    }


    public String getTestDataPath()
    {
        return TestDataFilePath;
    }

    public boolean isMockRequired()
    {
        return NeedMock;
    }


    public String getMockedInterfaceName()
    {
        return MockedInterfaceName;
    }

    public int getStartIndexForIteration()
    {
        return StartIndexforIteration;
    }

    public int getEndIndexforIteration()
    {
        return EndIndexforIteration;
    }

    public int getIterationCount()
    {
        return IterationCount;
    }

    public int getIterationFromCollection(int IterationCount) throws Exception
    {
        try
        {

            return Iterations_Collection.get(IterationCount);

        }
        catch (Exception e)
        {
            throw new Exception("Incorrect Iteration Count provided");
        }
    }
    public MockData GetMockData()
    {
        return mockData;
    }


    public HashMap<String, String> GetHeaderData()
    {
        return HeaderData;
    }

    public int getTimeout()
    {
        return Timeout;
    }

    public ResponseValidationModel getResponseValidationModel()
    {
        return responseValidationModel;
    }

    public void setResponseValidationModel(ResponseValidationModel responseValidationModel)
    {
    	this.responseValidationModel=responseValidationModel;
    }

    
    public StoreResponseModel getStoreResponseModel()
    {
        return storeResponseModel;
    }

    public void setStoreResponseModel(StoreResponseModel storeResponseModel)
    {
    	this.storeResponseModel=storeResponseModel;
    }


    public void setInterfaceDetails(String Module, String InterfaceName, String FileFormat, String InterfaceType,String ServiceURL,String SOAPAction,String MethodType, String CertificateRequired, String CertificateFileName, String CertificatePassword, String RequestData, String ResponseData, String NeedMock, String MockedInterfaceName, MockData mockData, HashMap<String,String> HeaderData, int timeout,ResponseValidationModel responseValidationModel ,StoreResponseModel storeResponseModel, String DBQuery, String DBExpectedValue)
	{

        setModule(Module);
		setInterfaceName(InterfaceName);
        setFileFormat(FileFormat);
        setInterfaceType(InterfaceType);
        setServiceUrl(ServiceURL);
        setSOAPAction(SOAPAction);
        setMethodType(MethodType);
        setCertificatePath(CertificateRequired, CertificateFileName,CertificatePassword);
		setRequestData(RequestData);
		setResponseData(ResponseData);
        setMockDetails(NeedMock, MockedInterfaceName);
        setHeaderData(HeaderData);
        setMockData(mockData);
        setTimeout(timeout);
        setResponseValidationModel(responseValidationModel);
        setStoreResponseModel(storeResponseModel);
        setDBQuery(DBQuery);
        setDBExpectedValue(DBExpectedValue);

    }
	
	
}
