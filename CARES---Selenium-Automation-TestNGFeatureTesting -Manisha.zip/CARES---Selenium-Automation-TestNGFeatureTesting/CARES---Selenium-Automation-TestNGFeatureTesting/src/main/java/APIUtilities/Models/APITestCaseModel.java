package APIUtilities.Models;

public class APITestCaseModel {

	public String TestCase;
	public String TestCaseDescription;
	public String Directory;
	public String TestCaseFilePath;
	public String UserStory;
		
}
