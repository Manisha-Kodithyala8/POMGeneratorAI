package APIUtilities.Models;

public class APITestStepModel {

	public String Module;

	public String APIName;
	public String FilePath;
	public String SheetName;
	public int StartIndexforIteration;
	public int EndIndexforIteration;
		
}
